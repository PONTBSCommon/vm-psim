var defaultExpiryDate = new Date();
defaultExpiryDate.setFullYear(defaultExpiryDate.getFullYear() + 1);
defaultExpiryDate.setMonth(defaultExpiryDate.getMonth() + 1);

$(document).on("click", "input[name='roles']", function () {
    handleBadgeCheckboxToggle($(this));
});

$(document).on("click", "input[name='state']", function () {
    handleAccountStateToggle($(this));
});

$(document).on("click", ".removeEmail", function () {
   $(this).parents(".email").remove();
});

$(document).on("click", ".addEmail", function () {
    $(this).parents(".emailsSection").find(".email").first().clone().find("input[name='emails']").val("").end().appendTo($(this).parents(".emailsSection").find(".emailsWrapper"));
});


function handleBadgeCheckboxToggle (checkbox) {
    if ($(checkbox).is(":checked")) {
        $(checkbox).parent().removeClass("disabled")
    }
    else {
        $(checkbox).parent().addClass("disabled");
    }
}

function handleAccountStateToggle (radioButton) {
    radioButton = $(radioButton);

    var form = radioButton.parents("form");

    $("input[name='state']", form).each(function () {
        if ($(this).is(":checked")) {
            $(this).parent().removeClass("disabled");
        }
        else {
            $(this).parent().addClass("disabled");
        }
    })
}

function resetAddUserForm() {
    var form = $("#addUserForm");

    $("input", form).not("[name^='expiryDate']").not("[name='state']").val("");
    //$("input[name='expiryDate-display']", form).datepicker("setDate", defaultExpiryDate);
    $("input[name='expiryDate']", form).val(defaultExpiryDate.getMonth() + "/" + defaultExpiryDate.getDate() + "/" + defaultExpiryDate.getFullYear());
    $("textarea", form).val("");
    //$("input[name='state']").prop("checked", false).addClass("disabled");
    $(".userAccountState-ACTIVE", form).find("input").prop("checked", "true").trigger("click");
    $(".email", form).not(":eq(0)").find(".removeEmail").trigger("click");
    $("#addDate").attr('disabled','disabled');
    $('#addExpireButton').removeClass("btn btn-danger").addClass("btn btn-secondary");
}

$(document).ready(function () {

    useAjaxForForm($("#addUserForm"), {
        beforeSend: function (xhr, data) {
            if (isEmptyParam(data.data, "emails", "#addUserForm")){
                xhr.abort();
                return false;
            }
            startSpinnerOnButton($("#addUserSaveButton"));
        },
        success: function (data) {
            dtUnloadUUID("#users-table");
            dtRedraw("#users-table");
            $("#addUserModal").modal("hide");
            notifySuccess(data);
        },
        complete: function () {
            stopSpinnerOnButton($("#addUserSaveButton"));
        }
    });

    $("#changePasswordDialog").hide();

    if (!isPonUserEnabled){
        $("#addUser").prop("disabled", true);
    }

    $('#addExpireButton').click(function() {

        if ($("#addDate").is(":disabled")){
            $("#addDate").removeAttr('disabled');
            $('#addExpireButton').removeClass("btn btn-secondary").addClass("btn btn-danger");
        }
        else{
            $("#addDate").attr('disabled','disabled');
            $('#addExpireButton').removeClass("btn btn-danger").addClass("btn btn-secondary");
        }
    });

    $('#editExpireButton').click(function() {

        if ($("#editDate").is(":disabled")){
            $("#editDate").removeAttr('disabled');
            $('#editExpireButton').removeClass("btn btn-secondary").addClass("btn btn-danger");
        }
        else{
            $("#editDate").attr('disabled','disabled');
            $('#editExpireButton').removeClass("btn btn-danger").addClass("btn btn-secondary");
        }
    });

    $("#changePasswordButton").click(function(){
        $("#changePasswordDialog input[name='password']").val("");
        $("#changePasswordDialog input[name='confirmPassword']").val("");
        $("#changePasswordDialog input[name='id']").val($("#editUserDialog input[name='id']").val());

        $("#editUserDialog").hide();
        $("#changePasswordDialog").show();
    });

    $("#changePasswordCancel").click(function(){
        $("#changePasswordDialog").hide();
        $("#editUserDialog").show();
    });

    $('#addUserForm').on('input', function(){
        resetErrorsOnForm('#addUserForm');
    });

    $('#editUserForm').on('input', function(){
        resetErrorsOnForm('#editUserForm');
    });

    $('#changePassForm').on('input', function(){
        resetErrorsOnForm('#changePassForm');
    });

    $("#addUserSaveButton").click(function () {
        passwordCheck("#addUserForm");
    });

    $("#changePassword").click(function(){
        passwordCheck("#changePassForm");
    });

    $(".datapicker").datepicker({
        autoclose:true
    });


    $("#addUser").click(function () {
        resetAddUserForm();
        var modal = $("#addUserModal");
        modal.one("transitionend", function () {
            $("#addUserForm").parent(".modal-body").scrollTop(0);
        });
        modal.modal("show");
    });

    $("#editUsers").click(function () {
        var id = $("#users-table tr.selected").data("id");
        var username = $("#users-table tr.selected").data("username");

        populateEditUserForm(id, username);

        $("#changePasswordDialog").hide();
        $("#editUserDialog").show();

        $("#editUserModal").modal("show");
    });

    $("#confirmDelete").click(function () {
        ajax({
            url: CONTEXT + "/users/delete",
            method: "POST",
            data: dtGetTableParamsForAjax("#users-table"),
            beforeSend: function () {
                startSpinnerOnButton($("#confirmDelete"));
            },
            success: function (data) {
                dtUnload("#users-table");
                loadUsersTable();
                $("#deleteUsers").prop("disabled", true);
                notifySuccess(data);
            },
            complete: function () {
                stopSpinnerOnButton($("#confirmDelete"));
                $("#confirmDeleteModal").hide();
            }
        });
    });

    $("#users-table").one("draw.dt", function () {
        $(this).on("dt.selection.updated", function () {
            var indexes = dtGetSelectedRowIndexes("#users-table");

            if (isPonUserEnabled) {
                $("#editUsers").prop("disabled", false);
                $("#deleteUsers").prop("disabled", false);
            }
            else
            {
                $("#editUsers").prop("disabled", true);
                $("#deleteUsers").prop("disabled", true);
                return;
            }

            if (indexes.length <= 0) {
                $("#deleteUsers").prop("disabled", true);
            }

            if (indexes.length != 1){
                $("#editUsers").prop("disabled", true);
            }
        });
    });

    loadUsersTable();

    ajax({
        url: CONTEXT + "/users/userEdit",
        method: "GET",
        success: function (data) {
            if (data)
            {
                $('#editUserEdit').bootstrapToggle('on');
            }
            else
            {
                $('#editUserEdit').bootstrapToggle('off')
            }
        },
        complete: function ()
        {
            $('#editUserEdit').change(function() {
                var enabled = $('#editUserEdit').is(":checked");
                ajax({
                    url: CONTEXT + "/users/userEdit",
                    method: "POST",
                    data: "isUserEdit=" + enabled,
                    success: function (data) {
                        notifySuccess(data);
                    }
                });
            })
        }
    });
});

function loadUsersTable() {
    dtLoad("#users-table", {
        fnRowCallback: function( nRow, aData ) { return decorateRow(nRow, aData); },
        ajax: {
            url: CONTEXT + "/users/list"
        },
        serverSide: true,
        columns: [
            {data: "userName", "class": "userName"},
            {data: "firstName", "class": "firstName"},
            {data: "lastName", "class": "lastName"},
            {data: "roles", "class": "roles"},
            {data: "state", "class": "state"},
            {data: "id"}
        ],
        selectableRows: true,
        multiSelectRows: true
    });
}

function startUsersSpinner () {
    $("#usersPanelWrapper").hide();
    startSpinner("#usersSpinner");
}

function stopUsersSpinner () {
    stopSpinner("#usersSpinner");
    $("#usersPanelWrapper").show();
}

function populateEditUserForm(id, username) {
    var ourPanel = $("#editUserForm");

    var html = "";
    if (username.length > 20) {
        html += username.substring(0,20) + "&nbsp;<span title='" + username + "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else {
        html += username;
    }
    $("#editHeader").find(".editUserPanelTitle").html(html);
    $("#passwordHeader").find(".passwordPanelTitle").html(html);


    $("#changePasswordDialog input[name='userName']").val(username);

    $(".email", ourPanel).not(":eq(0)").find(".removeEmail").trigger("click");

    // Edit a user : user hits 'save'
    useAjaxForForm($("#editUserForm"), {
        beforeSend: function (xhr, data) {

            //Check if email is not empty
            if (isEmptyParam(data.data, "emails", "#editUserForm")){
                xhr.abort();
                return false;
            }
            startSpinnerOnButton($("button[type='submit']", $("#editUserForm")));
        },
        success: function (data) {
            dtUnloadUUID("#users-table");
            dtRedraw("#users-table");
            $("#editUserModal").modal("hide");
            notifySuccess(data);
        },
        complete: function () {
            stopSpinnerOnButton($("button[type='submit']", $("#editUserForm")));
        }
    });

    useAjaxForForm($("#changePassForm"), {
        beforeSend: function () {
            startSpinnerOnButton($("#cbutton[type='submit']", $("#changePassForm")));
        },
        success: function (data) {
            $("#changePasswordDialog").hide();
            $("#editUserDialog").show();
            notifySuccess(data);
        },
        complete: function () {
            stopSpinnerOnButton($("button[type='submit']", $("#changePassForm")));
        }
    });

    $("input[name='roles']", ourPanel).each(function () {
        handleBadgeCheckboxToggle($(this));
    });

    var radio = ourPanel.find("input[name='state']").first();
    handleAccountStateToggle(radio);

    ajax({
        url: CONTEXT + "/users/user/" + id,
        success: function (data) {
            var targetForm = $("#editUserForm");
            for (var i in data)
            {
                if (i == "state") {
                    $("input[name='state']").attr("checked",false).addClass("disabled");
                    $(".userAccountState-ACTIVE", targetForm).addClass("disabled");
                    $(".userAccountState-LOCKED", targetForm).addClass("disabled");
                    $(".userAccountState-EXPIRED", targetForm).addClass("disabled");
                    $(".userAccountState-"+data[i], targetForm).trigger("click").removeClass("disabled").find("input").removeClass("disabled").attr("checked", true);
                }
                else if (i == "description") {
                    $("textarea[name='" + i + "']").val(data[i]);
                }
                else if (i == "cardNumber") {
                    $("input[name='" + i + "']").val(data[i]);
                }
                else if (i == "emails") {
                    var count = 1;
                    for (var email in data[i]) {

                        if (count > 1 && count > $(".email", targetForm).length) {
                            $(".email", targetForm).first().clone().appendTo($(".emailsWrapper", targetForm));
                        }

                        $(".emailsWrapper>.email:nth-child(" + count + ")", targetForm).find("input[name='emails']").val(data[i][email]);

                        count++;
                    }
                }
                else if (i == "expiryDate") {
                    var date = data[i];

                    if (date == "01/01/9999"){
                        date = defaultExpiryDate.getMonth() + "/" + defaultExpiryDate.getDate() + "/" + defaultExpiryDate.getFullYear();
                        $("#editDate").attr('disabled','disabled');
                        $('#editExpireButton').removeClass("btn btn-danger").addClass("btn btn-secondary");
                    }
                    else{
                        $("#editDate").removeAttr('disabled');
                        $('#editExpireButton').removeClass("btn btn-secondary").addClass("btn btn-danger");
                    }

                    $("#editDate").val(date);

                }
                //else if (i == "roles") {
                //    for (var role in data[i]) {
                //        $("input[value='" + data[i][role] + "']", targetForm).attr("checked", true).parent("label").removeClass("disabled");
                //    }
                //}
                else {
                    $("input[name='" + i + "']", targetForm).val(data[i]);
                }
            }
        }
    })
}


function decorateRow (nRow, aData) {
    $(nRow).data("username", aData['userName']);
    $(nRow).data("id", aData['id']);
    decorateUserName ($("td.userName", nRow), aData['userName']);
    decorateFirstName($("td.firstName", nRow), aData['firstName']);
    decorateLastName($("td.lastName", nRow), aData['lastName']);
    decorateState($("td.state", nRow), aData['state']);
    decorateRoles($("td.roles", nRow), aData['roles']);
}

function decorateUserName (column, userName) {
    var html = "";
    if (userName.length > 25) {
        html += userName.substring(0,25) + "&nbsp;<span title='" + userName + "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else {
        html += userName;
    }

    column.html(html);
}

function decorateFirstName (column, firstName) {
    var html = "";
    if (firstName.length > 25) {
        html += firstName.substring(0,25) + "&nbsp;<span title='" + firstName + "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else {
        html += firstName;
    }

    column.html(html);
}

function decorateLastName (column, lastName) {
    var html = "";
    if (lastName.length > 25) {
        html += lastName.substring(0,25) + "&nbsp;<span title='" + lastName + "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else {
        html += lastName;
    }

    column.html(html);
}

function decorateRoles (column, aData) {
    var html = "";

    for (var index in aData) {
        html += "<div class='badge'>" + $("#roles-" + aData[index]).val() + "</div>";
    }

    column.html(html);
}

function decorateState (column, state) {
    column.html("<div class='badge userAccountState-" + state + "'>" + $("#userAccountState-" + state).val() + "</div>");
}

function passwordCheck(form, usernameForm){
    resetErrorsOnForm(form);

     if (form != "#changePassForm" && $("#addUserForm input[name='userName']").val() === '')
     {
        $("#addUserForm").submit();
     }

    var result = samsungPolicyEnforcementPassword($(form + " input[name='userName']").val(), $(form + " input[name='password']").val());

    if ($(form + " input[name='confirmPassword']").val() != $(form + " input[name='password']").val())
    {
        addErrorToField($(form + " input[name='password']"), $("#js-passwordsDontMatch").val());
        addErrorToField($(form + " input[name='confirmPassword']"), $("#js-passwordsDontMatch").val());
    }
    else if (result == 0)
    {
        $(form).submit();
    }
    else if (result == 1)
    {
        addErrorToField($(form + " input[name='password']"), $("#js-passwordsContainsUserName").val());
    }
    else if (result == 2)
    {
        addErrorToField($(form + " input[name='password']"), $("#js-passwordsBadLength").val());
    }
    else
    {
        addErrorToField($(form + " input[name='password']"),
            $("#js-passwordsInvalid").val() + "\n" +
            $("#js-passwordsLine2").val() + "\n" +
            $("#js-passwordsLine3").val() + "\n" +
            $("#js-passwordsLine4").val() + "\n" + "\t" +
            $("#js-passwordsLine4-1").val() + "\n" + "\t" +
            $("#js-passwordsLine4-2").val() + "\n" + "\t" +
            $("#js-passwordsLine4-3").val());
    }
}

function isEmptyParam(data, param, form) {
    var emailsIndex = 0;
    var returnValue = false;

    var allParams = data.split("&");
    for (var i = 0; i < allParams.length; i++) {
        var cur = allParams[i].split("=");
        if (cur[0] == param) {
            if (!cur[1]) {
                returnValue = true;
                // set the error on the email index that is empty
                addErrorToField( $(form + " input[name='emails']")[emailsIndex], $("#js-emailNotEmpty").val());
            }
            emailsIndex++;
        }
    }

    return returnValue;
}