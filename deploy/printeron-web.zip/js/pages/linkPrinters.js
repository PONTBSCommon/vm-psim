$(document).ready(function () {
    $("#linkPrintersDialog").on('hidden.bs.modal', function () {
        clearLinkedPrinters();
    });
});

function startServerSpinner () {
    $("#linkedPrintersServerWrapper").hide();
    startSpinner("#linkedPrintersServerSpinner");
}

function stopServerSpinner () {
    stopSpinner("#linkedPrintersServerSpinner");
    $("#linkedPrintersServerWrapper").show();
}

function startLinkedPrintersSpinner () {
    $("#ponServer").attr("disabled", true);
    $("#linkPrintersSubmit").attr("disabled", true);
    $("#linkedPrintersWrapper").hide();
    startSpinner("#linkedPrintersSpinner");
}

function stopLinkedPrintersSpinner () {
    $("#ponServer").attr("disabled", false);
    $("#linkPrintersSubmit").attr("disabled", false);
    stopSpinner("#linkedPrintersSpinner");
    $("#linkedPrintersWrapper").show();
}

function getLinkedPrintersSection () {
    startServerSpinner();
    $("#linkPrintersDialog").modal("show");
    ajax({
        url: CONTEXT + "/printer/link/getAll",
        method: "GET",
        success: function (data) {
            fillLinkedPrintersSection(data);
            stopServerSpinner();
            getLinkedPrinters();
            $("#ponServer").change(getLinkedPrinters);
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
            $("#linkPrintersDialog").modal("hide");
        }
    });
}

function getLinkedPrinters () {
    startLinkedPrintersSpinner();

    // Get the printer classes
    var classes = $("#pagePrinterClass").val();

    // Strip out the []
    classes = classes.substring(1, classes.length - 1);

    ajax({
        url: CONTEXT + "/printer/link",
        method: "GET",

        success: function (data) {

            fillLinkedPrinters(data, $("#ponServer").val(), classes);

            $("#printerClassesInput").val(classes);

            useAjaxForForm("#linkPrintersForm", {

                beforeSend: function(){

                    startSpinnerOnButton("#linkPrintersSubmit");

                },

                success: function (resp) {

                    if (resp != null && resp != "") {

                        notifySuccess(resp);

                        stopSpinnerOnButton("#linkPrintersSubmit");

                        $("#linkPrintersDialog").modal("hide");

                        // Reload the current page of the printers table
                        dtUnloadUUID('#printerTable');
                        dtRedraw(false, '#printerTable');
                    }
                }
            });

        },
        error: function (xhr) {
            notifyError(xhr.responseText);

            stopSpinnerOnButton("#linkPrintersSubmit");

            $("#linkPrintersDialog").modal("hide");
        }
    })
}

function fillLinkedPrinters (data, server, classes) {
    clearLinkedPrinters();

    $("#linkedPrintersWrapper").html(data);
    linkedDataTables({
        "#availablePrinters":{
            ajax: {
                url: CONTEXT + "/printer/link/available",
                complete: stopLinkedPrintersSpinner
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ],
            "fnServerParams": function ( aoData ) {
                aoData = $.extend(true, aoData, {
                    "server": server,
                    "printerClasses": classes
                });
            }
        },
        "#linkedPrinters":{
            ajax: {
                url: CONTEXT + "/printer/link/linked",
                complete: stopLinkedPrintersSpinner
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ],
            "fnServerParams": function ( aoData ) {
                aoData = $.extend(true, aoData, {
                    "server": server,
                    "printerClasses": classes
                });
            },
            "form": "#linkPrintersForm"
        }
    });
}

function clearLinkedPrinters () {
    dtDestroy("#availablePrinters");
    dtDestroy("#linkedPrinters");
}

function fillLinkedPrintersSection (data) {
    clearLinkedPrintersSection();

    for (var key in data) {
        if (key == "servers") {
            var serverHTML = "<select class='form-control' id='ponServer' name='ponServer'>";

            for (var server in data[key]) {
                serverHTML += "<option value='" + data[key][server].serialNum + "'>" + data[key][server].label + "</option>";
            }
            serverHTML += "</select>";

            $("#linkedPrintersServerWrapper").html(serverHTML);
        }
        else if (key == "printers") {
            var printerHTML = "";

            for (var printer in data[key]) {
                printerHTML += "<div class='col-md-6'>";
                printerHTML += "<input type='checkbox' name='linkedPrinters' id='linkedPrinters-" + data[key][printer].id + "' value='" + data[key][printer].id + "'/>";
                printerHTML += "<label for='linkedPrinters-" + data[key][printer].id + "'>" + data[key][printer].label + "</label>";
                printerHTML += "</div>";
            }

            $("#linkedPrintersWrapper").html(printerHTML);
        }
    }
}

function clearLinkedPrintersSection () {
    $("#linkedPrintersServerWrapper").html("");
    $("#linkedPrintersWrapper").html("");
}