$(document).ready(function () {
    if ($("#convertEnd").val() == "true") {
        var endDate = $("#endDate");
        var d = new Date(0);
        d.setUTCSeconds(endDate.html());
        endDate.html(d.toLocaleDateString());
    }

    $("#logDownloadButton").click(function () {
        var newwindow = window.open(CONTEXT + "/logs/downloading", 'Download Support Package', "height=150,width=500px");
        if (window.focus) {newwindow.focus()}
        return false;
    })
});