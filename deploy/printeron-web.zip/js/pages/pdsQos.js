$(function (){disablePanel();});

function disablePanel(){
    if($('#enableQos').is(':checked')) {
        $('#settingsPanel :input').removeAttr('disabled');
    }else{
        $('#settingsPanel :input').attr('disabled', true);
    }

}