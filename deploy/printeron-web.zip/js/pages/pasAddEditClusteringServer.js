/**
 * Created by bershaa on 1/21/2015.
 */


function showLoading(){
    $("#spinner").show();
    $("#addEditPanel").hide();
}

