/**
 * JQuery DataTable helper methods.
 *
 * @author Lukas Rezek <lrezek@printeron.com>
 */

/** Private table list. */
var _dtTables = [];

/** Object to hold what rows are selected on each table */
var _dtSelectedRows = {};
/** Object to hold which row was last selected on a table */
var _dtCurrentlySelectedRow = {};

/** Object to keep track of each table's UUID */
var _dtUUIDs = {};

/** Map of filter name -> index. */
var _filters = {};

/** Variable to keep track of which table a drag 'n drop action originated from */
var _dtDragNDropStart = "";

/** Variable to keep track of the ctrl key being held */
var _ctrlHeld = false;

/** Variable to keep track of the shift key being held. */
var _shiftHeld = false;

/** Variable to keep a mapping to help serialize a dataTable for a form */
var _dtFormMap = {};

/** Weather to skip the window unload. Will be set to true if the unloading ajax call fails to prevent loops */
var _skipUnload = false;

/** Variable to hold the current page change timeout */
var _changePageTimeout;

/** The time it takes to go from hovering over an arrow to changing the page */
var _currentChangePageTimeoutValue = 1000;

/** SVG arrow overlay to be used to change pages while moving rows in a dataTable */
var _arrowOverlay =
    "<svg class='datatables-dragndrop-nav-wrapper' width='100%' height='100%' version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">" +
        "<defs>" +
            "<radialGradient id=\"GradientPad\" cx=\"0.5\" cy=\"0.5\" r=\"0.5\" fx=\"0.5\" fy=\"0.5\" spreadMethod=\"pad\">" +
                "<stop offset=\"0%\" stop-color=\"white\"></stop>" +
                "<stop offset=\"100%\" stop-color=\"#00aeef\"></stop>" +
            "</radialGradient>" +
        "</defs>" +
        "<svg width='25%' height='100%' x='0' class=\"datatables-dragndrop-nav dataTables-arrow-left-wrapper\">" +
            "<g class='datatables-arrow datatables-arrow-left-double'>" +
                "<svg x='0' preserveAspectRatio='none' width='50%' viewBox='0 0 100 400'>" +
                    "<rect x=\"0\" y=\"0\" fill=\"url(#GradientPad)\" width=\"100\" height=\"400\"></rect>" +
                "</svg>" +
                "<svg x='5%' y='0' width='40%' class='' viewBox='0 0 100 200'>" +
                    "<polygon stroke-linejoin=\"bevel\" points=\"100,0 0,100 100,200 100,190 10,100 100,10 100,0\"/>" +
                    "<polygon stroke-linejoin=\"bevel\" points=\"100,20 20,100 100,180 100,170 30,100 100,30 100,20\"/>" +
                "</svg>" +
            "</g>" +
            "<g class='datatables-arrow datatables-arrow-left-single'>" +
                "<svg x='50%' preserveAspectRatio='none' width='50%' viewBox='0 0 100 400'>" +
                    "<rect x=\"0\" y=\"0\" fill=\"url(#GradientPad)\" width=\"100\" height=\"400\"></rect>" +
                "</svg>" +
                "<svg x='55%' y='0' width='40%' class='' viewBox='0 0 100 200'>" +
                    "<polygon stroke-linejoin=\"bevel\" points=\"100,0 0,100 100,200 100,190 10,100 100,10 100,0\"/>" +
                "</svg>" +
            "</g>" +
        "</svg>" +

        "<svg width='25%' height='100%' x='75%' class=\"datatables-dragndrop-nav dataTables-arrow-right-wrapper\">" +
            "<g class='datatables-arrow datatables-arrow-right-single'>" +
                "<svg x='0' width='50%' preserveAspectRatio='none' viewBox='0 0 100 400'>"  +
                    "<rect x=\"0\" y=\"0\" fill=\"url(#GradientPad)\" width=\"100\" height=\"400\"></rect>" +
                "</svg>" +
                "<svg x='5%' y='0' width='40%' viewBox='0 0 100 200'>" +
                    "<polygon stroke-linejoin=\"bevel\" points=\"0,0 100,100 0,200 0,190 90,100 0,10 0,0\"/>" +
                "</svg>" +
            "</g>" +
            "<g class='datatables-arrow datatables-arrow-right-double'>" +
                "<svg x='50%' preserveAspectRatio='none' width='50%' viewBox='0 0 100 400'>" +
                    "<rect x=\"0\" y=\"0\" fill=\"url(#GradientPad)\" width=\"100\" height=\"400\"></rect>" +
                "</svg>" +
                "<svg x='55%' y='0' width='40%' viewBox='0 0 100 200'>" +
                    "<polygon stroke-linejoin=\"bevel\" points=\"0,0 100,100 0,200 0,190 90,100 0,10 0,0\"/>" +
                    "<polygon stroke-linejoin=\"bevel\" points=\"0,20 80,100 0,180 0,170 70,100 0,30 0,20\"/>" +
                "</svg>" +
            "</g>" +
        "</svg>" +
    "</svg>" ;

/**
 * When the window is "unloaded" (refreshed, closed, navigated away, etc)
 * send an AJAX request to the backend to remove all the DataTableModels that were used on this page.
 */
$(document).ready(function () {
    $(window).on("beforeunload", function () {
        if (!_skipUnload) {
            // When the window is unloaded, send a message to the backend to unload the dataTables
            var uuids = [];

            for (var id in _dtUUIDs) {
                uuids.push(_dtUUIDs[id]);
            }

            if (uuids.length) {
                ajax({
                    url: CONTEXT + "/unloadDataTableModel",
                    data: {"uuids": uuids},
                    method: "POST",
                    error: function () {
                        // Make sure we don't get in a loop of trying to send the unload
                        _skipUnload = true;
                    }
                });
            }
        }
    });
});

/**
 * Four events to handle changing pages within the dataTable
 */
$(document).on('mouseenter', ".datatables-arrow-right-single", function () {
    $(this)[0].classList.add("darker");
    var table = $(this).parents(".row").first().find(".dataTable");
    _changePageTimeout = setTimeout(function () {
        table.one("draw.dt", function() {_bindMouseEvents(table)});

        _currentChangePageTimeoutValue = _currentChangePageTimeoutValue/2;
        $(".datatables-arrow-right-single")[0].classList.remove("darker");

        dtNextPage(table);
    }, _currentChangePageTimeoutValue)
});
$(document).on('mouseenter', ".datatables-arrow-left-single", function () {
    $(this)[0].classList.add("darker");
    var table = $(this).parents(".row").first().find(".dataTable");
    _changePageTimeout = setTimeout(function () {
        table.one("draw.dt", function() {_bindMouseEvents(table)});

        _currentChangePageTimeoutValue = _currentChangePageTimeoutValue/2;
        $(".datatables-arrow-left-single")[0].classList.remove("darker");

        dtPreviousPage(table);
    }, _currentChangePageTimeoutValue)
});
$(document).on('mouseenter', ".datatables-arrow-left-double", function () {
    $(this)[0].classList.add("darker");
    var table = $(this).parents(".row").first().find(".dataTable");
    _changePageTimeout = setTimeout(function () {
        table.one("draw.dt", function() {_bindMouseEvents(table)});

        _currentChangePageTimeoutValue = _currentChangePageTimeoutValue/2;
        $(".datatables-arrow-left-double")[0].classList.remove("darker");

        dtFirstPage(table);
    }, _currentChangePageTimeoutValue)
});
$(document).on('mouseenter', ".datatables-arrow-right-double", function () {
    $(this)[0].classList.add("darker");
    var table = $(this).parents(".row").first().find(".dataTable");
    _changePageTimeout = setTimeout(function () {
        table.one("draw.dt", function() {_bindMouseEvents(table)});

        _currentChangePageTimeoutValue = _currentChangePageTimeoutValue/2;
        $(".datatables-arrow-right-double")[0].classList.remove("darker");

        dtLastPage(table);
    }, _currentChangePageTimeoutValue)
});

/**
 * Function to disable the change page timeout when the mouse leaves the arrow
 */
$(document).on('mouseleave', ".datatables-arrow-right-single, .datatables-arrow-left-single, .datatables-arrow-left-double, .datatables-arrow-right-double", function () {
    $(this)[0].classList.remove("darker");
    clearTimeout(_changePageTimeout);
    _currentChangePageTimeoutValue = 1000;
});

/**
 * Switch to the next page
 *
 * @param table The dataTable
 */
function dtNextPage (table) {
    table = $(table);
    table.DataTable().page('next').draw(false);
}

/**
 * Switch to the previous page
 *
 * @param table The dataTable
 */
function dtPreviousPage (table) {
    table = $(table);
    table.DataTable().page('previous').draw(false);
}

/**
 * Switch to the first page
 *
 * @param table The datatable
 */
function dtFirstPage (table) {
    table = $(table);
    table.DataTable().page('first').draw(false);
}

/**
 * Switch to the last page
 *
 * @param table The dataTable
 */
function dtLastPage (table) {
    table = $(table);
    table.DataTable().page('last').draw(false);
}

/**
 * Removes a UUID from the local map, and sends an AJAX request to the server to delete anything associated with the UUID
 *
 * @param table The dataTable
 */
function dtUnloadUUID (table) {
    table = $(table);

    if (typeof _dtUUIDs[table.attr("id")] !== "undefined") {
        ajax({
            url: CONTEXT + "/unloadDataTableModel",
            data: {"uuids": _dtUUIDs[table.attr("id")]},
            method: "POST"
        });

        delete _dtUUIDs[table.attr("id")];
    }
}

/**
 * Initializes a datatable.
 *
 * Current custom "plugins" supported:
 *
 *      selectableRows: allows rows in the dataTable to be selected. This helper keeps track of the indexes of any rows
 *                      that are selected so they can be conveniently accessed later when an action on these rows is done
 *
 *      multiSelectRows: when this is true, and selectableRows is also true, allows the user to select multiple rows at once
 *
 *      moveableRows: when this is true, rows inside of the dataTable can be dragged and re-ordered. Setting this to true
 *                      will force selectableRows to true as it needs the functionality to work.
 *
 *      form: when this is set, any column that is properly marked will have its value(s) inserted as hidden inputs in the
 *            specified form. This can be instantiated purely through data attributes in HTML, or through a mix of data attributes and js
 *
 *      linkedDataTables: supported, but must be initialized using the linkedDatatables function. Supports an arbitrary amount of tables
 *
 *      childRow: When a button inside of the dataTable has the attribute data-controls='childRow' it will bind an event
 *                  for that button so that when it is clicked, it will look in the same row for an element with the class .dataTable-childRow and reveal it
 *
 * All plugins support server side paging/loading. Everything but moveableRows also support client side paging
 *
 * TODO: Make these plugins actual DataTables plugins
 *
 * @param table The table to initialize (selector or jquery object)
 * @param extraParams Extra initialization parameters (optional).
 */
function dtLoad(table, extraParams) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // Initialize the datatable localization variables
    var dtLengthMenu = $('#dtLengthMenu').val().replace('%1', '_MENU_');
    var dtZeroRecords = $('#dtZeroRecords').val();
    var dtInfo = $('#dtInfo').val().replace('%1', '_START_').replace('%2', '_END_').replace('%3', "_TOTAL_");
    var dtInfoEmpty = $('#dtInfoEmpty').val();
    var dtInfoFiltered = $('#dtInfoFiltered').val().replace('%1', '_MAX_');
    var dtPrevious = $("#dtPrevious").val();
    var dtNext = $("#dtNext").val();
    var dtSearch = $("#dtSearch").val();
    var enableSelectableRows = false;
    var enableMultiSelectRows = false;
    var createFormInputsFromParams = false;
    var createFormInputsFromData = false;
    var enableMoveableRows = false;

    // Initialize parameters object with default parameters
    var params = {
        language: {
            lengthMenu: dtLengthMenu,
            zeroRecords: dtZeroRecords,
            info: dtInfo,
            infoEmpty: dtInfoEmpty,
            infoFiltered: dtInfoFiltered,
            search: dtSearch,
            paginate: {
                "previous": dtPrevious,
                "next": dtNext
            }
        },
        aoColumnDefs: [
            {bSearchable:false, aTargets:"unsearchable"},
            {bSortable:false, aTargets:"unsortable"},
            {bVisible:false, aTargets:"hiddenColumn"},
            {sSortDataType:"dom-checkbox", aTargets: "sortableCheckbox"} //to order by checkbox checked
        ],
        bAutoWidth: false,
        aaSorting: []
    };

    params = $.extend(true, params, extraParams);

    // If options were supplied, copy them to params
    if(extraParams) {

        if (extraParams.hasOwnProperty("moveableRows")) {
            enableMoveableRows = extraParams.moveableRows;

            // If we have moveableRows, then we need to guarentee we have selectableRows as well
            params.selectableRows = true;
            extraParams.selectableRows = true;

            // We also need to make sure that the columns are not sortable
            table.find("thead").find("th").addClass("unsortable");
        }
        if (extraParams.hasOwnProperty("selectableRows")) {
            enableSelectableRows = extraParams.selectableRows;
        }
        if (extraParams.hasOwnProperty("multiSelectRows")) {
            enableMultiSelectRows = extraParams.multiSelectRows;
        }
        if (extraParams.hasOwnProperty("form")) {
            createFormInputsFromParams = true;
        }


        if (extraParams.hasOwnProperty("ajax")) {

            // Make sure the table's UUID is added to the request
            params.ajax.beforeSend = function (xhr, settings) {
                if (typeof _dtUUIDs[table.attr("id")] !== "undefined") {
                    if (settings.type == "GET") {
                        settings.url += "&tableUUID=" + _dtUUIDs[table.attr("id")];
                    }
                    else {
                        if (typeof settings.data == "undefined") {
                            settings.data = {"tableUUID": _dtUUIDs[table.attr("id")]};
                        }
                        else {
                            settings.data = $.extend(settings.data, {"tableUUID": _dtUUIDs[table.attr("id")]});
                        }
                    }
                }

                if (extraParams.ajax.hasOwnProperty("beforeSend")) {
                    extraParams.ajax.beforeSend(xhr, settings);
                }
            };

            // After dataTables is loaded, store the UUID that is sent back
            params.ajax.complete = function (xhr, status) {
                var data = $.parseJSON(xhr.responseText);

                if (typeof data.tableUUID !== "undefined") {
                    _dtUUIDs[table.attr("id")] = data.tableUUID;
                }

                if (extraParams.ajax.hasOwnProperty("complete")) {
                    extraParams.ajax.complete(xhr, status);
                }

                table.trigger("dt.ajax.complete");
            };
        }
    }

    // Initialize the datatable
    var tableToReturn = table.DataTable(params);

    // Add table to tables array
    _dtTables.push(table);

    // Bind event for opening a child row
    // Bind the events on a "draw" event so that the events work with ajax loading
    $(table).on("draw.dt", function () {
        $(this).DataTable().rows().nodes().to$().find("[data-controls='childRow']").on("click", function () {
            var row = $(this).parents("tr");
            var childRow = row.find(".dataTable-childRow");
            var table = row.parents("table");
            var dtRow = table.DataTable().row(row);

            if (dtRow.child.isShown()) {
                $('div.dtSlider', dtRow.child()).slideUp( function () {
                    dtRow.child.hide();
                    row.removeClass("dataTable-parentRow");
                    row.removeClass("shown");
                } );
            }
            else {
                dtRow.child("<div class='dtSlider dtChildRow'>" + $(childRow)[0].outerHTML + "</div>").show();
                dtRow.child().find(".dataTable-childRow").removeClass("dataTable-childRow");
                dtRow.child().addClass("dataTable-childRow-visible");
                row.addClass("dataTable-parentRow");
                row.addClass("shown");
                $('div.dtSlider', dtRow.child()).slideDown();
            }

            return false;
        });
    });

    // Grab input map from parameters if necessary
    if (createFormInputsFromParams) {
        _dtFormMap[table.attr("id")] = extraParams["form"];
    }

    // Grab input map from data attributes if necessary
    if (table.find("[data-form]").length) {
        table.find("[data-form]").each(function () {
            var params = {};
            var formName = $(this).data("form");
            var table = $(this).parents("table").attr("id");

            params[table] = {};
            params[table][formName] = {};
            params[table][formName][$(this).data("input")] = $(this).parents("table").DataTable().column($(this)).index();

            $.extend(true, _dtFormMap, params);
        });

        createFormInputsFromData = true;
    }

    // Create form inputs and bind event for input refresh
    if (createFormInputsFromData || createFormInputsFromParams) {
        _createFormInputs(table);

        table.on("draw.dt", function () {
            _removeFormInputs($(this));
            _createFormInputs($(this));
        });

        // Ajax complete happens after a draw, so to make sure the form inputs initialize properly,
        // we set a one time input creation on the ajax complete event
        if (table.DataTable().ajax !== null) {
            table.one("dt.ajax.complete", function () {
                _removeFormInputs($(this));
                _createFormInputs($(this));
            });
        }
    }

    if (enableSelectableRows) {
        _dtSelectedRows[table.attr("id")] = {};

        // If multi row select is enabled, keep track of if ctrl or shift is held
        if (enableMultiSelectRows) {
            $(document)
                .keydown(function (e) {
                    _ctrlHeld = e.ctrlKey;
                    _shiftHeld = e.shiftKey;
                })
                .keyup(function (e) {
                    _ctrlHeld = e.ctrlKey;
                    _shiftHeld = e.shiftKey;
                });
        }

        // Bind select events
        if (typeof extraParams !== "undefined" && typeof extraParams.ajax !== "undefined") {
            $(table).on("draw.dt", function () {
                var selectedRows = _dtSelectedRows[table.attr("id")];

                var dt = $(this).DataTable();
                var pageLength = dt.page.info().length;
                var offset = dt.page.info().page * pageLength;
                for (var i = offset; i < offset + pageLength; i++) {
                    if (typeof selectedRows[i] !== "undefined") {
                        dt.row(i - offset, {page: "current"}).nodes().to$().addClass("selected");
                    }
                }

                // Make sure we don't bind the event twice
                table.DataTable().rows().nodes().to$().off('click', _handleRowSelection);
                // Bind the click event
                table.DataTable().rows().nodes().to$().on('click', _handleRowSelection);

                if (enableMoveableRows) {
                    table.DataTable().rows().nodes().to$().off("mousedown", _startMoveableRows);
                    table.DataTable().rows().nodes().to$().on("mousedown", _startMoveableRows);
                }
            });
        }
        else {
            $(table).on("draw.dt", function () {
                var selectedRows = _dtSelectedRows[table.attr("id")];

                var dt = $(this).DataTable();
                var pageLength = dt.page.info().length;
                var offset = dt.page.info().page * pageLength;
                for (var i = offset; i < offset + pageLength; i++) {
                    if (typeof selectedRows[i] !== "undefined") {
                        dt.row(i, {search: "applied"}).nodes().to$().addClass("selected");
                    }
                }
            });

            table.DataTable().rows().nodes().to$().on('click', _handleRowSelection);
            $("body").on("mouseup", _reenableTextSelect);

            // Bind the click event
            if (enableMoveableRows) {
                table.DataTable().rows().nodes().to$().off("mousedown", _startMoveableRows);
                table.DataTable().rows().nodes().to$().on("mousedown", _startMoveableRows);
            }
        }
    }

    if (enableMoveableRows) {
        //table.parents(".row").append(_arrowOverlay);
        table.parents(".row").first().append(_arrowOverlay);

        $(table).one("draw.dt", function () {
            $(window).resize(function () {
                _dtResizeOverlay(table.parents(".row").first().find(".datatables-dragndrop-nav-wrapper"));
            });
        });
        $(table).on("draw.dt", function () {
            _dtResizeOverlay(table.parents(".row").first().find(".datatables-dragndrop-nav-wrapper"));

            var pageInfo = table.DataTable().page.info();
            var leftWrapper = $(".dataTables-arrow-left-wrapper");
            var rightWrapper = $(".dataTables-arrow-right-wrapper");

            if (pageInfo.page > 0) {
                leftWrapper.show();
            }
            else {
                leftWrapper.hide();
            }

            if ((pageInfo.page + 1) >= pageInfo.pages) {
                rightWrapper.hide();
            }
            else {
                rightWrapper.show();
            }
        })
    }

    return tableToReturn;
}

function _dtResizeOverlay(overlay) {
    overlay = $(overlay);

    var table = overlay.parents("div").first().find("table");
    var tbody = table.find("tbody");
    var thead = table.find("thead");
    var height = tbody.height();
    var width = tbody.width();
    var offset = thead.offset().top + thead.height();
    var leftOffset = thead.offset().left;

    overlay.css("height", height + "px");
    overlay.css("width", width + "px");
    overlay.css("top", offset + "px");
    overlay.css("left", leftOffset + "px");
}

/**
 * Reverts the datatable back to a table, preserving it in the DOM.
 *
 * @param table The table (optional).
 */
function dtUnload(table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table, suppress logs if a table isn't found
        table = _dtCheckForTable(true);

        // Still not found
        if(!table) {
            return;
        }
    }

    _dtDestroy(table, false);
}

/**
 * Destroys the datatable, removing it from the DOM
 *
 * @param table The table (optional).
 */
function dtDestroy(table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    var jtable = $(table);

    // They didn't supply a table
    if(typeof table === "undefined") {

        // Get the right table, suppress logs if a table isn't found
        jtable = _dtCheckForTable(true);

        // Still not found
        if(!jtable) {
            return;
        }
    }

    _dtDestroy(jtable, true);
}

/**
 * Redraws the table.
 *
 * @param resetPage Whether to reset the page you're on to page 1 (optional).
 * @param table The table (optional).
 */
function dtRedraw(resetPage, table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // By default, don't reset the page
    if(typeof resetPage === 'undefined') {
        resetPage = false;
    }

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return;
        }
    }

    // Redraw without a page reset
    _dtRedraw(table, resetPage);
}

/**
 * Gets all the rows in the datable, with caching.
 *
 * @param table The table to get rows for (optional).
 * @return Array The array of all rows.
 */
function dtGetAllRows(table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return [];
        }
    }

    return table.dataTable().$("tr");
}

/**
 * Removes a row.
 *
 * @param row Row to remove.
 * @param table The table (optional).
 */
function dtRemoveRow(row, table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return false;
        }
    }

    // Remove it from the table
    table.DataTable().row(row).remove();

    return true;
}

/**
 * Gets the row by the specified selector.
 *
 * @param selector Selector to use.
 * @param table The table (optional).
 */
function dtQueryRows(selector, table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    return dtGetAllRows(table).find(selector);
}

/**
 * Gets rows based on a selector.
 *
 * @param selector The selector.
 * @param table The table (optional).
 * @returns {*} List of rows, or null.
 */
function dtGetRows(selector, table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    return dtGetAllRows(table).filter(selector);
}

/**
 * Gets the row with the specified ID.
 *
 * @param id The row ID.
 * @param table The table (optional).
 */
function dtGetRowById(id, table) {

    return dtGetRows("#" + id, table);
}

/**
 * Gets the row count for the table.
 *
 * @param table The table.
 * @returns {*} Null if table isn't found, length otherwise.
 */
function dtGetRowCount(table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    return dtGetAllRows(table).length;
}

/**
 * Attaches a filter to the datatable.
 *
 * Filter methods must be functions that have settings, data, and dataIndex parameters. Returning true in this function
 * will keep the row in the result set, false will remove it.
 *
 * @param filter The filter method.
 * @param filterName The filter name (optional, this will replace an existing filter).
 */
function dtAttachFilter(filter, filterName) {

    // Filter name supplied
    if(filterName) {

        // We have an index for this filter
        if(_filters.hasOwnProperty(filterName)) {

            // Replace the existing filter
            $.fn.dataTable.ext.search[_filters[filterName]] = filter;

        // No index for this filter, push it on and store it
        } else {

            $.fn.dataTable.ext.search.push(filter);

            _filters[filterName] = $.fn.dataTable.ext.search.length - 1;
        }

    // No filter name, generate one based on the index
    } else {

        // Push it on
        $.fn.dataTable.ext.search.push(filter);

        var index = $.fn.dataTable.ext.search.length - 1;

        // Save the filters index
        filterName = "filter." + index;
        _filters[filterName] = index;
    }

    return filterName;
}

/**
 * Removes a filter, based on the filter name.
 *
 * @param filterName The filter name.
 */
function dtDetachFilter(filterName) {

    // Get the index stored in the filters map
    var index = _filters[filterName];

    // Existing filter
    if(_filters.hasOwnProperty(filterName)) {

        // Splice out the filter
        $.fn.dataTable.ext.search.splice(index, 1);

        // Loop though filters and decrement their indexes if they're higher than the removed filter
        for(var prop in _filters) {
            if(_filters[prop] > index) {
                _filters[prop]--;
            }
        }

        // Remove the filter mapping
        delete _filters[filterName];
    }
}

/**
 * Applies filters on the supplied table.
 *
 * @param table
 * @returns {null}
 */
function dtApplyFilters(table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    // Redraw with a page reset
    _dtRedraw(table, true);
}

/**
 * Clears the specified table.
 *
 * @param table The table (optional, it will pick the first if there is only 1).
 * @returns {null}
 */
function dtClear(table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    _removeFormInputs(table);
    dtResetSelectedRows(table);
    dtUnloadUUID(table);
    table.dataTable().fnClearTable();
}

/**
 * Sets the datatable error mode.
 *
 * @param mode The requested mode.
 */
function dtErrorMode(mode) {

    $.fn.dataTableExt.sErrMode = mode;
}

/**
 * Adds a row to the specified data table
 *
 * @param row The row to be added. Can be an array or an HTML string
 * @param table The table to add to (optional)
 * @returns The node of the row that was just created
 */
function dtAddRow(row, table)
{
    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    var t = table.DataTable();

    if (row.constructor === Array) {
        return t.row.add(row).draw().node();
    }
    else {
        return t.row.add($(row)).draw().node();
    }
}

/**
 * Resets the table to page 1.
 *
 * @param table The table to reset.
 */
function dtResetPage (table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    var t = table.DataTable();

    t.page(0).draw(false);
}

/**
 * Get the jquery objects for all the rows that are currently selected in a table
 *
 * @param table The dataTable
 * @returns {*} The jquery object
 */
function dtGetSelectedRows (table) {

    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    return table.DataTable().rows(Object.keys(_dtSelectedRows[table.attr("id")])).nodes().to$();
}

/**
 * Clears all the selected rows on a table
 *
 * @param table The dataTable
 * @returns {null}
 */
function dtResetSelectedRows (table) {
    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    _dtSelectedRows[table.attr("id")] = {};
    delete _dtCurrentlySelectedRow[table.attr("id")];
}

/**
 * Gets all the table parameters associated with a dataTable for use in AJAX requests
 *
 * @param table The dataTable
 * @returns {*} json object with all the parameters
 */
function dtGetTableParamsForAjax (table) {
    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    var data = {
        "selectedIndexes" : dtGetSelectedRowIndexes(table),
        "tableUUID" : typeof _dtUUIDs[table.attr("id")] === "undefined" ? null : _dtUUIDs[table.attr("id")]
    };
    $.extend(data, table.DataTable().ajax.params());

    return data;
}

/**
 * Gets the indexes of all the selected rows of a table
 *
 * @param table The dataTable
 * @returns {*} Array of indexes
 */
function dtGetSelectedRowIndexes (table) {
    // Wrap in jquery object so you can use this with a selector or jquery object
    table = $(table);

    // They didn't supply a table
    if(table.length == 0) {

        // Get the right table
        table = _dtCheckForTable();

        // Still not found
        if(!table) {
            return null;
        }
    }

    var selectedRows = _dtSelectedRows[table.attr("id")];

    if (typeof selectedRows === "undefined") {
        return {};
    }
    else {
        return Object.keys(selectedRows);
    }
}

/**
 * Helper function to create multiple dataTables as well as all the necessary events to
 * move rows back and forth between them
 *
 *
 * You can define a button to initiate a row movement (in HTML) using the following data attributes:
 *
 * data-controls='moveRows' - indicates a button is responsible for initiating row movement
 * data-from='{selector}' - indicates that the rows to be moved come from the {selector} table
 * data-to='{selector}' - indicates that the rows to be moved go to the {selector} table
 *
 * @param tables JSON with keys being the tables to link, and the values being dataTable options
 */
function linkedDataTables (tables)
{
    var numColumns = -1;

    // Create all the data tables
    for (var i in tables) {
        var params;
        if (typeof tables[i] === "undefined") {
            params = {};
        }
        else {
            params = tables[i];
        }

        params = $.extend(true, {selectableRows : true, multiSelectRows: true}, params);

        $(i).on("draw.dt", function () {
            var wrapper = $(this).parents(".dataTables_wrapper");
            wrapper.find(".dataTables_length").parent(".col-md-6").removeClass("col-md-6").addClass("col-linkedDataTables-UI");
            wrapper.find(".dataTables_filter").parent(".col-md-6").removeClass("col-md-6").addClass("col-linkedDataTables-UI");
            wrapper.find(".dataTables_paginate").parent(".col-sm-6").removeClass("col-sm-6").addClass("col-linkedDataTables-UI");
            wrapper.find(".dataTables_info").parent(".col-sm-6").removeClass("col-sm-6").addClass("col-linkedDataTables-UI");
        });

        dtLoad(i, params);

        // Set up drag 'n drop events
        $(i).mousedown(function () {
            // Change the cursor to indicate movement
            $('body').css("cursor", "move");

            _dtDragNDropStart = $(this);
            return false;
        });

        $(i).mouseup(function () {
            // Change the cursor back
            $('body').css("cursor", "default");

            if (_dtDragNDropStart !== "" && _dtDragNDropStart.attr("id") != $(this).attr("id")) {
                _moveSelectedRows(_dtDragNDropStart, $(this));
            }

            $("table.table-glow").removeClass("table-glow");

            _dtDragNDropStart = "";
        });

        $(i).mouseenter(function () {
            if (_dtDragNDropStart != "" && _dtDragNDropStart.attr("id") != $(this).attr("id")) {
                $(this).addClass("table-glow");
            }
        });

        $(i).mouseleave(function () {
            $(this).removeClass("table-glow");
        });

        // Check if the tables have the same length, if they don't log a warning
        if (numColumns == -1) {
            numColumns = $(i).find("thead th").length;
        }
        else if (numColumns != $(i).find("thead th").length) {
            console.log("For linkedDataTables to work properly, all the supplied tables must have the same amount of columns");
        }
    }

    // Create events for passing rows around
    for (var firstId in tables) {
        for (var secondId in tables) {
            if (firstId !== secondId) {
                $(document).on(firstId + "-to-" + secondId, function (event) {
                    var eventType = event.type;
                    var eventParts = eventType.split("-");
                    _moveSelectedRows(eventParts[0], eventParts[2]);
                });
            }
        }
    }

    // Bind an event to clear the drag n' drop start point when it is not released on a table
    $('body').not("table").mouseup(function () {
        // Change the cursor back
        $('body').css("cursor", "default");

        $("table.table-glow").removeClass("table-glow");

        _dtDragNDropStart = "";
    });

    // Bind _moveSelectedRows to any buttons set up to do so
    $("button[data-controls='moveRows']").each(function () {
        $(this).click(function () {
            _moveSelectedRows($(this).data('from'), $(this).data('to'));
            $(this).blur();
        });
    });

    // Bind _moveAlRows to any buttons set up to do so
    $("a[data-controls='moveAllRows']").each(function () {
        $(this).click(function () {
            _moveAllRows($(this).data('from'), $(this).data('to'));
            $(this).blur();
        });
    });
}

/**
 * Gets the index of the row specified by a jQuery selector
 *
 * @param row The row selector to get the index of
 * @returns {*} The index
 */
function dtGetRowIndex (row) {
    row = $(row);

    var table = row.parents("table").first();

    var index = table.DataTable().row(row).index();

    var offset = table.DataTable().page.info().page * table.DataTable().page.info().length;

    // Ajax loaded tables won't have the offset applied already
    if (index < offset) {
        index += offset;
    }

    return index;
}

/**
 * Gets the UUID associated with a dataTable
 *
 * @param table The table to get the UUID of
 * @returns {*} The UUID
 */
function dtGetUUID (table) {
    table = $(table);

    return _dtUUIDs[table.attr("id")];
}

/**
 * Checks if a table exists, so you can apply operations to it without requiring a specified one.
 *
 * @param silentWhenEmpty Flag to prevent logging if a datatable isn't found.
 * @return Table or null.
 * @private
 */
function _dtCheckForTable(silentWhenEmpty) {

    // There's only 1 table
    if( _dtTables.length == 1) {

        return _dtTables[0];

        // More than 1 option
    } else if(_dtTables.length > 1){

        console.log("Please specify a table.");

        return null;

    } else if(_dtTables.length == 0) {

        if(!silentWhenEmpty) {
            console.log("No datatables found, please initialize one.");
        }

        return null;
    }
}

/**
 * Redraws a table.
 *
 * @param table The table.
 * @param resetPage Whether to reset the current page.
 * @private
 */
function _dtRedraw(table, resetPage) {

    table.DataTable().draw(resetPage);
}

/**
 * Destroys a datatable.
 *
 * @param table The table.
 * @param removeFromDom Whether to remove it from the DOM.
 * @private
 */
function _dtDestroy(table, removeFromDom) {

    // Find the datatable in our list and trash it
    for(var i = 0; i < _dtTables.length; i++) {

        if(_dtTables[i].attr('id') == table.attr('id')) {
            dtResetSelectedRows(table);
            _dtTables.splice(i, 1);
            _removeFormInputs(table);
            table.DataTable().destroy(removeFromDom);
            dtUnloadUUID(table);
            return;
        }
    }
}

/**
 * Takes two tables and moves all selected rows from one to the other
 *
 * @param from The table to rows are taken from
 * @param to The table to rows are moving to
 * @private
 */
function _moveSelectedRows(from, to) {
    from = $(from);
    to = $(to);

    // See if the current dataTable is using ajax
    var isAjax = from.DataTable().ajax.url() !== null;

    if (!isAjax) {

        var rows = dtGetSelectedRows(from);
        rows.removeClass("selected");

        from.DataTable().rows(Object.keys(_dtSelectedRows[from.attr("id")])).remove();
        _dtSelectedRows[from.attr("id")] = {};
        from.DataTable().draw(false);

        for (var row = 0; row < rows.length; row++) {
            to.DataTable().row.add(rows[row]);
        }

        to.DataTable().draw(false);
    }
    else {
        var data = dtGetTableParamsForAjax(from);
        data = $.extend(data, {"toUUID" : typeof _dtUUIDs[to.attr("id")] === "undefined" ? null : _dtUUIDs[to.attr("id")]});

        // Only send the request if something is selected
        if (data.selectedIndexes.length) {
            ajax({
                url: CONTEXT + "/dataTables/moveRows",
                method: "POST",
                data: data,
                complete: function () {
                    dtResetSelectedRows(from);
                    dtResetSelectedRows(to);
                    dtRedraw(true, from);
                    dtRedraw(true, to);
                }
            });
        }
    }
}

/**
 * Takes two tables and moves all rows from one to the other
 *
 * @param from The table to rows are taken from
 * @param to The table to rows are moving to
 * @private
 */
function _moveAllRows(from, to) {
    from = $(from);
    to = $(to);

    // See if the current dataTable is using ajax
    var isAjax = from.DataTable().ajax.url() !== null;

    if (isAjax) {

        var data = dtGetTableParamsForAjax(from);
        data = $.extend(data, {"toUUID" : typeof _dtUUIDs[to.attr("id")] === "undefined" ? null : _dtUUIDs[to.attr("id")]});

        ajax({
            url: CONTEXT + "/dataTables/moveRows/all",
            method: "POST",
            data: data,
            complete: function () {
                dtResetSelectedRows(from);
                dtResetSelectedRows(to);
                dtRedraw(true, from);
                dtRedraw(true, to);
            }
        });
    }
    else {

        var rows = from.dataTable().$("tr");

        from.DataTable().clear().draw(false);

        for (var row = 0; row < rows.length; row++) {
            to.DataTable().row.add(rows[row]);
        }

        to.DataTable().draw(false);
    }
}

/**
 * Helper function to see if a row is selected
 *
 * @param row The row to check
 * @returns {*} true/false if the row is selected or not
 * @private
 */
function _isRowSelected(row) {
    return row.hasClass("selected");
}

/**
 * Removes the class that stops text selection for all tables
 *
 * @private
 */
function _reenableTextSelect () {
    $(this).find("table").removeClass("disable-text-select");
}

/**
 * The function that starts the listeners for mouse events that control the moveable rows
 *
 * @private
 */
function _startMoveableRows() {
    if (_isRowSelected($(this))) {
        var table = $(this).parents("table");
        var pageInfo = table.DataTable().page.info();

        if (pageInfo.pages > 1) {
            $(".datatables-dragndrop-nav-wrapper").show();
        }

        _dtResizeOverlay(table.parents(".row").first().find(".datatables-dragndrop-nav-wrapper"));

        _bindMouseEvents(table);
    }
}

function _bindMouseEvents (table) {
    table.DataTable().rows().nodes().to$().on("mouseenter", _bindMouseMove);
    table.DataTable().rows().nodes().to$().on("mouseleave", _unbindMouseMove);

    $("body").off("mouseup", _stopMoveableRows);
    $("body").on("mouseup", _stopMoveableRows);

    table.DataTable().rows().nodes().to$().off("mouseup", _actuateRowMove);
    table.DataTable().rows().nodes().to$().on("mouseup", _actuateRowMove);
}

/**
 * The function that stops the listeners for mouse events that control the moveable rows
 *
 * @private
 */
function _stopMoveableRows() {
    var tables = $("table");

    tables.DataTable().rows().nodes().to$().off("mouseenter", _bindMouseMove);
    tables.DataTable().rows().nodes().to$().off("mouseleave", _unbindMouseMove);
    tables.DataTable().rows().nodes().to$().off("mouseup", _actuateRowMove);

    $(".datatables-dragndrop-nav-wrapper").hide();

    _unbindMouseMove();
}

/**
 * The function that actually changes the ordering of the rows. Currently only works for ajax loaded tables
 *
 * @private
 */
function _actuateRowMove() {
    if (!_isRowSelected($(this))) {
        var table = $(this).parents("table");

        $("table").DataTable().rows().nodes().to$().off("mouseenter", _bindMouseMove);
        $("table").DataTable().rows().nodes().to$().off("mouseleave", _unbindMouseMove);

        var insertRow = table.find(".dt-table-row-insert-point");

        var offset = table.DataTable().page.info().page * table.DataTable().page.info().length;

        // Get the index of the currently clicked row. Ignore paging since we're adding our own offset
        var currentlySelectedRow = table.DataTable().row(insertRow, {page: "current"}).index();

        // Ajax loaded tables won't have the offset applied already
        if (currentlySelectedRow < offset) {
            currentlySelectedRow += offset;
        }

        // If we need to insert after the selected row
        if (insertRow.hasClass("table-row-glow-bottom")) {
            currentlySelectedRow++;
        }

        var data = dtGetTableParamsForAjax(table);
        data = $.extend(data, {"insertIndex": currentlySelectedRow});

        ajax({
            url: CONTEXT + "/dataTables/changeOrder",
            method: "POST",
            data: data,
            success: function () {
                dtResetSelectedRows(table);
                dtRedraw(true, table);
                table.trigger("dt-rows-moved");
            }
        });
    }
}

/**
 * Function that binds the event that triggers the "glow" effect
 *
 * @private
 */
function _bindMouseMove () {
    $(this).on("mousemove", _makeRowGlow);
}

/**
 * Function that unbinds the event that triggers the "glow" effect and removes the effect from any row that currently has it
 *
 * @private
 */
function _unbindMouseMove () {
    $("table").DataTable().rows().nodes().to$().off("mousemove", _makeRowGlow);
    _removeGlow($("table"));
}

/**
 * Removes the "glow" effect from all rows in a table
 * @param elem The table to remove the glow from
 * @private
 */
function _removeGlow (elem) {
    $(elem).find("tr").removeClass("dt-table-row-insert-point table-row-glow-top");
    $(elem).find("tr").removeClass("dt-table-row-insert-point table-row-glow-bottom");
}

/**
 * Makes either the top or bottom of a row "glow" based on the mouse position
 *
 * @param event The event that triggered this function. Used to get the position of the mouse
 * @private
 */
function _makeRowGlow (event) {
    var y = event.pageY;
    var offset = $(this).offset().top;
    var height = $(this).height();

    var halfwayPoint = offset + (height/2);

    // If the mouse is above the halfway point of the row, make the top of the row glow, otherwise make the bottom glow
    if (y < halfwayPoint)
    {
        $(this).addClass("dt-table-row-insert-point table-row-glow-top");
        $(this).removeClass("table-row-glow-bottom");
    }
    else {
        $(this).addClass("dt-table-row-insert-point table-row-glow-bottom");
        $(this).removeClass("table-row-glow-top");
    }
}

/**
 * Method to keep track of which rows in a dataTable are selected
 * @private
 */
function _handleRowSelection () {
    var ourTable = $(this).parents("table");

    ourTable.addClass("disable-text-select");

    var selectedRows = _dtSelectedRows[ourTable.attr("id")];

    var offset = ourTable.DataTable().page.info().page * ourTable.DataTable().page.info().length;

    // Store the row that was previously selected (used for multi-select)
    var previousSelected = _dtCurrentlySelectedRow[ourTable.attr("id")];

    // Get the index of the currently clicked row. Ignore paging since we're adding our own offset
    var currentlySelectedRow = ourTable.DataTable().row($(this), {page: "current"}).index();

    // Ajax loaded tables won't have the offset applied already
    if (currentlySelectedRow < offset) {
        currentlySelectedRow += offset;
    }

    _dtCurrentlySelectedRow[ourTable.attr("id")] = currentlySelectedRow;

    var allSelectedButThis = ourTable.DataTable().rows('.selected').nodes().to$().not($(this));
    var allSelected = ourTable.DataTable().rows('.selected').nodes().to$();

    // See if the current dataTable is using ajax
    var ajax = ourTable.DataTable().ajax.url() !== null;

    // Shift takes precendence over ctrl
    if (_shiftHeld) {
        // If there is at least one other row selected
        if (typeof previousSelected !== "undefined") {
            // Select all rows between the one clicked and the last selected one
            for (var i = currentlySelectedRow; i > previousSelected; i--) {
                selectedRows[i] = true;

                if (ajax) {
                    if (i - offset >= 0) {
                        ourTable.DataTable().row(i - offset, {page: "current"}).nodes().to$().addClass("selected");
                    }
                }
                else {
                    ourTable.DataTable().row(i).nodes().to$().addClass("selected");
                }
            }
        }
        else {
            // Nothing else selected, so just select this one
            $(this).addClass("selected");
            selectedRows[currentlySelectedRow] = true;
        }
    }
    else {
        // If the row clicked is selected
        if (typeof selectedRows[currentlySelectedRow] !== "undefined") {
            if (!_ctrlHeld && Object.keys(selectedRows).length > 1) {
                allSelectedButThis.removeClass('selected');
                selectedRows = {};
                selectedRows[currentlySelectedRow] = true;
            }
            else {
                $(this).removeClass("selected");
                delete selectedRows[currentlySelectedRow];
            }
        }
        else {
            if (!_ctrlHeld) {
                allSelected.removeClass('selected');
                selectedRows = {};
            }

            $(this).addClass("selected");
            selectedRows[currentlySelectedRow] = true;
        }
    }

    _dtSelectedRows[ourTable.attr("id")] = selectedRows;

    ourTable.trigger("dt.selection.updated");
}

/**
 * Removes inputs created by the datatable when in a form.
 *
 * @param table The table.
 * @private
 */
function _removeFormInputs (table) {

    table = $(table);

    if (table.DataTable().ajax.url() !== null) {
        var form = _dtFormMap[table.attr("id")];

        // Double check the form exists
        if ($(form).length) {
            $(form).find("input[name='tableUUID']").remove();
        }
    }
    else {
        var map = _dtFormMap[table.attr("id")];

        if (typeof map !== "undefined") {
            for (var form in map) {
                if ($(form).length) {
                    for (var input in map[form]) {
                        $(form).find(".dt-" + table.attr("id") + "-input-col-" + map[form][input]).remove();
                    }
                }
            }
        }
    }
}

/**
 * Creates a form input for the specified table. This is called automatically when the table is in a form.
 *
 * @param table The table.
 * @private
 */
function _createFormInputs (table) {

    table = $(table);

    if (table.DataTable().ajax.url() !== null) {
        var form = _dtFormMap[table.attr("id")];

        // Double check the form exists
        if ($(form).length) {
            $(form).append('<input type="hidden" name="tableUUID" value="' + _dtUUIDs[table.attr("id")] + '"/>')
        }
    }
    else {
        var map = _dtFormMap[table.attr("id")];

        if (typeof map !== "undefined") {
            for (var form in map) {
                // Double check the form exists
                if ($(form).length) {
                    for (var input in map[form]) {
                        var data = table.DataTable().columns(map[form][input]).data();

                        for (var i = 0; i < data.length; i++) {
                            $(form).append("<input type='hidden' name='" + input + "' value='" + data[i] + "' class='dt-" + table.attr("id") + "-input-col-" + map[form][input] + "'/>");
                        }
                    }
                }
            }
        }
    }
}

/**
 * Plug-in function that allows you to jump to a row that matches the given selector
 * Will not work with AJAX loaded tables
 *
 * @param rowSelector The selector to find the row
 */
jQuery.fn.dataTable.Api.register( 'page.jumpToRow()', function ( rowSelector ) {
    var pos = this.rows({order:'current'}).nodes().indexOf(this.$(rowSelector)[0]);

    if ( pos >= 0 ) {
        var page = Math.floor( pos / this.page.info().length );
        this.page( page ).draw( false );
    }

    return this;
} );
