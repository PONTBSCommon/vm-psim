/**
 * Created by bershaa on 2/5/2015.
 */
function doIntegrationTest() {

    notifyInfo($("#testIntegration").val());

    var domainList  = $('#domainList').val();
    var apiLookupUrl  = $('#apiLookupUrl').val();
    var apiUsername  = $('#apiUsername').val();
    var apiPassword  = $('#apiPassword').val();
    var apiKey   = $('#apiKey').val();
    var emailAddress  = $('#emailAddress').val();
    var printer  = $('#printer').val();

    ajax({
        type: "POST",
        url: window.location.pathname + "/testIntegration",
        data:
        "domainList=" + domainList
        + "&apiLookupUrl=" + apiLookupUrl
        + "&apiUsername=" + apiUsername
        + "&apiPassword=" + apiPassword
        + "&apiKey=" + apiKey
        + "&emailAddress=" + emailAddress
        + "&printer=" + printer,
        success: function (response) {
            if(response.indexOf("Test Successful") > -1)
                notifySuccess(response);
            else
                notifyError(response);
        },
        error: function() {

            // TODO: localize
            notifyError("Error during test");
        }
    });

    return false;
}

