var disableInputsLookup = {
    'enableJobReplication1' : ['#jobReplicationPacingDelay', '#jobReplicationURI', '#enablePeriodicResynch'],
    'enablePeriodicResynch1' : ['#periodicResynchInterval', '#enableOneShotReplication1']
};

function disableInputs (element) {
    var inputsToDisable = disableInputsLookup[element.attr('id')],
        input;
    for (input in inputsToDisable) {
        $(inputsToDisable[input]).prop('disabled', !element.is(':checked'));
    }
}

$(document).on('click', '.disables-inputs', function () {disableInputs($(this))});

$(document).ready( function () {
    for (inputs in disableInputsLookup) {
        disableInputs($('#' + inputs));
    }
    $("#enhancedClusterAuthenticationPolicy").change(function() {
        authenticationPolicyChange();
    });

    authenticationPolicyChange();
});

function authenticationPolicyChange(){
    var authenticationPolicy = $("#enhancedClusterAuthenticationPolicy").val();

    if(authenticationPolicy == "ALWAYS"){
        $("#clusterCommunicationPassword").attr("disabled", true);
    }else {
        $("#clusterCommunicationPassword").removeAttr("disabled");
    }
}

function testRemoteHubReplication(){
    notifyInfo($("#runReplicationTest").val());

    ajax({
        url: window.location.pathname + "testRemoteHubReplication",
        type: "POST",
        data: "requestUrl=" + $("#jobReplicationURI").val(),
        success: function (response) {
            var res = response.split("|");

            if(res[0] == 1) {
                notifySuccess($("#" + res[1]).val());
            }
            else {
                notifyError($("#" + res[1]).val());
            }
        }
    })
}