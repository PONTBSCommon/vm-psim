$(document).ready(function () {
    changePdsType();

    useAjaxForForm("#configurePrintersForm", {
        beforeSend: function(xhr) {
            startSpinnerOnButton("#configurePrinterSubmit");
        },
        success: function(){
            stopSpinnerOnButton("#configurePrinterSubmit");
            notifySuccess($("#successMessage").val());
            $("#configurePrintersDialog").modal("hide");
        },
        error: function(){
            stopSpinnerOnButton("#configurePrinterSubmit");
        }
    });

    $("#connection").on('change', function()
    {
        if(this.value != "NETWORK")
        {
            $(".localIpAddressRow").hide();
            $(".portRow").hide();
        }
        else
        {
            $(".localIpAddressRow").show();
            $(".portRow").show();
        }

    });

    $(document).on("click", "#resetMachineId", function () {
        resetMachineId($("#ponServersTable").find("tr.selected").data("serialnumber"));
    });

    $(document).on("click", ".showPrinters", function () {
        showLinkedPrinters($(this).data("serialnumber"));
    });

    $("#linkPrintersDialog").on('hidden.bs.modal', function () {
        clearLinkedPrinters();
    });

    $("#configurePrintersDialog").on('hidden.bs.modal', function () {
        getLinkedPrintersSection();
        resetErrorsOnForm($("#configurePrintersForm"));
    });

    $("#editPrinter").on("click", function() {

        if($("#editPrinter").hasClass("btn-disabled"))
        {
            return false;
        }
        else
        {
            var printerDesc = $("#linkedPrinters").find("tr.selected > td:nth-child(1)").html();

            //printerName
            $("#printerLabel").html(printerDesc);
            $("#printerName").val(printerDesc);
            $("#configurePrintersDialog").modal("show");
            $("#linkPrintersDialog").modal("hide");

            ajax({
                url: CONTEXT + "/ponServers/printer",
                data: $("#configurePrintersForm").serialize(),
                method: "GET",
                success: function(data)
                {
                    bindOverrideSettingsForm(data);
                }
            })
        }

    });

    $("#pdsType").change(changePdsType);

    ponServersStartSpinner();

    dtLoad("#ponServersTable", {
        serverSide: true,
        fnRowCallback: function( nRow, aData ) { return decorateRow(nRow, aData); },
        fnInitComplete: function() {$('#ponServersTable tbody tr:eq(0)').click(); },//<- This line makes the first row selected
        ajax: {
            "url" : CONTEXT + '/ponServers/list'
        },
        columns: [
            {data: "label"},
            {data: "serialNum"}
        ],
        selectableRows: true,
        multiSelectRows: false
    });

    $("#ponServersTable").on("draw.dt", function () {
        $("#ponServersTable").find("tr").off('click', getPonServer);
        $("#ponServersTable").find("tr").on('click', getPonServer);
    });

    useAjaxForForm("#ponServerForm", {
            beforeSend: function () {startSpinnerOnButton("#submitPonServer")},
            complete: function () {
                stopSpinnerOnButton("#submitPonServer");

                //Update PonServer Label on Data table
                dtUnloadUUID($("#ponServersTable"));
                dtRedraw(true, "#ponServersTable");
            }
        });

    $("#machineIdSamsung").change(function () {
        $("#machineId").val("PON-" + $("#machineIdSamsung").val());
    });
});

function ponServersStartSpinner () {
    $("#ponServersTableWrapper").hide();
    $("#ponServersTableSpinner").show();
    startSpinner("#ponServersTableSpinner")
}

function ponServersStopSpinner () {
    $("#ponServersTableSpinner").hide();
    $("#ponServersTableWrapper").show();
    stopSpinner("#ponServersTableSpinner")
}

function decorateRow(nRow, aData) {
    ponServersStopSpinner();
    $(nRow).data("serialnumber", aData['serialNum']);
}

function changePdsType () {
    if ($("#pdsType").length) {
        if ($("#pdsType").val() == "SAMSUNG_EMBEDDED" || $("#pdsType").val() == "HP_EMBEDDED") {
            var machineIdSamsung = $("#machineIdSamsung");
            var machineIdVal = $("#machineId").val();

            if (machineIdVal != null && machineIdVal.startsWith("PON-")) {
                machineIdSamsung.val(machineIdVal.substring(4, machineIdVal.length));
            }
            else {
                machineIdSamsung.val(machineIdVal);
            }

            machineIdSamsung.change();
        }

        $(".ponServerRow").hide();
        $("." + $("#pdsType").val()).show();
    }

    convertPdsConfigTime();
}

function getPonServer () {
    clearMessageError();

    $('#ponServerForm').trigger("reset");
    ajax({
        url: CONTEXT + "/ponServers/" + $("#ponServersTable").find("tr.selected").data("serialnumber"),
        method: "GET",
        beforeSend: startPonServerLoading,
        success: populatePonServerForm,
        complete: stopPonServerLoading
    })
}

function populatePonServerForm (data) {
    $("#machineIdSamsung").val("");
    for (var key in data)
    {
        if (key == "serialNum") {
            $("#serialNum").val(data[key]);
            $("#serialNumDisplay").html(data[key]);
        }
        else if (key == "machineId") {
            $("#machineId").val(data[key]);

            if (data[key] != null && data[key].startsWith("PON-")) {
                $("#machineIdSamsung").val(data[key].substring(4, data[key].length));
            }
            else {
                $("#machineIdSamsung").val(data[key]);
            }
        }
        else if (key == "validateDetails")
        {
            // Do nothing
        }
        else if (data[key] === true || data[key] === false) {
            $("input[name='" + key + "']").prop("checked", data[key]);
        }
        else if (data[key] == "null") {
            $("#" + key).val("");
        }
        else {
            $("#" + key).val(data[key]);
        }
    }

    changePdsType();
}

function convertPdsConfigTime()
{
    var millis = Number($("#pdsConfigModified").val());

    if (millis > 0 && $("#pdsType").val() !== "SOFTWARE")
    {
        //Convert to local date
        var date = new Date(0);

        date.setUTCMilliseconds(millis);

        $("#pdsConfigTime").html(date.toLocaleString());
        $("#pdsConfigModifiedRow").show();
    }
    else {
        $("#pdsConfigModifiedRow").hide();
    }
}

function startPonServerLoading () {
    $("#ponServerExplanationWrapper").hide();
    $("#ponServers").attr("disabled", true);
    $("#ponServerLoadingWrapper").show();
    $("#ponServerFormWrapper").hide();

    startSpinner("#ponServerLoadingWrapper");
}

function stopPonServerLoading () {
    $("#ponServerExplanationWrapper").hide();
    $("#ponServers").attr("disabled", false);
    $("#ponServerLoadingWrapper").hide();
    $("#ponServerFormWrapper").show();

    stopSpinner("#ponServerLoadingWrapper");
}

function showLinkedPrinters(serialNumber)
{
    $(".pdsServerRow").hide();
    //$("#configurePrintersDialog").modal("show");
    getLinkedPrintersSection();
}

function startServerSpinner () {
    $("#linkedPrintersServerWrapper").hide();
    startSpinner("#linkedPrintersServerSpinner");
}

function stopServerSpinner () {
    stopSpinner("#linkedPrintersServerSpinner");
    $("#linkedPrintersServerWrapper").show();
}

function startLinkedPrintersSpinner () {
    $("#ponServer").attr("disabled", true);
    $("#linkPrintersSubmit").attr("disabled", true);
    $("#linkedPrintersWrapper").hide();
    startSpinner("#linkedPrintersSpinner");
}

function stopLinkedPrintersSpinner () {
    $("#ponServer").attr("disabled", false);
    $("#linkPrintersSubmit").attr("disabled", false);
    stopSpinner("#linkedPrintersSpinner");
    $("#linkedPrintersWrapper").show();
}

function getLinkedPrintersSection () {
    startServerSpinner();
    $("#linkPrintersDialog").modal("show");

    //Hide Edit Printer for PDS Software based
    if($('#pdsType option:selected').val() == "SOFTWARE")
    {
        $("#editPrinter").hide();
    }
    else
    {
        $("#editPrinter").show();
    }

    $("#editPrinter").prop("disabled", true);
    $("#editPrinter").removeClass("btn-default");
    $("#editPrinter").addClass("btn-disabled");
    ajax({
        url: CONTEXT + "/printer/link/getAll",
        method: "GET",
        success: function (data) {
            fillLinkedPrintersSection(data);
            stopServerSpinner();
            getLinkedPrinters();
            $("#ponServer").change(getLinkedPrinters);
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
            $("#linkPrintersDialog").modal("hide");
        },
        complete: function(){
            var aData = dtGetTableParamsForAjax($("#linkedPrinters"));

            if(aData.selectedIndexes.length <= 0)
            {
                $("#editPrinter").prop('disabled', true);
            }
            else
            {
                $("#editPrinter").prop('disabled', false);
            }
        }

    });
}

function getLinkedPrinters () {
    startLinkedPrintersSpinner();

    // Get the printer classes
    var classes = "PUBLIC, IPP";
    var ponSerialNum = $("#ponServersTable").find("tr.selected").data("serialnumber");

    ajax({
        url: CONTEXT + "/printer/link",
        method: "GET",

        success: function (data) {

            fillLinkedPrinters(data, ponSerialNum, classes);

            $("#printerClassesInput").val(classes);

            useAjaxForForm("#linkPrintersForm", {

                beforeSend: function(){

                    startSpinnerOnButton("#linkPrintersSubmit");

                },

                success: function (resp) {

                    if (resp != null && resp != "") {

                        notifySuccess(resp);

                        stopSpinnerOnButton("#linkPrintersSubmit");

                        $("#linkPrintersDialog").modal("hide");
                    }
                }
            });

        },
        error: function (xhr) {
            notifyError(xhr.responseText);

            stopSpinnerOnButton("#linkPrintersSubmit");

            $("#linkPrintersDialog").modal("hide");
        }
    })
}

function fillLinkedPrinters (data, server, classes) {
    clearLinkedPrinters();

    $("#linkedPrintersWrapper").html(data);
    linkedDataTables({
        "#availablePrinters":{
            ajax: {
                url: CONTEXT + "/printer/link/available?printerClasses=PULL&printerClasses=PUBLIC",
                complete: stopLinkedPrintersSpinner
            },
            fnCreatedRow: function() {
                toggleEditButton();
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ],
            "fnServerParams": function ( aoData ) {
                aoData = $.extend(true, aoData, {
                    "server": server,
                    "printerClasses": classes
                });
            }
        },
        "#linkedPrinters":{
            ajax: {
                url: CONTEXT + "/printer/link/linked?printerClasses=PULL&printerClasses=PUBLIC",
                complete: stopLinkedPrintersSpinner
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ],
            "fnServerParams": function ( aoData ) {
                aoData = $.extend(true, aoData, {
                    "server": server,
                    "printerClasses": classes
                });
            },
            "form": "#linkPrintersForm"
        }
    });

    $("#linkedPrinters").one("draw.dt", function () {
        $('#linkedPrinters').on( 'dt.selection.updated', function()
        {
            toggleEditButton();
        });
    });
}

/**
 * Function to Enable or Disable Edit button based on
 * LinkedPrinters datatables selected row
 */
function toggleEditButton()
{
    var aData = dtGetSelectedRowIndexes($("#linkedPrinters"));
    if(aData.length == 1)
    {
        $("#editPrinter").prop("disabled", false);
        $("#editPrinter").removeClass("btn-disabled");
        $("#editPrinter").addClass("btn-default");
    }
    else
    {
        $("#editPrinter").prop("disabled", true);
        $("#editPrinter").removeClass("btn-default");
        $("#editPrinter").addClass("btn-disabled");
    }
}

function clearLinkedPrinters () {
    dtDestroy("#availablePrinters");
    dtDestroy("#linkedPrinters");
}

function fillLinkedPrintersSection (data) {
    clearLinkedPrintersSection();

    $("#pdsName").html($("#label").val());

    for (var key in data) {
        if (key == "printers") {
            var printerHTML = "";

            for (var printer in data[key]) {
                printerHTML += "<div class='col-md-6'>";
                printerHTML += "<input type='checkbox' name='linkedPrinters' id='linkedPrinters-" + data[key][printer].id + "' value='" + data[key][printer].id + "'/>";
                printerHTML += "<label for='linkedPrinters-" + data[key][printer].id + "'>" + data[key][printer].label + "</label>";
                printerHTML += "</div>";
            }

            $("#linkedPrintersWrapper").html(printerHTML);
        }
    }
}

function clearLinkedPrintersSection () {
    $("#linkedPrintersServerWrapper").html("");
    $("#linkedPrintersWrapper").html("");
}

function bindOverrideSettingsForm(data)
{
    var pdsType = $("#pdsType").val();

    $("#localIpAddress").val( data["localIpAddress"]);

    $("#port").val( data["port"]);

    $("#connection").val( data["connection"]);

    $("#host").prop('checked', data["host"]);

    if(pdsType != "RICOH_HOTSPOT" && pdsType != "SAMSUNG_EMBEDDED"&& pdsType != "HP_EMBEDDED" && pdsType != "OXPD_AGENT")
    {
        $(".hostRow").hide();
    }
    else
    {
        $(".hostRow").show();
    }

    if(pdsType != "PRINT_CONNECT")
    {
        $(".connectionsRow").hide();
    }
    else
    {
        $(".connectionsRow").show();
    }
}

function resetMachineId(serialNumber)
{
    ajax({
        url: CONTEXT + "/ponServers/reset/" + serialNumber,
        method: "POST",
        success: function (data) {
            $("#machineId").val("");
            $("#machineIdSamsung").val("");
            notifySuccess(data);
            $("#pdsConfigModifiedRow").hide();
        },
        error: function (xhr) {
            notifyError(xhr.responseText);

        }
    })
}

function clearMessageError()
{
    var control = $("#rqmUrl");

    control.removeClass("error");

    $(".errorMessage").html("");
}
