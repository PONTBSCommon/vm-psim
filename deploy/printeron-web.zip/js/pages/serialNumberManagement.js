var oldSerial = "";

function updateSerialInTable(data, agentType)
{
    var json = JSON.parse(data);
    var canStillAdd = json['canStillAdd'];
    var serialNum = json['serialNumber'];

    var form = $("#changeSerialNumberForm-" + agentType);
    var uuid = form.find("input[name='uuid']").val();

    var row = dtGetRows("tr[data-uuid='" + uuid + "']", "#serialNumberTable");
    var label = row.find(".serialLabel").html();

    row.find(".serialNumber").html(serialNum);
    row.removeClass("duplicate");
    row.removeClass(oldSerial);
    row.removeClass(label);

    row.addClass(serialNum);

    var option = form.find("select option[value='" + serialNum + "']");

    if ($("#serialNumber-" + agentType).val() === "new") {
        row.find(".serialLabel").html($("#serialLabel-" + agentType).val());
        row.addClass($("#serialLabel-" + agentType).val());
    }
    else {
        row.find(".serialLabel").html(option.data("label"));
        row.addClass(option.data("label"));
    }

    //Remove serial from unused serials
    option.remove();
    dtRemoveRow($(".extraSerial[data-serialnumber='" + serialNum + "']"), "#serialNumberListingTable");
    dtRedraw(false, "#serialNumberListingTable");

    var duplicates = dtGetRows("tr." + oldSerial, "#serialNumberTable");
    if (duplicates.size() <= 1)
    {
        duplicates.removeClass("duplicate");

        if (duplicates.size() <= 0) {
            var html = "<option data-label=" + label + " value=" + oldSerial + ">" + label + " (" + oldSerial + ")</option>";
            form.find("select").append(html);

            addUnusedServerRow(agentType, oldSerial, label);
        }
    }

    if (canStillAdd == "false") {
        form.find("select option[value='new']").remove();
    }

    stopSpinnerOnButton("#submitSerialChange-" + agentType);

    notifySuccess($("#updateSuccess").val());

    $("#changeSerialNumberDialog-" + agentType).modal("hide");
}

function updateSerialLabelInTables(serial, label) {

    // Find the row with that serial
    var rows = dtGetRows("." + serial, "#serialNumberTable");

    if(!rows.length) {
        rows = dtGetRows("tr[data-serialnumber='" + serial + "']", "#serialNumberListingTable");
    }

    if(!rows.length) {
        return;
    }

    rows.children(".serialLabel").text(label).html();
}

function addUnusedServerRow(agentType, serial, label) {

    if($('#serialNumberListingTable').length) {
        var rowHtml = "<tr class=\"extraSerial\" data-serialNumber=\"" + serial + "\">"
            + "<td>" + $("#acronym" + agentType).val() + "</td>"
            + "    <td class=\"serialLabel\">" + label + "</td>"
            + "    <td class=\"serialNumber\">" + serial + "</td>"
            + "    <td><button class=\"openEditLabel btn btn-default\">"+$("#editButtonText").val()+"</button> <button class=\"btn btn-danger deleteSerialNumber\" data-type=\"" + agentType.toLowerCase() + "\" data-serialNumber=\"" + serial + "\">" + $("#deleteButtonText").val() + "</button></td>"
            + "</tr>";
        dtAddRow(rowHtml, "#serialNumberListingTable");
        dtRedraw(false, "#serialNumberListingTable");

        bindRemoveSerialEvent();
        bindEditSerialLabelEvent();
    }
}

function bindRemoveSerialEvent() {

    // Only bind if the table is there
    if($('#serialNumberListingTable').length) {

        dtQueryRows(".deleteSerialNumber", "#serialNumberListingTable").click(function () {
            var serialNumber = $(this).data("serialnumber");
            var type = $(this).data("type");

            ajax({
                url: CONTEXT + "/serialNumberManagement/" + type + "/remove/" + serialNumber,
                method: "DELETE",
                success: function (resp) {
                    notifySuccess(resp);

                    dtRemoveRow($(".extraSerial[data-serialnumber='" + serialNumber + "']"), "#serialNumberListingTable");
                    dtRedraw(false, "#serialNumberListingTable");
                },
                error: function (xhr) {
                    defaultErrorFunction(xhr);
                }
            });
        });
    }
}

function bindEditSerialLabelEvent() {

    $(".openEditLabel").click(function () {
        openEditLabelModal($(this));
        return false;
    });
}

$(document).ready(function () {
    dtLoad("#serialNumberTable");
    dtLoad("#serialNumberListingTable");

    bindRemoveSerialEvent();
    bindEditSerialLabelEvent();

    useAjaxForForm("#changeSerialNumberForm-PDS",
            {
                beforeSend: function () {
                    startSpinnerOnButton("#submitSerialChange-PDS-confirm");
                },
                success: function (data) {
                    stopSpinnerOnButton("#submitSerialChange-PDS-confirm");

                    $('#pds-serial-change-confirm').modal('hide');

                    updateSerialInTable(data, "PDS")
                },
                error: function () {
                    stopSpinnerOnButton("#submitSerialChange-PDS-confirm");

                    $('#pds-serial-change-confirm').modal('hide');
                }
            }
        );

    useAjaxForForm("#changeSerialNumberForm-PDH",
        {
            beforeSend: function () {
                startSpinnerOnButton("#submitSerialChange-PDH");
            },
            success: function (data) {
                updateSerialInTable(data, "PDH")
            },
            error: function () {
                stopSpinnerOnButton("#submitSerialChange-PDH");
            }
        }
    );

    useAjaxForForm("#changeSerialNumberForm-PAS",
        {
            beforeSend: function () {
                startSpinnerOnButton("#submitSerialChange-PAS");
            },
            success: function (data) {
                updateSerialInTable(data, "PAS")
            },
            error: function () {
                stopSpinnerOnButton("#submitSerialChange-PAS");
            }
        }
    );

    useAjaxForForm("#editLabelForm", {

        beforeSend: function () {
            startSpinnerOnButton("#editLabelSubmit");
        },
        success: function (data) {
            notifySuccess(data);
            updateSerialLabelInTables($("#serialToEdit").val(), $("#labelToEdit").val());
            $("#editLabelModal").modal("hide");
        },
        complete: function () {
            stopSpinnerOnButton("#editLabelSubmit");
        }
    });

    $(".openChangeSerialNumber").click(function () {
        openSerialNumberModal($(this));
    });

    $(".serialNumberSelect").change(function () {
       toggleSerialLabel($(this));
    });

    $("#addPds").click(function () {
        $("#addPdsDialog").modal("show");
    });

    $("#addPas").click(function () {
        ajax({
            url: CONTEXT + "/serialNumberManagement/pas/canAdd",
            success: function(data) {
                if (data == true) {
                    $("#addPasDialog").modal("show");
                }
                else {
                    $("#licenseExceededDialog").modal("show");
                }
            }
        });

    });

    $("#addPdh").click(function () {
        ajax({
            url: CONTEXT + "/serialNumberManagement/pdh/canAdd",
            success: function(data) {
                if (data == true) {
                    $("#addPdhDialog").modal("show");
                }
                else {
                    $("#licenseExceededDialog").modal("show");
                }
            }
        });
    });

    useAjaxForForm("#addPdsForm",
        {
            beforeSend: function (){
                startSpinnerOnButton("#addPdsSubmit");
            },
            success: function (resp) {
                stopSpinnerOnButton("#addPdsSubmit");
                $("#addPdsDialog").modal("hide");
                $("input[type='text']", "#addPdsForm").val("");

                var json = JSON.parse(resp);
                addUnusedServerRow("PDS", json.serialNumber, json.label);

                notifySuccess($("#addPdsSuccess").val());
            },
            error: function () {
                notifyError($("#couldNotAddPds").val());
                stopSpinnerOnButton("#addPdsSubmit");
            }
        });

    useAjaxForForm("#addPasForm",
        {
            beforeSend: function (){
                startSpinnerOnButton("#addPasSubmit");
            },
            success: function (resp) {
                stopSpinnerOnButton("#addPasSubmit");
                $("#addPasDialog").modal("hide");
                $("input[type='text']", "#addPasForm").val("");

                var json = JSON.parse(resp);

                addUnusedServerRow("PAS", json.serialNumber, json.label);
                notifySuccess($("#addPasSuccess").val());
            },
            error: function (xhr) {
                var data = xhr.responseText;

                if (data == "false") {
                    $("#licenseExceededDialog").modal("show");
                }

                notifyError($("#couldNotAddPas").val());
                stopSpinnerOnButton("#addPasSubmit");
            }
        });

    useAjaxForForm("#addPdhForm",
        {
            beforeSend: function (){
                startSpinnerOnButton("#addPdhSubmit");
            },
            success: function (resp) {
                stopSpinnerOnButton("#addPdhSubmit");
                $("#addPdhDialog").modal("hide");
                $("input[type='text']", "#addPdhForm").val("");

                var json = JSON.parse(resp);

                addUnusedServerRow("PDH", json.serialNumber, json.label);
                notifySuccess($("#addPdhSuccess").val());
            },
            error: function (xhr) {
                var data = xhr.responseText;

                if (data == "false") {
                    $("#licenseExceededDialog").modal("show");
                }

                notifyError($("#couldNotAddPdh").val());
                stopSpinnerOnButton("#addPdsSubmit");
            }
        });
});

function openSerialNumberModal(elem) {

    var row = elem.parents("tr");
    var serialNumber = row.find(".serialNumber").html();
    var agentType = row.data("agenttype");
    var uuid = row.data("uuid");
    var select = $("#serialNumber-" + agentType);

    if (select.find("option").size() == 0) {
        $("#licenseExceededDialog").modal("show");
    }
    else {
        oldSerial = serialNumber;

        $("#agentType-" + agentType).val(agentType);
        $("#uuid-" + agentType).val(uuid);
        select.find(' option:first-child').attr("selected", "selected");
        $('#serialLabel-' + agentType).val("");

        toggleSerialLabel(select);

        $("#changeSerialNumberDialog-" + agentType).modal("show");
    }

    $('#submitSerialChange-PDS').click(function(e) {
        $('#changeSerialNumberDialog-PDS').modal('hide');
        $('#pds-serial-change-confirm').modal('show');
        return false;
    });
}

function openEditLabelModal(elem) {

    var row = elem.parents("tr");
    var serialNumber = row.find(".serialNumber").html();
    var label = row.find(".serialLabel").html();

    $("#serialToEdit").val(serialNumber);
    $("#labelToEdit").val(label);

    $("#editLabelModal").modal("show");
}

function submitPdsSerialNumberChange(){
    $("#changeSerialNumberForm-PDS").submit();
}

function toggleSerialLabel(select)
{
    var label = select.parents(".modal-body").find(".serialLabelWrapper");

    if (select.val() === "new") {
        label.show();
    }
    else {
        label.hide();
    }
}