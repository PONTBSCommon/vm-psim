/**
 * Created by bershaa on 3/23/2015.
 */
var dataTableWrapper = $("#pdgPrinters_wrapper");
var spinner = $("#dataTable-spinner");
var uuid = $("#uuid").val();
var clientname = $("#clientname").val();

$(document).ready(function (){
    prepareDataTable();
});

function showDataTableLoading () {
    dataTableWrapper.hide();
    spinner.show();
}

function hideDataTableLoading () {
    spinner.hide();
    dataTableWrapper.show();
}

function prepareDataTable () {
    
    var table = $("#pdgPrinters");
    
    showDataTableLoading();
    dtLoad("#pdgPrinters", {
        ajax: {
            "url" : CONTEXT + "/" + clientname + "/" + uuid + "/printers/list",
            "complete" : hideDataTableLoading
        },
        fnRowCallback: function( nRow, aData ) { return decorateRow(nRow, aData); },
        serverSide: true,
        columns: [
            {data : "printeronName"},
            {data : "device"},
            {data : "networkAuthLocalized"},
            {data : "pqmsMapped"},
            {data : "googleMapped"},
            {data : "airEnabled"}
        ]
    });

    // Rebind events when the table is drawn
    table.on("draw.dt", function () {
        // Register event handlers for enable/disable, in all rows (even hidden ones)
        dtQueryRows("[id$='-enable'], [id$='-disable']", table).click(setProperty);

        // Register event handlers for the header row
        table.find("th").find("[id$='-enable'], [id$='-disable']").click(setProperty);
    });
}

function decoratePrinterNameColumn(column, printerName, printerNumber) {
    var html = "";

    column.data("printernum", printerNumber);

    if (printerName.length > 25) {
        html += printerName.substring(0,25) + "&nbsp;<span title='" + $("#js-printerName").val() + printerName + " " + $("#js-printerNumber").val() + printerNumber +  "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else
    {
        html += printerName;
    }

    column.html(html);
}

function decorateDeviceColumn(column, device) {
    var html = "";

    column.attr("title", device);

    if (device.length > 25) {
        html += device.substring(0,25) + "&nbsp;<span title='" + device + "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else {
        html += device;
    }

    column.html(html);
}

function decorateBooleanColumn (column, val) {
    column.addClass("col-md-1 printers-glyphicon-align text-center");

    if (val) {
        column.data("order", "1");
        column.html("<span class=\"glyphicons glyphicons-ok x1 green\"></span>");
    }
    else if (!val) {
        column.data("order", "2");
        column.html("<span class=\"glyphicons glyphicons-remove x1 red\"></span>");
    }
    else {
        column.data("order", "3");
        column.html($("#js-na").val());
    }
}

function decorateSendTestJobColumn(column, printerNumber) {
    column.html("<button type='button' class='btn btn-default' title='" + $("#js-sendTestJob").val() + "' onclick='testPrinter(" + printerNumber + ")'>" + $("#js-test").val() + "</button>");
}

function decorateRow (nRow, aData) {
    var displayedColumnIndex = 0;
    var columnIndex = 0;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decoratePrinterNameColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["printeronName"], aData["printeronNumber"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateDeviceColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["device"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        // Do nothing for the network auth column. Fine as it is
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateBooleanColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["pqmsMapped"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateBooleanColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["googleMapped"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateDiscoveryColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["airEnabled"], aData["printeronNumber"]);
        //decorateBooleanColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["airEnabled"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateSendTestJobColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["printeronNumber"]);
    }
}

function testPrinter(printerNumber){
    notifyInfo($("#sendingPrintJob").val());

    ajax({
        type: "POST",
        url: window.location.pathname + "/sendTestPrintJob",
        data: "printerNumber=" + printerNumber,
        success : function(response) {

            if(response) {
                notifySuccess($("#sendPrintJobSuccess").val());
            }
            else {
                notifyError($("#sendPrintJobFailed").val());
            }

        },
        error : function(e) {
            notifyError($("#sendPrintJobFailed").val());
        }
    });
}

function decorateDiscoveryColumn (column, discovery, printerNum) {
    column.addClass("col-md-1 printers-glyphicon-align text-center");

    var discoveryEnabled = true;

    // this is the global discovery enabled flag
    if($("#discoveryEnabled").val() == "false")
        discoveryEnabled = false;

    // if the global flag is off then show all toggles as
    // the red x, which will not be clickable
    if (discoveryEnabled && discovery) {
        column.data("order", "1");
        column.attr("id", printerNum + "-discovery");
        column.html("<span id='" + printerNum + "-discovery-disable' class=\"glyphicons glyphicons-ok x1 green hoverable discovery-toggle\"></span>");
    }
    else if (!discoveryEnabled || !discovery) {
        column.data("order", "2");
        column.attr("id", printerNum + "-discovery");
        column.html("<span id='" + printerNum + "-discovery-enable' class=\"glyphicons glyphicons-remove x1 red hoverable discovery-toggle\"></span>");
    }
    else {
        column.data("order", "3");
        column.html($("#js-na").val());
    }

}

/**
 * Sets a printer property via AJAX.
 *
 * @param event The click event.
 */
function setProperty(event) {

    // prevent clicking of sort button
    preventPropogation(event);

    // Get the ID
    var id = getIdFromEvent(event);

    // Blur the select box outta here
    $("#" + id).parent().blur();

    // Split the id on hyphens
    var parts = id.split('-');

    var printerId = parts[0];
    var property = parts[1];
    var action = parts[2];

    // Show confirmation dialog, the ok button will send the printer update
    if(printerId == "all") {

        // Get the appropriate dialog message
        var message = $("#confirmation-" + property + "-" + action).val();

        // Set the message
        var dialog = $("#confirmationDialog");
        dialog.find(".modal-body").html(message);

        // Save the current action and property, so saying yes on the modal can do it
        confirmationRequiredProperty = property;
        confirmationRequiredAction = action;

        // Set up the dialog
        dialog.modal("show");

    } else {
        sendPrinterUpdate(printerId, property, action);
    }
}

/**
 * Sends an ajax request to modify printer info.
 *
 * @param printerId The printer ID, or "all".
 * @param property The property we're setting.
 * @param action The action we want.
 */
function sendPrinterUpdate(printerId, property, action) {

    // Post to printers
    ajax({
        url: CONTEXT + "/pdg/" + uuid + "/printers/" + printerId + "/" + property + "/" + action,
        type: "POST",
        
        success: function (resp) {

            // Toggle the list entry option
            toggleListEntryOption(printerId, property, action);
            
        },
        error: function (resp) {

            if(printerId == "all") {
                notifyError($("#updateAllFailed").val());
            } else {
                notifyError($("#updateOneFailed").val());
            }
        }
    });
}

/**
 * Toggles a list entry option.
 *
 * @param printerId The id of the printer.
 * @param property The property we set.
 * @param action The action that was completed.
 * @param rows The DT rows, so you don't have re-query them (optional).
 * @param updateHead Whether to update the head option as required (optional, default true).
 */
function toggleListEntryOption(printerId, property, action, rows, updateHead) {

    // if the global discovery is set to off then just return from here
    // we do not want to be able to toggle these guys when it is off
    if(property == "discovery"){
        if($("#discoveryEnabled").val() == "false")
            return;
    }

    // If rows were not supplied, query the table for them
    if (typeof rows === "undefined") {
        rows = dtGetAllRows($("#printerTable"));
    }

    // If update head is not supplied, default it to true
    if (typeof updateHead === "undefined") {
        updateHead = true;
    }

    // Grab the right td, tr, and the datatable (for api calls)
    var table = $('#printerTable').DataTable();
    var td = $("#" + printerId + "-" + property, rows);
    var tr = td.parent();

    // And the glyph inside
    var glyph = $("#" + printerId + "-" + property + "-" + action, td);

    // Replace check with x, or x with check
    if (action == 'disable') {

        // Change the glyph
        glyph.removeClass("glyphicons-ok");
        glyph.removeClass("green");
        glyph.addClass("glyphicons-remove");
        glyph.addClass("red");
        glyph.attr("id", printerId + "-" + property + "-enable");

        // Change the data order of the span
        td.attr('data-order', 2);
    } else {

        // Change the glyph
        glyph.removeClass("glyphicons-remove");
        glyph.removeClass("red");
        glyph.addClass("glyphicons-ok");
        glyph.addClass("green");
        glyph.attr("id", printerId + "-" + property + "-disable");

        // Change the data order of the span
        td.attr('data-order', 1);
    }
}
