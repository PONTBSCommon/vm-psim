/**
 * Created by bershaa on 11/13/2015.
 */
var type = 0;

$(function(){
    $( "#releaseAnywhereType" ).change(function() {
        onTypeChange();
    });

    $( "#enableAbandonedJobPurgePds" ).click(function() {
        onAbandonedJobPurgePdsClick(this);
    });

    $( "#enableAbandonedJobPurgePdh" ).click(function() {
        onAbandonedJobPurgePdhClick(this);
    });

    onTypeChange();

    onAbandonedJobPurgePdhClick($("#enableAbandonedJobPurgePdh"));
    onAbandonedJobPurgePdsClick($("#enableAbandonedJobPurgePds"));
});


function onAbandonedJobPurgePdhClick(element){
    var checked = $(element).prop("checked");

    if(checked) {
        $("#abandonedJobPurgeIntervalPdh").removeAttr("disabled");
    }else {
        $("#abandonedJobPurgeIntervalPdh").attr("disabled", "true");
    }
}

function onAbandonedJobPurgePdsClick(element){
    var checked = $(element).prop("checked");

    if(checked) {
        $("#abandonedJobPurgeIntervalPds").removeAttr("disabled");
    }else {
        $("#abandonedJobPurgeIntervalPds").attr("disabled", "true");
    }
}

function onTypeChange(){
    type = $("select[id='releaseAnywhereType'] option:selected").index();

    if(type == 0) {
        $(".advanced").hide();
        $(".standard").show();
    }else {
        $(".standard").hide();
        $(".advanced").show();
    }
}