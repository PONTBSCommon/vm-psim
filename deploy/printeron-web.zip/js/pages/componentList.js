/**
 * Component list JS.
 *
 * @author Lukas Rezek <lrezek@printeron.com>
 */

var filterName = "superFilter";
var componentNameColumn = 0; // Index of the component name column
var hostNameColumn = 1;      // Index of the host name column

/**
 * Executes on document ready.
 */
$(document).ready(function() {

   // Load up the datatable
    dtLoad("#componentTable", {"order": [[$("#onlineStatus").index(), 'asc']]});

    // Stick in the filter show button
    var filterSpan = $("#componentTable_filter");
    filterSpan.prepend('<button id="resetFiltersButton" class="btn btn-danger">' + $("#resetButtonText").val() + "</button>");
    filterSpan.prepend('<button id="showFiltersButton" class="btn btn-info">' + $("#filterButtonText").val() + "</button>");

    $("#showFiltersButton").click(showFilters);

    $("#applyFiltersButton").click(applyFiltersClick);
    $("#resetFiltersButton").click(resetFiltersClick);

    // Apply the filters on start up
    applyFilters(getComponentFilters(), getServerFilters());
});

/**
 * On click for the apply filters button.
 */
function applyFiltersClick() {

    startSpinnerOnButton("#applyFiltersButton");

    var components = getComponentFilters();
    var servers = getServerFilters();

    applyFilters(components, servers);

    saveFilters(components, servers);

    stopSpinnerOnButton("#applyFiltersButton");

    // Close the modal
    $("#filterDialog").modal("hide");
}

/**
 * On click for filter resetting.
 */
function resetFiltersClick() {

    // Start spinner
    startSpinnerOnButton("#resetFiltersButton");

    // Reset filters in the UI
    resetFilters();

    // Save empty filter list
    saveFilters([], []);

    // Stop spinner
    stopSpinnerOnButton("#resetFiltersButton");
}

/**
 * On click for showing the filters dialog.
 */
function showFilters() {

    $("#filterDialog").modal("show");
}

/**
 * Saves filters to the server.
 *
 * @param components Component filters.
 * @param servers Server filters.
 */
function saveFilters(components, servers) {

    ajax({
        url: CONTEXT + "/components/filter",
        type: "POST",
        contentType: "application/json; charset=UTF-8",
        data: JSON.stringify({components: components, servers: servers}),
        error: function() {
            notifyError($("#filterSaveError").val());
        }
    });
}

/**
 * Applies filters to the datatable.
 *
 * @param components The component filters.
 * @param servers The server filters.
 */
function applyFilters(components, servers) {

    // Create the filter
    var filter = function(settings, data) {

        var componentMatch = ($.inArray(data[componentNameColumn], components) > -1) || (components.length == 0);
        var hostMatch = ($.inArray(data[hostNameColumn], servers) > -1) || (servers.length == 0);

        return componentMatch && hostMatch;
    };

    // Attach it to the datatable
    dtAttachFilter(filter, filterName);

    // Filter it
    dtApplyFilters();
}

/**
 * Clears the filters from the table.
 */
function resetFilters() {

    // Check all filters
    $("#componentFilters").find("input:checkbox").prop("checked", true);
    $("#hostNameFilters").find("input:checkbox").prop("checked", true);

    // Reset the filters
    dtDetachFilter(filterName);

    // Apply the filter changes
    dtApplyFilters();
}

/**
 * Gets selected component filters.
 *
 * @returns {Array}
 */
function getComponentFilters() {

    var componentFilters = $("#componentFilters").find(":checked");

    var filters = [];

    // Loop over components, add and remove the appropriate filters
    componentFilters.each(function() {

        filters.push($(this).data("type"));
    });

    return filters;
}

/**
 * Gets selected server filters.
 *
 * @returns {Array}
 */
function getServerFilters() {

    var hostNameFilters = $("#hostNameFilters").find(":checked");

    var filters = [];

    // Loop over components, add and remove the appropriate filters
    hostNameFilters.each(function() {

        filters.push($(this).data("host"));
    });

    return filters;
}