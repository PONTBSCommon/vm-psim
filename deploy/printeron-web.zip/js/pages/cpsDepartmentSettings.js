/**
 * Shows the right div, based on the selector.
 */
function showRightDiv() {

    // Get your value
    var option = $("#ldapDepartmentSelect").find("option:selected").val();

    // Hide all divs
    $(".departmentSettings").hide();

    // Show the right div
    if(option == "") {
        $("#newDepartment").show();
        $("#deleteButton").attr("disabled", true);
    } else {
        $("#" + option).show();
        $("#deleteButton").removeAttr("disabled");
    }
}

/**
 * On change for department selector.
 */
$("#ldapDepartmentSelect").change(function() {

    showRightDiv();

});

/**
 * On click for drop down.
 */
$(".groupSelectLink").click(function() {

    // Get the selected UUID and covert to a selector
    var option = $("#ldapDepartmentSelect").find("option:selected").val();
    var selector = "";
    if(option == "") {
        selector = "#newDepartment";
    } else {
        selector = "#" + option;
    }

    // Replace div with the selected one
    $(selector + " .targetNameInput").val(this.innerHTML);

});

/**
 * On submit
 */
$("#submitButton").click(function() {

    /**Linked Printer Departments: at least one department is checked**/
        //Get total of checked boxes
    var atLeastOneIsChecked = $("#linkedPrinterDepartments input:checkbox").is(':checked');
    if (!atLeastOneIsChecked) {
        alert("Linked Printer Departments: Please check at least one option");
        return false;
    }
})

/**
 * On click of the delete button.
 */
$("#deleteButton").click(function() {

    // Get the selected option
    var option = $("#ldapDepartmentSelect").find("option:selected").val();
    var uuid = $("#uuid").val();
    var url = "";

    // If the UUID isn't there, must be a global setting
    if(uuid) {
        url = CONTEXT + "/cps/" + uuid + "/authentication/ldapDepartment/" + option;
    } else {
        url = CONTEXT + "/authentication/ldapDepartment/" + option;
    }

    // Do the ajax call
    ajax({
        url: url,
        type: "DELETE",
        success: function () {

            // Remove option
            $("#ldapDepartmentSelect").find("option[value='"+option+"']").remove();

            // Show the right div
            showRightDiv();
        },
        error: function() {
            notifyError($("#deleteErrorMessage").val());
        }
    });
});

/**
 * Load the document.
 */
$(document).ready(function() {

    // Show the right div on start up
    showRightDiv();

    var ldapAll = $(".ldapDepartmentAll");

    //disable department checkboxes if allow all is checked
    ldapAll.each(function () {
        var index = $(this).data("index");
        if ($(this).is(":checked")) {
            $(".ldapDepartment-"+index).each(function () {
                $(this).attr("checked", false);
                $(this).attr("disabled", true);
            });
        }
        else {
            $(".ldapDepartment-"+index).each(function () {
                $(this).attr("disabled", false);
            });
        }
    });


    //set up event to take care of this in the future
    ldapAll.on("change", function () {
        var index = $(this).data("index");
        if ($(this).is(":checked")) {
            $(".ldapDepartment-"+index).each(function () {
                $(this).attr("checked", false);
                $(this).attr("disabled", true);
            });
        }
        else {
            $(".ldapDepartment-"+index).each(function () {
                $(this).attr("disabled", false);
            });
        }
    });

});