/**
 * Created by bershaa on 1/13/2015.
 */
$(function() {
    $( "#accordion" ).accordion({
        heightStyle: "content"
    });

    $('#editUserLookupFrame').load(function() {
        var params = $("#editUserLookupFrame").contents().find("#apiServiceForm")[0].action;
        var action = getUrlParameter(params,"saved");

        if(action == "true") {
            closeEdit();
        }
    });

    showHide();

    $('#identified_guest_SendRC').click(function() {
        enableDisableFields1();
    });

    $('#identified_nonguest_SendRC').click(function() {
        enableDisableFields2();
    });

    $('#unidentified_guest_SendRC').click(function() {
        enableDisableFields3();
    });

    $('#unidentified_nonguest_SendRC').click(function() {
        enableDisableFields4();
    });

    $("#integrationType").change(function () {
        showHide();
    });

    $("#identified_guest_ActionMode").change(function () {
        enableDisableFields1();
    });

    $("#identified_nonguest_ActionMode").change(function () {
        enableDisableFields2();
    });

    $("#unidentified_guest_ActionMode").change(function () {
        enableDisableFields3();
    });

    $("#unidentified_nonguest_ActionMode").change(function () {
        enableDisableFields4();
    });

    enableDisableFields1();
    enableDisableFields2();
    enableDisableFields3();
    enableDisableFields4();
});

function enableDisableFields1(){
    var actionMode = $("#identified_guest_ActionMode").val();

    var enabled = true;

    if(actionMode == "DEFAULT_ENABLE_WEB_AUTH" || actionMode == "REJECT_JOBS"){
        $("#identified_guest_SendRC").attr("disabled", true);
        $("#identified_guest_setRCAsJobOwner").attr("disabled", true);
    }else{
        if($("#identified_guest_SendRC").is(':disabled')){
            $("#identified_guest_SendRC").removeAttr("disabled");
        }

        enabled = $("#identified_guest_SendRC").prop('checked');

        if (enabled != true)
            $("#identified_guest_setRCAsJobOwner").attr("disabled", true);
        else
            $("#identified_guest_setRCAsJobOwner").removeAttr("disabled");
    }
}

function enableDisableFields2(){
    var actionMode = $("#identified_nonguest_ActionMode").val();

    if(actionMode == "DEFAULT_ENABLE_WEB_AUTH" || actionMode == "REJECT_JOBS"){
        $("#identified_nonguest_SendRC").attr("disabled", true);
        $("#identified_nonguest_setRCAsJobOwner").attr("disabled", true);
    }else {
        if ($("#identified_nonguest_SendRC").is(':disabled')) {
            $("#identified_nonguest_SendRC").removeAttr("disabled");
        }

        enabled = $("#identified_nonguest_SendRC").prop('checked');

        if (enabled != true)
            $("#identified_nonguest_setRCAsJobOwner").attr("disabled", true);
        else
            $("#identified_nonguest_setRCAsJobOwner").removeAttr("disabled");
    }
}

function enableDisableFields3(){
    var actionMode = $("#unidentified_guest_ActionMode").val();

    if(actionMode == "DEFAULT_ENABLE_WEB_AUTH" || actionMode == "REJECT_JOBS"){
        $("#unidentified_guest_SendRC").attr("disabled", true);
        $("#unidentified_guest_setRCAsJobOwner").attr("disabled", true);
    }else {
        if ($("#unidentified_guest_SendRC").is(':disabled')) {
            $("#unidentified_guest_SendRC").removeAttr("disabled");
        }

        enabled = $("#unidentified_guest_SendRC").prop('checked');

        if (enabled != true)
            $("#unidentified_guest_setRCAsJobOwner").attr("disabled", true);
        else
            $("#unidentified_guest_setRCAsJobOwner").removeAttr("disabled");
    }
}

function enableDisableFields4(){
    var actionMode = $("#unidentified_nonguest_ActionMode").val();

    if(actionMode == "DEFAULT_ENABLE_WEB_AUTH" || actionMode == "REJECT_JOBS"){
        $("#unidentified_nonguest_SendRC").attr("disabled", true);
        $("#unidentified_nonguest_setRCAsJobOwner").attr("disabled", true);
    }else {
        if ($("#unidentified_nonguest_SendRC").is(':disabled')) {
            $("#unidentified_nonguest_SendRC").removeAttr("disabled");
        }

        enabled = $("#unidentified_nonguest_SendRC").prop('checked');

        if (enabled != true)
            $("#unidentified_nonguest_setRCAsJobOwner").attr("disabled", true);
        else
            $("#unidentified_nonguest_setRCAsJobOwner").removeAttr("disabled");
    }
}


function showHide(){
    var integrationType = $("#integrationType").val();

    if(integrationType == "NONE" || integrationType == "USERIDFROMEMAIL")
        $("#userLookupPanel").hide();
    else
        $("#userLookupPanel").show();
}

function showEdit(){
    $('#edit-userlookup').modal('show');
}


function closeEdit(){
    $('#edit-userlookup').modal('hide');
    refresh();
}

function getUrlParameter(source,sParam)
{
    var n = source.lastIndexOf('?');
    var result = source.substring(n + 1);

    var sURLVariables = result.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}


