$(document).ready(function () {
    toggleScheduledSync();

    $("#enableAutoSync").change(function () {
       toggleScheduledSync();
   });
});

function toggleScheduledSync () {
    if ($("#enableAutoSync").is(":checked")) {
        $("#cpsUpdatePrintersInterval").prop("disabled", false);
    }
    else {
        $("#cpsUpdatePrintersInterval").prop("disabled", true);
    }
}

function syncPrinters() {

    notifyInfo($("#status-syncing-printers").val());
    startSpinnerOnButton('#syncPrintersButton');

    var form = $("#pdgBasicSettingsForm");

    ajax({
        type: "POST",
        url: window.location.pathname + "/syncPrinters",
        data: form.serialize(),

        success : function(response) {
            notifySuccess(response);
        },

        error : function(xhr) {
            defaultErrorFunction(xhr, form);
        },

        complete: function() {
            stopSpinnerOnButton('#syncPrintersButton');
        }
    });
}