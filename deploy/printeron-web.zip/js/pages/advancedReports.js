$(document).ready(function () {
    initDatePickers();

    $(".exportReport").click(function () {
        var link = $(this).data("link");
        var from = $($(this).data("from")).datepicker("getDate");
        var till = $($(this).data("till")).datepicker("getDate");

        // Adjust the end to the end of the day
        till.setHours(23);
        till.setMinutes(59);
        till.setSeconds(59);
        till.setMilliseconds(999);

        // Convert to epoch millis
        from = from.getTime();
        till = till.getTime();

        window.location.href = link + "?from=" + from + "&till=" + till;
    });

    $(".generateReport").each(function () {
        $(this).click(function () {
            var button = $(this);
            var table = $("#" + $(this).data("type"));
            var from = $($(this).data("from")).datepicker("getDate");
            var till = $($(this).data("till")).datepicker("getDate");
            var type = $(this).data("type");
            var wrapper = $("#" + type + "-wrapper");
            var row = $("#" + type + "-row");

            // Adjust the end to the end of the day
            till.setHours(23);
            till.setMinutes(59);
            till.setSeconds(59);
            till.setMilliseconds(999);

            // Convert to epoch millis
            from = from.getTime();
            till = till.getTime();

            startSpinnerOnButton(button);

            ajax({
                url : window.location + "/" + type,
                method : "GET",
                data : {from : from,
                    till: till
                },
                beforeSend: function () {
                    if (table.length) {
                        destroyChartAndDT(table);
                    }

                    startSpinner(row);
                },
                success: function (data) {
                    row.show();

                    stopSpinner(row);
                    stopSpinnerOnButton(button);

                    wrapper.html(data);

                    table = $("#" + type);
                    createChartAndDT(table);
                    convertDateTime(table);
                },
                error: function () {
                    row.show();

                    stopSpinner(row);
                    stopSpinnerOnButton(button);
                }
            });
        });
    });
});

function convertDateTime(table) {
    dtQueryRows(".convertDateTime", table).each(function () {
        // Make a date object out of the date
        var time = new Date(0);
        time.setUTCMilliseconds($(this).html());
        time = time.toLocaleString();

        $(this).html(time);
    });
}