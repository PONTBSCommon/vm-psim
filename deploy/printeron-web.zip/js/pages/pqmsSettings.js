/**
 * Created by szawlom on 10/7/2016.
 */
var dataTableWrapper = $("#pdgPrinters_wrapper");
var spinner = $("#dataTable-spinner");
var uuid = $("#uuid").val();
var clientname = $("#clientname").val();

$(document).ready(function (){
    prepareDataTable();

    $("#mapPrintersDialogClose").click(function () {
        $("#mapPrintersDialog").modal("hide");
    });

    useAjaxForForm("#pqmsMappings");
});

function showMapPrinterDialog(button){
    var localprinter = $(button).data('localprinter');
    $("#mapPrintersLabel").data('localprinter',localprinter );
    $("#mapPrintersLabel").data('number',$(button).data('number'));
    $("#mapPrintersLabel").text($(button).data('label') + " " + localprinter);
    $("#mapPrintersDialog").modal("show");
}

function removePrinter(button){
    var inputGroup = $('#input-group-' + $(button).data('number'));

    inputGroup.find("input[type='text']").val("");
    inputGroup.find("input[type='hidden']").val("");
}

function showDataTableLoading () {
   dataTableWrapper.hide();
   spinner.show();
}

function hideDataTableLoading () {
    spinner.hide();
    dataTableWrapper.show();
}

function prepareDataTable () {

    var table = $("#pqmsPrinters");

    showDataTableLoading();
    dtLoad("#pqmsPrinters", {
        ajax: {
            "url" : CONTEXT + "/pdg/" + uuid + "/printers/list",
            "complete" : hideDataTableLoading
        },
        fnRowCallback: function( nRow, aData ) { return decorateRow(nRow, aData); },
        serverSide: true,
        columns: [
            {data : "airDisplay"},
            {data : "printeronName"}
        ],
        selectableRows : true
    });
}

function decorateRow (nRow, aData) {
    $(nRow).data("airDisplay", aData["airDisplay"]);
    $(nRow).data("printeronName", aData["printeronName"]);
}

function mapSelectedPrinter(){
    var selectedPrinter = $("#pqmsPrinters tr.selected");
    var airDisplay =  selectedPrinter.data('airDisplay');
    var printeronName =  selectedPrinter.data('printeronName');

    var inputGroup = $('#input-group-' + $("#mapPrintersLabel").data('number'));

    inputGroup.find("input[type='text']").val(airDisplay);
    inputGroup.find("input[type='hidden']").val(printeronName);

    $("#mapPrintersDialog").modal("hide");
}

