/**
 * Created by bershaa on 2/5/2015.
 */
$(function () {$( document ).tooltip();});