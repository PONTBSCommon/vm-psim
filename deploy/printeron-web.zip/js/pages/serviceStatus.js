// Get possible status values
var statusStopped = $('#status-1').val();
var statusStarting = $('#status-2').val();
var statusStopping = $('#status-3').val();
var statusRunning = $('#status-4').val();
var statusContinuing = $('#status-5').val();
var statusPausing = $('#status-6').val();
var statusPaused = $('#status-7').val();
var statusUnknown = $('#status-8').val();
var statusNotInstalled = $('#status-9').val();
var statusRestarting = $('#status-restarting').val();

/**
 * Shows buttons for a running service.
 *
 * @param uuid The server UUID.
 * @param serviceId The service ID.
 */
function showRunningButtons(uuid, serviceId) {
    dtQueryRows("#restart_" + uuid + "_" + serviceId).removeAttr("disabled");
    dtQueryRows("#stop_" + uuid + "_" + serviceId).removeAttr("disabled");
    dtQueryRows("#start_" + uuid + "_" + serviceId).attr("disabled", "true");
}

/**
 * Shows buttons for a stopped service.
 *
 * @param uuid The server UUID.
 * @param serviceId The service ID.
 */
function showStoppedButtons(uuid, serviceId) {
    dtQueryRows("#restart_" + uuid + "_" + serviceId).attr("disabled", "true");
    dtQueryRows("#stop_" + uuid + "_" + serviceId).attr("disabled", "true");
    dtQueryRows("#start_" + uuid + "_" + serviceId).removeAttr("disabled");
}

/**
 * Show buttons for an unknown service state.
 *
 * @param uuid The server UUID.
 * @param serviceId The service ID.
 */
function disableServiceButtons(uuid, serviceId) {
    dtQueryRows("#restart_" + uuid + "_" + serviceId).attr("disabled", "true");
    dtQueryRows("#stop_" + uuid + "_" + serviceId).attr("disabled", "true");
    dtQueryRows("#start_" + uuid + "_" + serviceId).attr("disabled", "true");
}

/**
 * Updates service buttons for the UUID.
 *
 * @param status The status string.
 * @param uuid The UUID.
 * @param serviceId The service ID.
 */
function updateServiceButtons(status, uuid, serviceId) {

    // If it's running, show restart and stop
    if (status == statusRunning) {
        showRunningButtons(uuid, serviceId);
    }

    // Not running, show start
    else if (status == statusStopped){
        showStoppedButtons(uuid, serviceId);
    }

    else {
        disableServiceButtons(uuid, serviceId);
    }
}

/**
 * Executes a service action.
 *
 * @param action String action to do.
 * @param uuid String UUID to apply it to.
 * @param serviceId The service ID.
 * @param progressStatus String that should be the interim status.
 * @param successStatus The string to show on success.
 * @param errorStatus The error status.
 * @param statusDiv The status Div.
 */
function executeAction(action, uuid, serviceId, progressStatus, successStatus, errorStatus, statusDiv) {

    var url = CONTEXT + "/ajax/status/services/";

    // If we have a UUID, add it to the url
    if(uuid) {
        url += uuid + "/";
    }

    // Add the service ID and action
    url += serviceId + "/" + action;


    // Do the ajax call
    ajax({
        url: url,
        type: "POST",
        beforeSend: function(xhr) {
            statusDiv.html(progressStatus);
            disableServiceButtons(uuid, serviceId);
        },
        success: function() {
            statusDiv.html(successStatus);
            updateServiceButtons(successStatus, uuid, serviceId);
        },
        error: function(error) {
            statusDiv.html(errorStatus);
            updateServiceButtons(errorStatus, uuid, serviceId);
            notifyError(error.responseText);
        }
    });
}

/**
 * Does preparation of the document.
 */
$(document).ready(function () {

    // Load the datatable
    dtLoad("#servicesTable", {"order": [[$("#serviceStatus").index(), 'asc']]});

    // Loop over all status' and enable/disable buttons
    dtQueryRows("[id^=status_]").each(function () {

        var splitId = this.id.split('_');

        // Get the status and UUID
        var status = $(this).html().trim();
        var uuid = splitId[1];
        var serviceId = splitId[2];

        updateServiceButtons(status, uuid, serviceId);
    });

    // Make the start onClick
    dtQueryRows(".serviceStartButton").click(function () {

        $(this).blur();

        var splitId =  this.id.split('_');

        // Get required info
        var uuid = splitId[1];
        var serviceId = splitId[2];
        var statusDiv = $("#status_" + uuid  + "_" + serviceId);
        var currentStatus = statusDiv.html().trim();
        var action = $("#action-START").val();

        // Execute
        executeAction(action, uuid, serviceId, statusStarting, statusRunning, currentStatus, statusDiv);
    });

    // Make the stop onClick
    dtQueryRows(".serviceStopButton").click(function () {

        $(this).blur();

        var splitId =  this.id.split('_');

        // Get required info
        var uuid = splitId[1];
        var serviceId = splitId[2];
        var statusDiv = $("#status_" + uuid  + "_" + serviceId);
        var currentStatus = statusDiv.html().trim();
        var action = $("#action-STOP").val();

        // Execute
        executeAction(action, uuid, serviceId, statusStopping, statusStopped, currentStatus, statusDiv);
    });

    // Make the restart onClick
    dtQueryRows(".serviceRestartButton").click(function () {

        $(this).blur();

        var splitId =  this.id.split('_');

        // Get required info
        var uuid = splitId[1];
        var serviceId = splitId[2];
        var statusDiv = $("#status_" + uuid  + "_" + serviceId);
        var currentStatus = statusDiv.html().trim();
        var action = $("#action-RESTART").val();

        // Execute
        executeAction(action, uuid, serviceId, statusRestarting, statusRunning, currentStatus, statusDiv);
    });
});