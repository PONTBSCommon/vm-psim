/**
 * Created by bershaa on 1/5/2015.
 */
var editId = -1;

function closeAddEdit(){
    $('#jobProcessorDialog').modal('hide');

    if(editId == -1)
        notifySuccess($("#jobProcessorAddSuccess").val());
    else
        notifySuccess($("#jobProcessorEditedSuccess").val());

    setTimeout( function(){
            location.reload();
        }, 2000 );
}

function getUrlParameter(source,sParam)
{
    var n = source.lastIndexOf('?');
    var result = source.substring(n + 1);

    var sURLVariables = result.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

function showAddEdit(id) {
    editId = id;

    if (id != -1)
        $("#jobProcessorDialog").find(".modal-body").html("<iframe src=\"modal/edit?index=" + id + "\" id='jobProcessorFrame'></iframe>");
    else
        $("#jobProcessorDialog").find(".modal-body").html("<iframe src='modal/add' id='jobProcessorFrame'></iframe>");

    $('#jobProcessorFrame').load(function() {

        onFrameLoad();
    });

    $('#jobProcessorDialog').modal('show');
}

function onFrameLoad(){
    var params = $("#jobProcessorFrame").contents().find("#addEditForm")[0].action;

    var action = getUrlParameter(params,"saved");

    if(action == "true") {
        closeAddEdit();
    }
}

var currentForm;

function deleteJobProcessor(index){
    $('#delete-confirm').modal('show');

    toDelete = index;

    currentForm = $("#jobProcessorForm")[0];
}

$(document).ready(function() {
    $('#jobProcessorFrame').load(function() {
        onFrameLoad();
    });
});

function deleteConfirmYES() {
    $("#delete-confirm").modal("hide");
    currentForm.action = currentForm.action + "/modal/delete/" + toDelete;
    currentForm.submit();
}