/**
 * Created by bershaa on 2/26/2015.
 */
$(function () {
    $('#jstree')
        // listen for event
        .on('select_node.jstree', function (e, data) {
            alert("Are you sure you want to import PDS settings for PDS with serial number: " + data.instance.get_node(data.selected[0]).id);
        })
        // create the instance
        .jstree();


});