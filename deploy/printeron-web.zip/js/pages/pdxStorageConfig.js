/**
 * Created by bershaa on 6/6/2016.
 */

$(function()
{
    showPanel();

    $("#storageType").change(showPanel);

    $("#cancelRebootPrompt").click(closePromptReboot);

    $("#closeRebootPrompt").click(closePromptReboot);
});

function showPanel()
{
    if ($("#storageType").val() == "LOCAL")
    {
        $("#s3panel").hide();
        $("#local").show();
    }
    else if ($("#storageType").val() == "S3")
    {
        $("#s3panel").show();
        $("#local").hide();
    }
}

function promptReboot()
{
    $('#reboot-required').modal('show');
}

function closePromptReboot()
{
    $('#reboot-required').modal('hide');
}

function applySettings()
{
    $('#storageForm').submit();

    return false;
}