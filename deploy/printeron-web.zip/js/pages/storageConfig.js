/**
 * Created by bershaa on 6/6/2016.
 */

$(function()
{
    if($("#pdhStorageType").val() == "S3")
        showPanel();

    $("#pdhStorageType").change(showPanel);

    if($("#previewS3check").attr("checked") != "checked")
    {
        showPreviewS3();
    }

    if($("#printUriPanelS3check").attr("checked") != "checked")
    {
        showPrintUriS3();
    }

    $("#cancelRebootPrompt").click(closePromptReboot);

    $("#closeRebootPrompt").click(closePromptReboot);

});

function showPreviewS3()
{
    $("#previewPanelS3").slideToggle('slow');

    if ($("#previewS3check").prop("checked") == false)
    {
        if($("#optimizeJobDelivery").prop("checked") == true)
        {
            $("#optimizeJobDelivery").click();
        }
    }
}

function optimizeClicked()
{
    //we cannot have optimized it having it go to a different
    //s3 instance
    if($("#optimizeJobDelivery").prop("checked") == true)
    {
        if ($("#previewS3check").prop("checked") == false)
        {
            $("#previewS3check").click();
        }

        if ($("#printUriPanelS3check").prop("checked") == false)
        {
            $("#printUriPanelS3check").click();
        }
    }
}

function showPrintUriS3()
{
    $("#printUriPanelS3").slideToggle('slow');

    if ($("#printUriPanelS3check").prop("checked") == false)
    {
        if($("#optimizeJobDelivery").prop("checked") == true)
        {
            $("#optimizeJobDelivery").click();
        }
    }
}

function showPanel()
{
    if ($("#pdhStorageType").val() == "LOCAL")
    {
        $("#s3Panel").slideToggle('slow');
        $("#printUriPanel").slideToggle('slow');
        $("#previewPanel").slideToggle('slow');
    }
    else if ($("#pdhStorageType").val() == "S3")
    {
        $("#s3Panel").slideToggle('slow');
        $("#printUriPanel").slideToggle('slow');
        $("#previewPanel").slideToggle('slow');
    }
}

var sameAsAboveClicked;

function optimizedWarningYES() {
    $("#optimizedWarning").modal("hide");

    if(sameAsAboveClicked == "preview")
        showPreviewS3();

    if(sameAsAboveClicked == "printuri")
        showPrintUriS3();
}

function optimizedWarningNO() {
    $("#optimizedWarning").modal("hide");

    if(sameAsAboveClicked == "preview")
        $("#previewS3check").prop('checked', true);

    if(sameAsAboveClicked == "printuri")
        $("#printUriPanelS3check").prop('checked', true);
}

function optimizedWarningPreview()
{
    sameAsAboveClicked = "preview";

    if($("#previewS3check").prop("checked") == false && $("#optimizeJobDelivery").prop("checked") == true)
        $("#optimizedWarning").modal("show");
    else
        showPreviewS3();
}

function optimizedWarningPrinturi()
{
    sameAsAboveClicked = "printuri";

    if($("#printUriPanelS3check").prop("checked") == false && $("#optimizeJobDelivery").prop("checked") == true)
        $("#optimizedWarning").modal("show");
    else
        showPrintUriS3();
}

// For Agent Reboot All
function promptReboot()
{
    $('#reboot-required').modal('show');
}

function closePromptReboot()
{
    $('#reboot-required').modal('hide');
}

function applySettings()
{
    $('#storageForm').submit();

    return false;
}