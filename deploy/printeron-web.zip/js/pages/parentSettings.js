/**
 * JS for the parent settings page.
 *
 * @author Lukas Rezek <lrezek@printeron.com>
 */

var onlineMessage = $("#onlineMessage").val();
var offlineMessage = $("#offlineMessage").val();

/**
 * Runs on start, registers on clicks.
 */
$(document).ready(function() {

    $("#disconnectButton").click(manualDisconnect);

    useAjaxForForm($("#parent"),{
        beforeSend: function() {
            startSpinnerOnButton("#connectButton");
        },
        success: function (data) {

            // Update the status span and notify
            notifySuccess(data);
            $("#status").html(onlineMessage);

            // Enable disconnect button
            $('#disconnectButton').prop('disabled', false);
        },
        complete: function() {
            stopSpinnerOnButton("#connectButton");
        }
    });

    useAjaxForForm($("#authentication"),{
        beforeSend: function() {
            startSpinnerOnButton("#applySettings");
        },
        success: function (data) {
            notifySuccess(data);
        },
        complete: function() {
            stopSpinnerOnButton("#applySettings");
        }
    });
});

/**
 * Manually disconnects from the parent server.
 */
function manualDisconnect() {

    startSpinnerOnButton("#disconnectButton");

    ajax({
        url: CONTEXT + "/ajax/parent/disconnect",
        type: "POST",
        success: function(data) {

            $("#parentURL").val("");

            // Change to disconnected
            $("#status").html(offlineMessage);

            // Stop polling, and clear spinner
            stopSpinnerOnButton("#disconnectButton");

            // Disable button and notify
            $('#disconnectButton').prop('disabled', true);
            notifySuccess(data);
        },
        error: function(data) {

            // Stop spinner and show error
            stopSpinnerOnButton("#disconnectButton");
            notifyError(data);
        }
    });
}