/**
 * Progress indicator helper methods.
 *
 * @author Lukas Rezek <lrezek@printeron.com>
 */

/**
 * Map of ladda buttons, so you don't have re-initialize ladda every time.
 *
 * @type {Array}
 * @private
 */
var _laddaButtons = [];

/**
 * The ladda style to use for buttons.
 *
 * @type {string}
 * @private
 */
var _laddaStyle = "expand-right";

/**
 * Class string for spin js wrapper.
 *
 * @type {string}
 * @private
 */
var _spinJsWrapper = "spinJsWrapper";

/**
 * The spinner class to use.
 *
 * @type {string}
 * @private
 */
var _spinnerClass = "spinJs";

/**
 * Define spinner defaults.
 *
 * @type {{}}
 */
var spinner = {

    large: {
        lines: 12,
        length: 10,
        width: 4,
        radius: 10
    },

    normal: {
        lines: 10,
        length: 8,
        width: 4,
        radius: 8
    },

    small: {
        lines: 10,
        length: 6,
        width: 2,
        radius: 4
    }
};

/**
 * Starts progress on a button.
 *
 * @param button The button jquery object, or a selector
 */
function startSpinnerOnButton(button) {

    // Wrap in a jquery selector so you can pass a selector or an object
    button = $(button);

    var l = _getLaddaButtonObject(button);

    if(l) {
        l.ladda("start");
    }
}

/**
 * Stops the spinner on a button.
 *
 * @param button The button jquery object or selector.
 */
function stopSpinnerOnButton(button) {

    // Wrap in a jquery selector so you can pass a selector or an object
    button = $(button);

    var l = _getLaddaButtonObject(button);

    if(l) {
        _removeLaddaButtonObject(button);

        l.ladda("stop");
    }
}

/**
 * Starts a standard spinner inside the specified element.
 *
 * @param el The elements jquery object or selector.
 * @param options The spinner options (use one of the presets defined in this file).
 * @param pad Whether or not to pad the wrapper.
 */
function startSpinner(el, options, pad) {

    // Wrap in a jquery selector so you can pass a selector or an object
    el = $(el);

    // Options weren't passed, use default
    if(!options) {
        options = spinner.normal;
    }

    // Default to having padding
    if(typeof pad === "undefined") {
        pad = true;
    }

    // Add the className to the options
    options.className = _spinnerClass;

    // Add a spin wrapper for every element that doesn't have one
    el.each(function() {

        var $this = $(this),
            wrapper = $this.children("." + _spinJsWrapper);

        // No spinner wrapper, make one and start spinning
        if(wrapper.length == 0) {

            var height = (pad ? (2 * _spinnerHeight(options)) : _spinnerHeight(options)) + "px";

            // Create the wrapper span
            var wrapperSpan = $("<span />")
                .addClass(_spinJsWrapper)
                .css("position", "relative")
                .css("display", "block")
                .css("margin", "0 auto")
                .css("padding", 0)
                .css("height", height)
                .css("width", height);

            // Add it to the element
            $this.prepend(wrapperSpan);

            // Start spinning
            wrapperSpan.spin(options);
        }
    });
}

/**
 * Stops a spinner in an element.
 *
 * @param el The element the spinner was started on.
 */
function stopSpinner(el) {

    // Wrap in a jquery selector so you can pass a selector or an object
    el = $(el);

    el.each(function() {

        var $this = $(this),
            wrapper = $this.children("." + _spinJsWrapper);

        // Have a wrapper
        if(wrapper.length != 0) {

            // Stop the spinner
            wrapper.spin(false);

            // Remove the wrapper from the DOM
            wrapper.remove();
        }
    });
}

/**
 * Initializes ladda support on a button.
 *
 * @param button The button jquery object.
 * @returns {*} Ladda object.
 * @private
 */
function _getLaddaButtonObject(button) {

    // Cannot get ladda button object for a button that's hidden (The height is used to specify spinner size)
    if(button.height() && button.height() > 0) {

        var id = button.attr("id");

        if (!id) {
            console.log("Cannot get a Ladda object for a button without an ID");
            return null;
        }

        // Not in the buttons array, add it on
        if (!_laddaButtons[id]) {

            // Add the required attributes
            _addButtonAttributes(button);

            // Add it to the map
            _laddaButtons[id] = button.ladda();
        }

        return _laddaButtons[id];
    }

    return null;
}

function _removeLaddaButtonObject(button) {
    var id = button.attr("id");

    if (!id) {
        console.log("Cannot get a Ladda object for a button without an ID");
        return null;
    }

    if (_laddaButtons[id]) {
        delete _laddaButtons[id];
    }
}

/**
 * Ensures the button has the required attributes, but doesn't override existing ones.
 *
 * @param button The button.
 * @private
 */
function _addButtonAttributes(button) {

    // Add ladda class to button if it doesn't have it
    if(!button.hasClass("ladda-button")) {
        button.addClass("ladda-button");
    }

    // Add data style to button if it doesn't have it
    if(!button.attr("data-style")) {
        button.attr("data-style", _laddaStyle);
    }
}

/**
 * Get the spinner height for the given options.
 *
 * @param opts The options.
 * @private
 */
function _spinnerHeight(opts) {

    return 2 * (opts.radius + opts.length);

}