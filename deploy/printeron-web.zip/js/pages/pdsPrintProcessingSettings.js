var disableInputsLookup = {
    'spoolLocally' : ['#printJobDir'],
    'enableMaximumJobSizeLimit' : ['#maximumJobSizeLimit'],
    'enableFailedJobRetry' : ['#failedJobRetryLimit', '#failedJobRetryInterval'],
    'enableFailedJobPurge' : ['#failedIntervalValue'],
    'enableAbandonedJobPurge' : ['#abandonedJobPurgeInterval']
};

function checkSpool () {
    if (!$('#spoolLocally').is(':checked')) {
        $('#spoolLocally').trigger('click');
    }
}

function disableInputs (element) {
    var inputsToDisable = disableInputsLookup[element.attr('id')],
        input;
    for (input in inputsToDisable) {
        $(inputsToDisable[input]).prop('disabled', !element.is(':checked'));
    }
}

function disableInputsById (id) {
    var inputsToDisable = disableInputsLookup[id],
        input;
    for (input in inputsToDisable) {
        $(inputsToDisable[input]).prop('disabled', !element.is(':checked'));
    }
}

//Brings up a modal to confirm or deny an action.
//Calls confirmFunction on "Yes" and rejectFunction on "No"
//Both function calls are optional
function confirmChoice (message, confirmFunction, rejectFunction) {
    $("#confirmModal").find(".modal-body").html(message);

    if (typeof confirmFunction !== "undefined") {
        $("#modal-button-yes").click(confirmFunction);
    }

    if(typeof rejectFunction !== "undefined") {
        $("#modal-button-no").click(rejectFunction);
    }

    $("#confirmModal").modal("show");
}

$(document).on('click', '#spoolLocally', function () {
    if (!$(this).prop("checked")) {
        confirmChoice("Spooling print job data locally enhances data transer reliability when crossing the Internet and allows Print Delivery Station to receive jobs locally (via the Local Listener). <br/> <br/>Are you sure you wish to disable local spooling of print job data?", function () {}, checkSpool);
    }
});

$(document).on('click', '.disables-inputs', function () {disableInputs($(this))});

$(document).ready( function () {
    for (inputs in disableInputsLookup) {
        disableInputs($('#' + inputs));
    }
});
