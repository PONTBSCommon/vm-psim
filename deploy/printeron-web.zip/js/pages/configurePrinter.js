// @author Robert Bowering <RBowering@printeron.com>


var printerLabel = $("#printerDesc");
var _crsID2_masterList;

var codeXerox = 'Secure Print Code';
var codeRicoh = 'Locked Print Password';

// Default value for sessionMetaDataLabel is defined in CPS default_printer.xml
var defaultSessionMetaDataLabel = "Password";

var qrCode;

var DISABLED = 3;

$(document).ready(function () {

    var el = document.getElementById("qrCodeWrapper");

    //initialize QR Code
    qrCode = new QRCode(el, {text: "test", height: 100, width: 100});

    // Set up our event listeners

    $(".PDSLinkProtocol").click(function () {
        $("#pdsLinkProtocol").html($(this).html());
        updatePDSLink();
    });

    $(".IPPLinkProtocol").click(function () {
        $("#ippLinkProtocol").html($(this).html());
        updateIppLink();
    });

    $(".PDHLinkProtocol").click(function () {
        $("#pdhLinkProtocol").html($(this).html());
        updatePDHLink();
    });

    $("input.form-control").on("change keyup paste", clearMessageError);

    $("#pdsLink").change(updatePDSLink);

    $("#ippLink").change(updateIppLink);

    $("#pdhLink").change(updatePDHLink);

    $("#emailDomain").change(updatePrinterEmails);
    $("#printerOnName").change(function () {
        updatePrinterEmails();
        $("#summary-printerOnName").html($(this).val());
    });

    // Hide drivers, then bind the listener
    $("#printDriverFamily").change(togglePrintDriverInfo);

    $(".driver-select").click(function () {
        // They selected a driver, so hide the url field
        $("#printerDriverUrlWrapper").hide();
        // Also clear the value so we don't send it back
        $("#printerDriverUrl").val("");

        // Populate the text field with the selected value
        $("#printDriver").val($(this).data("value"));

        updatePrinterModelSuggestions();
    });

    $("#enableIntegration").click(togglePrintManagementService);

    $("#crsId").change(toggleAdditionalIntegration);

    togglePrintDriverInfo();

    $("#releaseCodeUse").change(function () {
        toggleReleaseCodeOptions();
    });

    $("#releaseCodeAutoGenerate").click(toggleReleaseCodeCheckboxes);

    $("#currentLabelLanguage").change(setLabelLanguage);

    $(".printerModelNameListItemText").click(function () {
        $("#printerModelName").val($(this).html());
    });

    $("#printerDesc").change(function () {
        $("#summary-printerDesc").html($(this).val());
    });

    $("#payPerPrint").click(togglePaymentOptions);

    $("#taxInclude").click(toggleIncludeTaxes);

    $("#printToPDS").click(toggleUsePDH);

    dtLoad("#paperSizes", {"order": [[ 1, "asc" ]]});

    $("#qrAuth").change(updateConfigureQrCode);

    $("#qrDirectPrint").change(updateConfigureQrCode);

    $("#emailPrinting").click(toggleEmailPrint);

    $("#allowPrintToPDS").change(toggleAllowPrintToPDS);

    $("#allowPrintToPDH").change(toggleAllowPrintToPDH);

    $("#clientUidUse").change(function () {
        $("input[name='clientUidUse']").val($(this).val());
    });

    $("#ippPrinter").click(toggleIppPrinterSettings);

    _crsID2_masterList = $("#crsId2").html();

    $('#paperSizes').on('click', 'input[type="checkbox"]', function()
    {
        var paperSizeId = $(this).val();

        if(!$(this).prop("checked"))
        {
            removeMediaPriceById(paperSizeId);
        }
        else
        {
            if(!paperSizePriceExists(paperSizeId))
            {
                addPaperSizePrice(paperSizeId);

                showPrices($("#duplexingType").val());
            }
        }

        reIndexMediaPriceList();

        changeCurrencySymbol(getSymbolByCurrencyId($("#currencyId").find(":selected").val()));

    });

    $(".sampleUrlButton").click(function () {
       $($(this).data("destination")).val($(this).data("value"));
    });

    $(".aaaAuthUrlEnableCheckbox").click(enableDisableAuthUrls);

    $("#mapPrinters").on("click", function () {
        var uuid = $(this).data("pds");

        $("#selectPhysicalPrinter").one("draw.dt", function () {

            if (dtGetSelectedRowIndexes($(this)).length == 0) {
                $("#mapPrintersButton").prop("disabled", true);
            }

            $(this).on("dt.selection.updated", function () {
                if (dtGetSelectedRowIndexes($(this)).length) {
                    $("#mapPrintersButton").prop("disabled", false);
                }
                else {
                    $("#mapPrintersButton").prop("disabled", true);
                }
            });
        });

        if (! $.fn.DataTable.isDataTable( '#selectPhysicalPrinter' )) {
            dtLoad("#selectPhysicalPrinter", {
                ajax: {
                    url: CONTEXT + "/pds/" + uuid + "/printers/physicalPrinters"
                },
                serverSide: true,
                columns: [
                    {data: "printer"},
                    {data: "serverName"}
                ],
                selectableRows: true,
                multiSelectRows: false
            });
        }
        else {
            dtResetSelectedRows("#selectPhysicalPrinter");
            dtUnloadUUID("#selectPhysicalPrinter");
            $("#selectPhysicalPrinter").DataTable().ajax.url(CONTEXT + "/pds/" + uuid + "/printers/physicalPrinters").load();
            dtRedraw(true, "#selectPhysicalPrinter");
        }
    });

    $("#mapPrinters").click(function () {
        $("#editPrinterDialog").modal("hide");
        $("#physicalPrintersDialog").modal("show");
    });

    $("#physicalPrintersDialog").on("hide.bs.modal", function () {
        $("#editPrinterDialog").modal("show");
    });

    $("#mapPrintersButton").click(function () {
        $("#locIpScheme").val("UNKNOWN");
        $("#locIpPath").val(dtGetSelectedRows("#selectPhysicalPrinter").find("td:first-child").html());
        $("#physicalPrintersDialog").modal("hide");
    });

    $("#mapNetworkPrinters").on("click", function () {
        var uuid = $(this).data("pds");

        $("#selectNetworkPrinter").one("draw.dt", function () {

            if (dtGetSelectedRowIndexes($(this)).length == 0) {
                $("#mapNetworkPrintersButton").prop("disabled", true);
            }

            $(this).on("dt.selection.updated", function () {
                if (dtGetSelectedRowIndexes($(this)).length) {
                    $("#mapNetworkPrintersButton").prop("disabled", false);
                }
                else {
                    $("#mapNetworkPrintersButton").prop("disabled", true);
                }
            });
        });

        if (! $.fn.DataTable.isDataTable( '#selectNetworkPrinter' )) {
            dtLoad("#selectNetworkPrinter", {
                ajax: {
                    url: CONTEXT + "/pds/" + uuid + "/printers/networkPrinters"
                },
                serverSide: true,
                columns: [
                    {data: "printer"},
                    {data: "serverName"}
                ],
                selectableRows: true,
                multiSelectRows: false
            });
        }
        else {
            dtResetSelectedRows("#selectNetworkPrinter");
            dtUnloadUUID("#selectNetworkPrinter");
            $("#selectNetworkPrinter").DataTable().ajax.url(CONTEXT + "/pds/" + uuid + "/printers/networkPrinters").load();
            dtRedraw(true, "#selectNetworkPrinter");
        }
    });

    $("#mapNetworkPrinters").click(function () {
        $("#editPrinterDialog").modal("hide");
        $("#networkPrintersDialog").modal("show");
    });

    $("#networkPrintersDialog").on("hide.bs.modal", function () {
        $("#editPrinterDialog").modal("show");
    });

    $("#mapNetworkPrintersButton").click(function () {
        $("#locIpScheme").val("UNKNOWN");
        $("#locIpPath").val(dtGetSelectedRows("#selectNetworkPrinter").find("td:first-child").html());
        $("#networkPrintersDialog").modal("hide");
    });

    $.fn.dataTable.ext.order['dom-checkbox'] = function  ( settings, col )
    {
        return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
            return $('input', td).prop('checked') ? '0' : '1'; // so checked will be sorted first
        } );
    };

    $("#paperSizePanel").on("click", function () {
        //to order desc as soon as the page loads, because the default is 'asc'
        var table = $('#paperSizes').DataTable();
        // Sort by column 1 and then re-draw
        table
            .order( [ 1, 'asc' ] )
            .draw();
    });

    $("#finishingOptionPanel").on("click", function () {
        checkColourPrintingValue();
    });
});

function addPaperSizePrice(paperSizeId)
{
    var name = dtQueryRows("#paperSizeDisplay-" + paperSizeId, "#paperSizes").html().split("(")[0];

    var index = $(".row.priceList").length;

    addMediaPrice(paperSizeId, name, index, "", "");
}

function paperSizePriceExists(paperSizeId)
{
    if($("input[data-papersize='" + paperSizeId + "']").length)
    {
        return true;
    }
        return false;
}

function clearMessageError()
{
    var control = $(this);

    control.removeClass("error");

    var errorMessage = control.parents().closest(".row").children(".errorMessage");

    $(errorMessage).html("");

}

function toggleIppPrinterSettings ()
{
    var printToPds = $("#printToPDS");

    if ($("#isPull").val() == 'false')
    {
        if ($("#ippPrinter").is(":checked"))
        {
            $("#pdsLinkPrinterNum").hide();
            $("#pdhLinkPrinterNum").hide();
            $("#linkedPDSRow").hide();

            $("#ippLinkRow").show();
            $("#pdsLinkRow").hide();
            $("#fullIppLink").prop("disabled", false);
            $("#fullPDSLink").prop("disabled", true);

            $("#outputDestinationRow").hide();

            $("#allowPrintToPDS").prop("checked", true);
            $("#allowPrintToPDSRow").hide();

            printToPds.prop("checked", true);
            printToPds.addClass("disabled");
            printToPds.attr("onclick", "return false");

            $("#pdhLink").prop("readonly", true);
            $("#printToPDSRow").hide();

            $("#allowPrintToPDH").prop("checked", false);
            $("#allowPrintToPDHRow").hide();

            $("#pdhLinkRow").hide();

            $("#releaseModePrintSpot").prop("checked", true);
            $(".releaseModeRow").hide();
        }
        else
        {
            $("#pdsLinkPrinterNum").show();
            $("#pdhLinkPrinterNum").show();
            //Connect Edition
            if ($("#isConnectEdition").val() == 'false')
            {
                $("#linkedPDSRow").show();
                $("#allowPrintToPDSRow").show();
                $("#printToPDSRow").show();
                $("#allowPrintToPDHRow").show();
            }

            $("#pdhLinkRow").show();

            $("#ippLinkRow").hide();
            $("#pdsLinkRow").show();
            $("#fullIppLink").prop("disabled", true);
            $("#fullPDSLink").prop("disabled", false);

            $("#outputDestinationRow").show();

            $(".releaseModeRow").show();

            printToPds.removeClass("disabled");
            printToPds.attr("onclick", "");
            toggleUsePDH();
        }
    }
    toggleAllowPrintToPDH();
    toggleAllowPrintToPDS();
}

function updateConfigureQrCode () {
    qrCode.clear();
    qrCode.makeCode(getQrCodeUrl());
}

function setLabelLanguage () {
    var language = $("#currentLabelLanguage").find("option:selected").data("languagecode");
    $(".labelLanguage").hide();
    $(".label-" + language).show();
}

function toggleReleaseCodeCheckboxes () {

    var forceNumeric = $("#releaseCodeForceNumeric");
    var autoGenerate = $("#releaseCodeAutoGenerate");

    if (autoGenerate.is(":checked")) {
        forceNumeric.prop("checked", true);
        forceNumeric.addClass("disabled");
        forceNumeric.attr("onclick", 'return false');
    }
    else {
        forceNumeric.removeClass("disabled");
        forceNumeric.attr("onclick", '');
    }
}

function togglePaymentOptions () {

    var payPerPrint = $("#payPerPrint");
    var paymentOptions = $("#paymentOptions");

    if (payPerPrint.is(":checked"))
    {
        paymentOptions.show();
    }
    else
    {
        paymentOptions.hide();
    }
}

function toggleIncludeTaxes () {

    var taxIncluded = $("#taxInclude");
    var taxRate = $("#taxRate");

    if (taxIncluded.is(":checked"))
    {
        taxRate.prop('disabled', true);
        taxRate.val('');
    }
    else
    {
        taxRate.prop('disabled', false);
    }
}

function togglePrintManagementService () {
    var enable = $("#enableIntegration");
    var wrapper = $("#printManagementServiceWrapper");

    if (enable.is(":checked")) {
        wrapper.find("select").prop("disabled", false);
        wrapper.find("input[type='checkbox']").removeClass("disabled").attr("onclick", "");
    }
    else {
        $("#crsId").val([]);
        $("#crsId2").val([]);

        wrapper.find("select").prop("disabled", true);
        wrapper.find("input[type='checkbox']").addClass("disabled").attr("onclick", "return false").attr("checked", false);
    }

    toggleAdditionalIntegration();
}

function toggleAdditionalIntegration () {
    var crs = $("#crsId");
    var additional = $("#crsId2");
    additional.html(_crsID2_masterList);

    var samSecure = additional.find("option[value='SamSecureMode1']");
    var samSecureCode = additional.find("option[value='SamSecureReleaseCodeMode1']");
    var samBCPS = additional.find("option[value='SamBCPSMode1']");
    var secuPrint = additional.find("option[value='SecuPrintMode1']");
    var litech = additional.find("option[value='LitechMode1']");
    var equitrac = additional.find("option[value='EquitracMode1']");
    var samsungPinCodeAccounting = additional.find("option[value='SamsungPinMode1']");
    var samsungSecuThruPro = additional.find("option[value='SamSecuThruMode1']");
    var authorizationIntegration = $("#authorizationIntegration");
    var clientUidUse = $("#clientUidUse");
    var clientUidLabel = $(".clientUidLabel");

    var selectedHtml = crs.find("option:selected").html();

    if (selectedHtml == "Equitrac - Printer Release Server")
    {
        setMetadataForSecurePrint(false, '');
        authorizationIntegration.attr("checked", false);
        authorizationIntegration.attr("onclick", "return false");
        authorizationIntegration.addClass('disabled');
        
        secuPrint.remove();
        litech.remove();
        equitrac.remove();
        samsungSecuThruPro.remove();
        samBCPS.remove();

        additional.prop("disabled", false);

        clientUidUse.prop("disabled", false);
        clientUidLabel.prop("readonly", false);
    }
    else if (selectedHtml == "Samsung BCPS" || selectedHtml == "Samsung SecuThru Pro")
    {
        setMetadataForSecurePrint(false, '');
        authorizationIntegration.attr("checked", false);
        authorizationIntegration.attr("onclick", "return false");
        authorizationIntegration.addClass('disabled');

        samSecure.remove();
        samsungSecuThruPro.remove();
        litech.remove();
        equitrac.remove();
        secuPrint.remove();
        samSecureCode.remove();
        samBCPS.remove();

        additional.prop("disabled", false);

        clientUidUse.prop("disabled", false);
        clientUidLabel.prop("readonly", false);
    }
    else if (selectedHtml == "SecuPrint")
    {
        setMetadataForSecurePrint(false, '');
        authorizationIntegration.attr("checked", false);
        authorizationIntegration.attr("onclick", "return false");
        authorizationIntegration.addClass('disabled');

        secuPrint.remove();
        litech.remove();
        equitrac.remove();
        additional.prop("disabled", false);

        clientUidUse.prop("disabled", false);
        clientUidLabel.prop("readonly", false);
    }
    else if (selectedHtml == "Konica-Minolta SecurePrint")
    {
        setMetadataForSecurePrint(false, '');
        additional.prop("disabled", true);

        samSecureCode.remove();
        samBCPS.remove();

        authorizationIntegration.removeClass('disabled');
        authorizationIntegration.attr("onclick", "");

        clientUidUse.prop("disabled", false);
        clientUidLabel.prop("readonly", false);
    }
    else if (selectedHtml == "Samsung Secure Release Code")
    {
        setMetadataForSecurePrint(false, '');
        authorizationIntegration.attr("checked", false);
        authorizationIntegration.attr("onclick", "return false");
        authorizationIntegration.addClass('disabled');

        samsungPinCodeAccounting.remove();
        samSecure.remove();
        samsungSecuThruPro.remove();
        secuPrint.remove();
        equitrac.remove();
        samSecureCode.remove();
        samBCPS.remove();

        additional.prop("disabled", false);

        clientUidUse.prop("disabled", false);
        clientUidLabel.prop("readonly", false);
    }
    else if (selectedHtml == "Samsung PIN Code Accounting")
    {
        setMetadataForSecurePrint(false, '');
        additional.val([]);
        additional.prop("disabled", true);
        
        clientUidUse.val("1");
        clientUidUse.trigger("change");

        clientUidUse.prop("disabled", true);
        clientUidLabel.prop("readonly", true);

        samSecureCode.remove();
        samBCPS.remove();

        $("#clientUidSecured").prop("checked", true).addClass("disabled");
        $("label[for='clientUidSecured']").attr("onclick", "return false");
    }
    else if (selectedHtml == "Ricoh Locked Print")
    {
        additional.val("null");
        additional.prop("disabled", true);

        authorizationIntegration.removeClass('disabled');
        authorizationIntegration.attr("onclick", "");

        clientUidUse.prop("disabled", false);
        clientUidLabel.prop("readonly", false);

        setMetadataForSecurePrint(true, codeRicoh);
    }
    else if (selectedHtml == "Xerox Secure Print")
    {
        additional.val("null");
        additional.prop("disabled", true);

        authorizationIntegration.removeClass('disabled');
        authorizationIntegration.attr("onclick", "");

        clientUidUse.prop("disabled", false);
        clientUidLabel.prop("readonly", false);

        setMetadataForSecurePrint(true, codeXerox);
    }
    else
    {
        setMetadataForSecurePrint(false, '');
        if ($("#crsId").find("option:selected").html() == "Ricoh User Codes") {
            clientUidUse.val(1);
            clientUidUse.trigger("change");
            clientUidUse.prop("disabled", true);
            clientUidLabel.prop("readonly", true);
        }
        else
        {
            clientUidUse.prop("disabled", false);
            clientUidLabel.prop("readonly", false);
        }

        authorizationIntegration.attr("checked", false);
        authorizationIntegration.attr("onclick", "return false");
        authorizationIntegration.addClass('disabled');

        $("#clientUidSecured").removeClass("disabled");
        $("label[for='clientUidSecured']").attr("onclick", "");

        additional.val("null");
        additional.prop("disabled", true);
    }
}

function togglePrintDriverInfo () {
    var familySelect = $("#printDriverFamily");
    var driver = $("#printDriver");
    var driverButton = $("#driverButton");

    if (familySelect.val() == "customDriver") {
        // Hide all drivers
        $(".driver-listItem").hide();

        driver.prop("readOnly", false);
        driverButton.prop("disabled", true);
        $("#printerDriverUrlWrapper").show();
    }
    else {
        var family = familySelect.val();

        // Hide all drivers
        $(".driver-listItem").hide();

        // Show drivers of the selected family
        $(".driver-listItem[data-family='" + family + "']").show();

        driver.prop("readOnly", true);
        driverButton.prop("disabled", false);
        $("#printerDriverUrlWrapper").hide();
    }
}

function updatePDSLink () {
    $("#fullPDSLink").val($("#pdsLinkProtocol").html() + $("#pdsLink").val());
}

function updateIppLink () {
    $("#fullIppLink").val($("#ippLinkProtocol").html() + $("#ippLink").val());
}

function updatePDHLink () {
    $("#fullPDHLink").val($("#pdhLinkProtocol").html() + $("#pdhLink").val());
}

function clearConfigurePrinterForm () {

    // Remove any paper sizes inputs from the previous request (they will be remade before the form is submitted)
    $("#configurePrinterForm").find("input[name='paperSizes']").remove();

    $(".priceList").remove();

    //clear all inputs
    $("input", "#configurePrinterForm").each(function () {

        //if it's a checkbox, uncheck it
        if ($(this).attr("type") == "checkbox" || $(this).attr("type") == "radio")
        {
            $(this).attr("checked", false);
        }
        //otherwise, simply clear the value
        else
        {
            $(this).val("");
        }

        //remove the error class from the input
        $(this).removeClass("error");
    });

    $("h4.errorHeading").removeClass("errorHeading");

    // Uncheck the paper size checkboxes inside of the dataTable
    dtQueryRows("input[name='paperSizes-temp']", "#paperSizes").each(function () {
        $(this).prop("checked", false);
        $(this).removeClass("disabled");
    });

    dtQueryRows("label", "#paperSizes").attr("onclick", "");

    // Reset paper sizes table back to page 1
    dtResetPage("#paperSizes");

    $("select", "#configurePrinterForm").not("[name='paperSizes_length']").val([]);

    //collapse the panels
    $("#collapsePrinterConfiguration").attr("aria-expanded", false).removeClass("in");
    $("#collapsePrinterLocation").attr("aria-expanded", false).removeClass("in");
    $("#collapsePrinterDriverConfiguration").attr("aria-expanded", false).removeClass("in");
    $("#collapseWebPrintWhereEmail").attr("aria-expanded", false).removeClass("in");
    $("#collapseJobUserInfo").attr("aria-expanded", false).removeClass("in");
    $("#collapseOutputOptions").attr("aria-expanded", false).removeClass("in");
    $("#collapsePaperSizes").attr("aria-expanded", false).removeClass("in");
    $("#collapsePDS").attr("aria-expanded", false).removeClass("in");
    $("#collapseReleaseModeInfo").attr("aria-expanded", false).removeClass("in");
    $("#collapseLabel").attr("aria-expanded", false).removeClass("in");
    $("#collapsePayment").attr("aria-expanded", false).removeClass("in");
    $("#collapseAuthorizingUsers").attr("aria-expanded", false).removeClass("in");
    $("#collapseOutputLocation").attr("aria-expanded", false).removeClass("in");
    $(".panel-title > *[aria-expanded=true]", "#configurePrinterForm").attr("aria-expanded", false);

    //clear the printer number
    $("#printerNumber").html("");
    $("#pdsLinkPrinterNum").html("");
    $("#pdhLinkPrinterNum").html("");

    //hide the qrCode
    $("#qrCodeWrapper").hide();

    //get rid of any error messages
    $(".errorMessage", "#configurePrinterForm").html("");
}

function toggleEmailPrint() {
    var emailBody = $("#emailPrintingBody");

    if ($("#emailPrinting").is(":checked")) {
        emailBody.removeClass("disabled");
        emailBody.attr("onclick", '');
    }
    else {
        emailBody.prop("checked", false);
        emailBody.addClass("disabled");
        emailBody.attr("onclick", 'return false');
    }
}

function toggleAllowPrintToPDS()
{
    var pdsLinkRow = $("#pdsLinkRow");
    var printToPDSRow = $("#printToPDSRow");

    // Determine if IPP is checked
    var ippChecked = $("#isPull").val() == 'false' && $("#ippPrinter").is(":checked");

    if ($("#allowPrintToPDS").is(":checked"))
    {
        if (!ippChecked) {
            pdsLinkRow.show();

            //Connect Edition
            if ($("#isConnectEdition").val() == 'false')
            {
                printToPDSRow.show();
            }
        }
    }
    else
    {
        pdsLinkRow.hide();
        $("#pdsLink").val('');

        printToPDSRow.hide();
        $("#printToPDS").prop('checked', false);

        toggleUsePDH();
    }
}

function toggleAllowPrintToPDH()
{
    var pdhLinkRow = $("#pdhLinkRow");

    if ($("#allowPrintToPDH").is(":checked"))
    {
        pdhLinkRow.show();
    }
    else
    {
        pdhLinkRow.hide();
        $("#pdhLink").val('');
    }
}

function updatePrinterModelSuggestions () {
    var printerDriver = $("#printDriver");

    // Hide all, then show the ones we need
    $(".printerModelNameListItem").hide();

    if (printerDriver.val() == "Samsung Universal EMU V1") {
        $(".emuV1").show();
        $("#printerModelDropdownButton").prop("disabled", false);
    }
    else if (printerDriver.val() == "Samsung Universal EMU V2") {
        $(".emuV2").show();
        $("#printerModelDropdownButton").prop("disabled", false);
    }
    else if (printerDriver.val() == "Samsung Universal EMU V3") {
        $(".emuV3").show();
        $("#printerModelDropdownButton").prop("disabled", false);
    }
    else {
        $("#printerModelDropdownButton").prop("disabled", true);
    }
}

function createQrCode () {
    qrCode.clear();
    qrCode.makeCode(getQrCodeUrl());
    $("#qrCodeWrapper").show();
}

function getQrCodeUrl () {
    var sauth = $("#qrAuth").is(":checked") ? 1 : 0;
    var dp = $("#qrDirectPrint").is(":checked") ? 1: 0;
    return "pon://?pid=" + $("#printerNumber").html() + "&surl=" + $("#serviceUrl").val() + "&sauth=" + sauth + "&dp=" + dp;
}

function updateRemoteReleaseUrl () {

    var serviceUrl = $("#serviceUrl").val();

    // If the service url does not end with a /, add a slash
    if(!serviceUrl.endsWith("/")) {
        serviceUrl = serviceUrl + "/";
    }

    $("#remoteReleaseUrl").html(serviceUrl + "release/" + $("#printerNumber").html() + "/");
}

function updatePrinterEmails () {
    var emailDomain = $("#emailDomain").val();

    if (emailDomain.trim() == "") {
        $("#emailPrintAddresses").hide();
    }
    else {
        var printerNumberVal = $("#printerNumber").html();
        if (printerNumberVal.length <= 3) {
            printerNumberVal = " ";
        }
        else {
            printerNumberVal = printerNumberVal.substr(3);
        }
        var firstAddress = printerNumberVal + "@" + emailDomain;
        var secondAddress = $("#printerOnName").val() + "@" + emailDomain;

        $("#emailPrintAddress1").html(firstAddress);
        $("#emailPrintAddress2").html(secondAddress);

        $("#emailPrintAddresses").show();
    }

}

function toggleReleaseCodeOptions() {
    var releaseCodeVal = $("#releaseCodeUse").val();

    var releaseCodeMoreOptions = $("#releaseCodeMoreOptions");
    var checkboxes = releaseCodeMoreOptions.find("input[type='checkbox']");
    var checkboxLabels = releaseCodeMoreOptions.find("input[type='checkbox'] + label");

    if (releaseCodeVal == DISABLED) {
        checkboxes.prop("checked", true); //sub options always enabled
        checkboxes.addClass("disabled");
        checkboxes.attr("onclick", 'return false');
        checkboxLabels.attr("onclick", 'return false');
    }
    else {
        checkboxes.prop("checked", true);
        checkboxes.removeClass("disabled");
        checkboxes.attr("onclick", '');
        checkboxLabels.attr("onclick", '');

        toggleReleaseCodeCheckboxes();
    }
}

function changeDefaultPaperSize(id, label) {
    var defaultPaperSize = $("#defaultPaperSize");
    var current = defaultPaperSize.val();
    dtQueryRows("#paperSize-" + current, "#paperSizes").removeClass("disabled");
    dtQueryRows("#paperSize-" + current, "#paperSizes").attr("onclick", "");
    dtQueryRows("label[for='paperSize-"  + current + "']", "#paperSizes").attr("onclick", "");

    dtQueryRows("#paperSize-" + id, "#paperSizes").prop("checked", true);
    dtQueryRows("#paperSize-" + id, "#paperSizes").addClass("disabled");
    dtQueryRows("#paperSize-" + id, "#paperSizes").attr("onlcick", "return false");
    dtQueryRows("label[for='paperSize-"  + id + "']", "#paperSizes").attr("onclick", "return false");

    defaultPaperSize.val(id);
    $("#defaultPaperSize-display").html(label);

    if(!paperSizePriceExists(id))
    {
        addPaperSizePrice(id);
        showPrices($("#duplexingType").val());
        changeCurrencySymbol(getSymbolByCurrencyId($("#currencyId").find(":selected").val()));
    }
}

function toggleUsePDH() {
    var allowPDH = $("#allowPrintToPDH");
    var allowPDHLabel = $("label[for='allowPrintToPDH']");

    if ($("#printToPDS").is(":checked")) {
        allowPDH.prop("checked", false);
        allowPDH.addClass("disabled");
        allowPDH.attr("onclick", "return false");
        allowPDHLabel.attr("onclick", "return false");

        $("#pdhLink").prop("readonly", true);
    }
    else {
        allowPDH.removeClass("disabled");
        allowPDH.attr("onclick", "");
        allowPDHLabel.attr("onclick", "");

        $("#pdhLink").prop("readonly", false);
    }

    toggleAllowPrintToPDH();
}

function changeCurrencySymbol(symbol)
{
    $(".curSymbol").each(function()
    {
        $(this).text(symbol);
    });
}

function getSymbolByCurrencyId(id)
{
    return $("#" + id).prop("name");
}

function addMediaPrice(id, name, index, simplexPrice, duplexPrice)
{
    var mediaPriceRowDiv = $("<div class='row priceList' ></div>");

    var mediaNameCol = $("<div class='col-md-4'><label>" + name + "</label></div>");

    mediaPriceRowDiv.append(mediaNameCol);

    var simplexCol = $("<div class='col-md-6 simplexCol'></div>");

    var simplexRow = $("<div class='row'></div>");

    var simplexFormGroup = $("<div class='form-group'></div>");

    var simplexInputGroup = $("<div class='input-group' style='padding-right: 20px;'></div>");

    simplexInputGroup.append("<div class='input-group-addon curSymbol'>$</div>");

    simplexInputGroup.append("<input type='text' data-papersize='" + id + "' id='mediaModelList[" + index + "].simplexPrice' value='" + simplexPrice + "' name='mediaModelList[" + index + "].simplexPrice' class='form-control'/><label for=''></label>");

    simplexInputGroup.append("<div class='input-group-addon'>/pg</div></div>");

    simplexFormGroup.append(simplexInputGroup);

    simplexRow.append(simplexFormGroup);

    simplexRow.append("<div class='errorMessage'></div>");

    simplexCol.append(simplexRow);

    simplexCol.append("<input type='hidden' name='mediaModelList[" + index + "].num' value='" + id + "'/>");

    var duplexCol = $("<div class='col-md-6 duplexCol'></div>");

    var duplexFormGroup = $("<div class='form-group'></div>");

    var duplexInputGroup = $("<div class='input-group' style='padding-left: 20px;'></div>");

    var duplexRow = $("<div class='row'></div>");

    duplexInputGroup.append("<div class='input-group-addon curSymbol'>$</div>");

    duplexInputGroup.append("<input type='text' id='mediaModelList[" + index + "].duplexPrice' name='mediaModelList[" + index + "].duplexPrice' value='" + duplexPrice + "'class='form-control'/><label for=''></label>");

    duplexInputGroup.append("<div class='input-group-addon'>/pg</div>");

    duplexFormGroup.append(duplexInputGroup);

    duplexRow.append(duplexFormGroup);

    duplexRow.append("<div class='col-xs-1 errorMessage'></div>");

    duplexCol.append(duplexRow);

    var alignDiv = $("<div class='col-md-8'></div>");

    alignDiv.append(simplexCol);
    alignDiv.append(duplexCol);
    mediaPriceRowDiv.append(alignDiv);

    $("#paymentWrapper").append(mediaPriceRowDiv);
}

function clearMediaPrices()
{
    $("#paymentWrapper").remove();
}

function getMediaPriceIndexById(id)
{
    return $("input[value|='" + id + "'][type='hidden']").attr("name").split("[")[1].charAt(0);
}

function getMediaSimplexPriceById(id)
{
    var index = getMediaPriceIndexById(id);

    return $("#mediaModelList\\[" + index + "\\]\\.simplexPrice").val();
}

function getMediaDuplexPriceById(id)
{
    var index = getMediaPriceIndexById(id);

    return $("#mediaModelList\\[" + index + "\\]\\.duplexPrice").val();
}

function removeMediaPriceById(id)
{
    return $("input[data-paperSize='" + id + "']").parents(".priceList").remove();
}

function reIndexMediaPriceList()
{
    $(".priceList").each(function(i, obj)
    {
        var elementIndex = $(obj).find("input[name*='simplex']").attr("name").split("[")[1].split("]")[0];

        if(elementIndex > i)
        {
            $(obj).find("input[name*='simplex']").attr("name", "mediaModelList[" + i + "].simplexPrice");
            $(obj).find("input[name*='simplex']").attr("id", "mediaModelList[" + i + "].simplexPrice");

            $(obj).find("input[name*='duplex']").attr("name", "mediaModelList[" + i + "].duplexPrice");
            $(obj).find("input[name*='duplex']").attr("id", "mediaModelList[" + i + "].duplexPrice");

            $(obj).find("input[name*='num']").attr("name", "mediaModelList[" + i + "].num");
        }

    });
}

$('#colourPrinting').on('change', function () {
    checkColourPrintingValue();
});

function checkColourPrintingValue()
{
    $( "#colourPrinting option:selected" ).each(function() {
        if ($(this).val() == 1) //Supports colour printing
        {
            $('#bwColourDefault').removeClass('colourDefault');
        }
        else
        {
            $('#bwColourDefault').addClass('colourDefault');
        }
    });
}

function setMetadataForSecurePrint(active, codeLabel) {
    var sessionMetadataUse = $("#sessionMetaDataUse");
    var sessionMetadataSecured = $("#sessionMetaDataSecured");
    var sessionMetadataLabel = $("#sessionMetaDataLabelByLanguage-en_us");

    if (active)
    {
        // set to required
        sessionMetadataUse.find('option[value="1"]').prop("selected", true);
        sessionMetadataUse.addClass("disabled");
        // check secured
        sessionMetadataSecured.prop("checked", true);
        sessionMetadataSecured.addClass("disabled");
        sessionMetadataSecured.attr("onclick", 'return false');
        // sets label
        sessionMetadataLabel.val(codeLabel);
        sessionMetadataLabel.prop("readonly", true);

    } else if ((sessionMetadataLabel.val() == codeRicoh) || (sessionMetadataLabel.val() == codeXerox)) {
        // set to disabled
        sessionMetadataUse.find('option[value="3"]').prop("selected", true);
        sessionMetadataUse.removeClass("disabled");
        // uncheck secured
        sessionMetadataSecured.prop("checked", false);
        sessionMetadataSecured.removeClass("disabled");
        sessionMetadataSecured.attr("onclick", '');
        // reset label
        sessionMetadataLabel.val(defaultSessionMetaDataLabel);
        sessionMetadataLabel.prop("readonly", true);
    }
}