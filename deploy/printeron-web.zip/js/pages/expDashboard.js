/**
 * Created by bershaa on 12/8/2014.
 */

$(function () {
    $('#tabs-left')
        .tabs();

    $("a.tabref").click(function() {
        loadTabFrame($(this).attr("href"),$(this).attr("rel"));
    });
});


function loadTabFrame(tab, url) {
    if ($(tab).find("iframe").length == 0) {
        var html = [];
        html.push('<div class="tabIframeWrapper">');
        html.push('<iframe class="iframetab" src="' + url + '">Load Failed?</iframe>');
        html.push('</div>');
        $(tab).append(html.join(""));
        $(tab).find("iframe").height($(window).height());
    }
    return false;
}