/**
 * Created by leibolr on 7/10/2017.
 */

/**
 * currentForm is used for deleting a sentinel master from the list
 */
var currentForm;

function deletePromptYES() {
    currentForm.submit();
}


/**
 * Onload - Functionality for changing the redis Config UI based on the Connection Type selected (Single, Sentinel, Cluster)
 */
$(function(){

    $('#deleteSentinelForm').submit(function() {

        currentForm = this;

        $('#delete-prompt').modal('show');

        return false;
    });

    if ($("#redisCachingEnabled").is(":checked")) {
        showRedisConfig();
    }

    $("#redisCachingEnabled").change(showRedisConfig);

    $("#redisConnectionType").change(showRedisConfig);
});


function showRedisConfig() {

    if ($("#redisCachingEnabled").is(":checked")) {
        $("#redisCache").slideDown('slow');

        if ($("#redisConnectionType").val() == "SINGLE") {
            $(".cluster").slideUp('slow');
            $(".sentinel").slideUp('slow');
            $(".single").slideDown('slow');
            $(".single").slideDown('slow');
        }
        else if ($("#redisConnectionType").val() == "SENTINEL") {
            $(".cluster").slideUp('slow');
            $(".single").slideUp('slow');
            $(".sentinel").slideDown('slow');
            $(".sentinel").slideDown('slow');
        }
        else if ($("#redisConnectionType").val() == "CLUSTER") {
            $(".single").slideUp('slow');
            $(".sentinel").slideUp('slow');
            $(".cluster").slideDown('slow');
            $(".cluster").slideDown('slow');
        }
    }
    else {
        $("#redisCache").slideUp('slow');

        $(".single").slideDown('slow');
        $(".sentinel").slideDown('slow');
        $(".cluster").slideDown('slow');
    }
}

// For Agent Reboot All
function promptReboot() {
    $('#reboot-required').modal('show');
}

function noRestartPdh() {
    $('#restartPdhOnSave').val('N');

    applySettings();
}

function restartPdh() {
    $('#restartPdhOnSave').val('Y');


    $('#pdh-restarting').modal('show');
    $('#reboot-required').modal('hide');

    applySettings();
}

function applySettings() {
    $('#redisConfigSettings').submit();

    return false;
}
