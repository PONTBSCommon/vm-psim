/**
 * Created by bershaa on 2/18/2015.
 */
function calcHeight()
{
    $("#spinner").hide();
    $("#workflowFrame").show();

    //find the height of the internal page
    var the_height = $('#workflowFrame')[0].contentWindow.document.body.scrollHeight;

    //change the height of the iframe
    $('#workflowFrame')[0].height = the_height;

    var iFrame = "#workflowFrame";
    var contents = $(iFrame).contents();

    contents.find("body").on('click', function(){

        parent.$('#workflowFrame').trigger('click');

    });

    var email = $("#emailType", contents);
    if (email.length) {
        email.click(function () {
            $("#workflowFrame").height($("#pas", contents).height());
        });
    }
}