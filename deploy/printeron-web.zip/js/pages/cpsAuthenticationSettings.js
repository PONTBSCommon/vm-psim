/**
 * Gets the URL, based on whether we have a UUID.
 *
 * @return {string} The url.
 */
function getUrl() {

    var uuid = $("#uuid").val();

    if(uuid) {
        return CONTEXT + "/cps/" + uuid + "/authentication/"
    } else {
        return CONTEXT + "/authentication/"
    }
}

function populateThirdPartyFields(option)
{
    var authMethod = option;

    var ajaxCall = false;

    if (option == 'THIRD_PARTY')
    {

        // Find the selected option value for third party type
        var thirdPartyOption = $("#thirdPartyAuthenticationType").find("option:selected").val();

        // Show the relevant one
        $("#" + thirdPartyOption).show();

        authMethod = thirdPartyOption;

        ajaxCall = true;
    }
    else if (option == 'AZURE_AD')
    {
        ajaxCall = true;
    }

     if (ajaxCall) {
         ajax({
             url: getUrl() + "?authMethod=" + option,
             context: document.body,
             type: 'post',
             success: function (data) {
                 $("#" + authMethod).html($(data).find("#" + authMethod).html())
             },
             error: function () {
                 //this error should never happen
             },
             complete: function () {
                 bindEnableSyncClickEvent();
                 enableUserSync();
                 enableGroupSync();
             }
         });
     }
}

/**
 * Displays the correct div, based on the selected auth type.
 */
function displayCorrectDiv() {

    // Find the selected option value
    var option = $("#selectedAuthMethod").find("option:selected").val();

    // Hide all divs
    $(".authSetting").hide();

    //populate the fields on screen
    populateThirdPartyFields(option);

    displayGuestAndTrustedPrinters(option);

    // Show the relevant one
    $("#" + option).show();
}

function displayGuestAndTrustedPrinters(option)
{
    if (option == 'UNDEFINED'
        || option == 'NO_LOGIN')
    {
        $("#guestEnableTrustedPrinters").hide();
    }
    else
    {
        $("#guestEnableTrustedPrinters").show();
    }

}

/**
 * Displays the correct div, based on the selected auth type.
 */
function displayCorrectGuestDiv() {

    // Find the selected option value
    var option = $("#cpsLdapGuestSelect").find("option:selected").val();

    // Hide all divs
    $(".behaviourOption").hide();

    // Show the relevant one
    $("#" + option).show();
}

/**
 * On change for behaviour selector
 */
$("#cpsLdapGuestSelect").change(function() {
    displayCorrectGuestDiv();
});

/**
 * Enables or disables the manage departments button.
 */
function enableDisableManageDept() {

    var button = $("#manageDeptButton");

    // If CPS says we can manage departments, enable it (as long as group or OU is selected)
    if($("#departmentManagementEnabled").val() == "true") {

        // Disable manage if default button
        var ldapGroupOption = $("#cpsLdapDepartmentBehaviorDropDownInput").find("option:selected").val();
        if (ldapGroupOption == $("#defaultDepartment").val()) {
            button.addClass("btn-disabled");
            button.attr("title", $("#defaultDepartmentExplanation").val());
        } else {
            button.removeClass("btn-disabled");
            button.removeAttr("title");
        }
    } else {
        button.addClass("btn-disabled");
        button.attr("title", $("#disabledDepartmentExplanation").val());
    }
}

/**
 * Enables or disables guest settings link
 */
function enableDisableManageGuest() {

    // Disable manage guest button if guest is unchecked
    if ($("#guestEnabledInput").is(":checked")) {
        $("#manageGuestButton").removeAttr("disabled");
    } else {
        $("#manageGuestButton").attr("disabled", true);
    }
}

/**
 * Enables and disables the detail buttons.
 */
function enableDisableDetailButtons() {

    // Display the edit button if selected
    var option = $("#ldapDetailNamesDropDown").find("option:selected").val();

    var num = $("#ldapDetailNamesDropDown option").size();

    // If there is no selected option, disable the edit/delete button
    if(typeof option === 'undefined') {
        $("#detailEditButton").attr("disabled", true);
    } else {
        $("#detailEditButton").removeAttr("disabled");
    }

    // No delete if you have 1 or less detail sets
    if(num <= 1) {
        $("#detailDeleteButton").attr("disabled", true);
    } else {
        $("#detailDeleteButton").removeAttr("disabled");
    }

    $("#detailNewButton").removeAttr("disabled");

}

/**
 * Closes the guest dialog and reloads the page.
 */
function closeGuestDialog(){

    // Hide the modal
    $('#guestSettings').one('hidden.bs.modal', function(){
        // Reset selected guest setting to saved value
        $("#cpsLdapGuestSelect").val($("#savedGuestBehaviour").val()).change();
    }).modal('hide');
}

/**
 * On change for LDAP detail list, enable edit button.
 */
$("#ldapDetailNamesDropDown").change(function() {

    enableDisableDetailButtons();

});

/**
 * On change of the select, display the right div.
 */
$("#selectedAuthMethod").change(function() {

    // Show the right div
    displayCorrectDiv();

    // Show all the right states
    enableDisableDetailButtons();
    enableDisableManageDept();
    enableDisableManageGuest();
    setUpAdvancedView(ADVANCED_VIEW_ENABLED);

    SSLEnabledNotification();
});

/**
 * On change for LDAP departments
 */
$("#cpsLdapDepartmentBehaviorDropDownInput").change(function() {

    enableDisableManageDept()

});

/**
 * On change for guest enabled checkbox
 */
$("#guestEnabledInput").change(function() {

    enableDisableManageGuest()

});

/**
 * Display the right div on start up.
 */
$(document).ready(function() {

    $("#guestSettingsForm").submit(function(e){

        $("#guestSettingsApplyButton").hide();
        $("#loading").show();

        $(".formFieldError").remove();

        ajax({
            url: getUrl() + "modal/guest",
            context: document.body,
            type: 'post',
            data: $(this).serialize(),
            success: function () {

                // Save the setting we're on
                $("#savedGuestBehaviour").val($("#cpsLdapGuestSelect").val());

                notifySuccess($("#settingsSaved").val());
                $("#guestSettingsApplyButton").show();
                $("#loading").hide();
                closeGuestDialog();
            },
            error: function () {
                notifyError($("#settingsError").val());
                $("#guestSettingsApplyButton").show();
                $("#loading").hide();
            }
        });

        return false;
    });

    // Show all the right states
    enableDisableDetailButtons();
    enableDisableManageDept();
    enableDisableManageGuest();

    bindEnableSyncClickEvent();

    enableGroupSync();
    enableUserSync();

});

/**
 * On click for the detail edit button, redirect to the right edit page.
 */
$("#detailEditButton").click(function() {

    // Get the selected name
    var option = $("#ldapDetailNamesDropDown").find("option:selected").val();

    window.location.href = getUrl() + 'ldapDetail?detailName=' + option;

});

/**
 * On click for the detail new button, redirect to the right page.
 */
$("#detailNewButton").click(function() {

    window.location.href = getUrl() + 'ldapDetail/new';

});

/**
 * On click for the delete of a type.
 */
$("#detailDeleteButton").click(function() {

    // Get the selected option
    var option = $("#ldapDetailNamesDropDown").find("option:selected");
    var name = option.val();

    // Do the ajax call
    ajax({
        url: getUrl() + 'ldapDetail?detailName=' + name,
        type: "DELETE",
        success: function (resp) {

            // Set the dept management flag and enable/disable depts as required
            $("#departmentManagementEnabled").val(resp);
            enableDisableManageDept();

            // Remove option and enable/disable detail buttons as required
            option.remove();
            enableDisableDetailButtons();
        },
        error: function() {
            notifyError($("#deleteErrorMessage").val());
        }
    });

});

/**
 * On click for LDAP departments.
 */
$("#manageDeptButton").click(function() {

    // Only do stuff if you don't have the disabled button class
    if(!$(this).hasClass("btn-disabled")) {

        // Get selected department
        var option = $("#cpsLdapDepartmentBehaviorDropDownInput").find("option:selected").val();

        // Redirect to LDAP Departments
        window.location.href = getUrl() + 'ldapDepartment/' + option;
    }

});

/**
 * On click for Guest settings.
 */
$("#manageGuestButton").click(function() {

    $("#guestSettingsApplyButton").show();
    $("#loading").hide();
    $("#guestSettings").modal("show");

});

/**
 * On change of the selected third party type, display the right div.
 */
$("#thirdPartyAuthenticationType").change(function() {

    // Show the right div
    displayCorrectDiv();
});

function bindEnableSyncClickEvent() {
    /**
     * On change for enabled group sync checkbox
     */
    $("#enableGroupSync").click(function() {
        enableGroupSync();
    });

    /**
     * On change for enabled user sync checkbox
     */
    $("#enableUserSync").click(function() {
        enableUserSync();
    });
}

function enableGroupSync()
{
    if ($("#enableGroupSync").is(":checked")) {
        $("#groupSyncIntervalRow").show();
    }
    else
    {
        $("#groupSyncIntervalRow").hide();
    }
}

function enableUserSync()
{
    if ($("#enableUserSync").is(":checked")) {
        $("#userSyncIntervalRow").show();
    }
    else
    {
        $("#userSyncIntervalRow").hide();
    }
}

function SSLEnabledNotification()
{
    var isSSLEnabled = document.getElementById("SSLEnabled").value;
    var option = $("#selectedAuthMethod").find("option:selected").val();

    if ((isSSLEnabled == "false") && ((option == "PON_USERS") || (option == 'AZURE_AD'))) {
        $("#SSLEnabledDialog").modal("show");
    }
}