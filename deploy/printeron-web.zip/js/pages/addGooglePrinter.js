/**
 * Created by bershaa on 1/8/2015.
 */

function showLoading(){
    $("#spinner").show();
    $("#addPrinterPanel").hide();
}
