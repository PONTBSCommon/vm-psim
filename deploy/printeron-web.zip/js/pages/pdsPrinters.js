/**
 * Created by bershaa on 3/23/2015.
 */
var uuid = $("#uuid").val();
var clientname = $("#clientname").val();
var dataTableWrapper = $("#pdsPrinter-container");
var isPull = $("#isPull").val();

$(document).ready(function ()
{
    var printerListUrl = "";

    if(isPull == "true")
    {
        printerListUrl = CONTEXT + "/pds/" + uuid + "/printers/pull/list";
    }
    else
    {
        printerListUrl = CONTEXT + "/" + clientname + "/" + uuid + "/printers/list";
    }

    renderDataTable(printerListUrl);

    useAjaxForForm("#linkPrintersForm", {
        beforeSend: function (jqXHR, settings) {
            settings.data += "&availableUUID=" + dtGetUUID("#device-availablePrinters");
            startSpinnerOnButton("#linkPrintersSave");
        },
        complete: function () {
            stopSpinnerOnButton("#linkPrintersSave");

            $("#linkPrintersDialog").modal("hide");
            $("#physicalPrintersDialog").modal("show");

            var table = $("#pdsPrinters");
            dtUnloadUUID(table);
            dtRedraw(true, table);
        }
    });

    $("#linkPrintersDialogClose").click(function () {
        $("#linkPrintersDialog").modal("hide");
        $("#physicalPrintersDialog").modal("show");
    });

    $("#mapPrinters").one("click", function () {
       dtLoad("#selectPhysicalPrinter", {
           ajax: {
               url: CONTEXT + "/pds/" + uuid + "/printers/physicalPrinters"
           },
           serverSide: true,
           columns: [
               {data: "printer"},
               {data: "serverName"}
           ],
           selectableRows: true
       });

        $("#selectPhysicalPrinter").one("draw.dt", function () {
            $(this).on("dt.selection.updated", function () {
                if (dtGetSelectedRowIndexes($(this)).length) {
                   $("#mapPrintersButton").prop("disabled", false);
                }
                else {
                    $("#mapPrintersButton").prop("disabled", true);
                }
            });
        });

        $("#mapPrintersButton").on("click", function () {
            $("#physicalPrintersDialog").modal("hide");
            dtDestroy("#device-availablePrinters");
            dtDestroy("#device-linkedPrinters");
            startSpinner("#linkPrintersLoader");
            $("#linkPrintersLoader").show();
            $("#linkPrintersWrapper").hide();
            $("#linkPrintersDialog").modal("show");
            ajax({
                url: CONTEXT + "/pds/" + uuid + "/printers/ajax/getLinkPrintersBody/" ,
                method: "GET",
                data: dtGetTableParamsForAjax("#selectPhysicalPrinter"),
                beforeSend: function () {
                    startSpinnerOnButton($("#mapPrintersButton")) ;
                },
                success: function (data) {
                    $("#linkPrintersWrapper").html(data);
                    $("#linkPrintersDialogTitle").html($("input[name='device']").val());
                    stopSpinner("#linkPrintersLoader");
                    $("#linkPrintersLoader").hide();
                    $("#linkPrintersWrapper").show();
                    linkedDataTables({
                        "#device-linkedPrinters":{
                            ajax: {
                                url: CONTEXT + "/pds/" + uuid + "/printers/mapPrinters/linking/linked"
                            },
                            serverSide: true,
                            columns : [
                                {data: "printeronName", "class": "printeronName"},
                                {data: "device", "class": "device"}
                            ],
                            "fnServerParams": function ( aoData ) {
                                aoData = $.extend(true, aoData, {
                                    device: $("input[name='device']").val()
                                });
                            },
                            form: "#linkPrintersForm"
                        },
                        "#device-availablePrinters": {
                            ajax: {
                                url: CONTEXT + "/pds/" + uuid + "/printers/mapPrinters/linking/available"
                            },
                            serverSide: true,
                            columns : [
                                {data: "printeronName", "class": "printeronName"},
                                {data: "device", "class": "device"}
                            ],
                            "fnServerParams": function ( aoData ) {
                                aoData = $.extend(true, aoData, {
                                    device: $("input[name='device']").val()
                                });
                            }
                        }
                    });
                },
                complete: function () {
                    stopSpinnerOnButton($("#mapPrintersButton"));
                }
            })
        });
    });

    $("#mapPrinters").click(function () {
        $("#physicalPrintersDialog").modal("show");
    });

    $("#synchronizationSettingsModalButton").click(function () {
        $("#synchronizationSettingsModal > .modal-dialog > .modal-content > .modal-body").html("<iframe src=\"modal/printerSyncSettings\" id='PrinterSyncFrame' style='width:100%; height:100%;' frameBorder='0'></iframe>");

        $("#synchronizationSettingsModal").modal("show");
    });

});

function showDataTableLoading() {
    var spinnerDiv = $("#dataTable-spinner");

    dataTableWrapper.hide();
    startSpinner(spinnerDiv);
    spinnerDiv.show();
}

function hideDataTableLoading () {
    var spinnerDiv = $("#dataTable-spinner");

    dataTableWrapper.show();
    stopSpinner(spinnerDiv);
    spinnerDiv.hide();
}

function renderDataTable(printerListUrl) {
    var dtLengthMenu = $('#dtLengthMenu').val().replace('%1', '_MENU_');
    var dtZeroRecords = $('#dtZeroRecords').val();
    var dtInfo = $('#dtInfo').val().replace('%1', '_PAGE_').replace('%2', '_PAGES_');
    var dtInfoEmpty = $('#dtInfoEmpty').val();
    var dtInfoFiltered = $('#dtInfoFiltered').val().replace('%1', '_MAX_');
    var dtPrevious = $("#dtPrevious").val();
    var dtNext = $("#dtNext").val();
    var dtSearch = $("#dtSearch").val();

    var selectableRows = isPull == "false";

    showDataTableLoading();

    dtLoad("#pdsPrinters", {
        ajax: {
            "url" : printerListUrl,
            "complete" : hideDataTableLoading
        },
        fnRowCallback: function( nRow, aData ) { return decorateRow(nRow, aData); },
        serverSide: true,
        columns: [
            {data : "printeronName"},
            {data : "printeronNumber"},
            {data : "device"},
            {data : "printeronNumber"},
            {data : "printeronNumber"},
            {data : "printeronNumber"}
        ],
        "selectableRows": selectableRows,
        "multiSelectRows": selectableRows
    });
}

function decoratePrinterNameColumn(column, printerName, printerNumber) {
    var html = "";

    column.data("printernum", printerNumber);
    if (printerName.length > 25) {
        html += printerName.substring(0,25) + "&nbsp;<span title='" + $("#js-printerName").val() + printerName + " " + $("#js-printerNumber").val() + printerNumber +  "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else
    {
        html += printerName;
    }

    column.html(html);
}

function decorateDeviceColumn(column, device) {
    var html = "";

    column.attr("title", device);

    if (device.length > 25) {
        html += device.substring(0,25) + "&nbsp;<span title='" + device + "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else {
        html += device;
    }

    column.html(html);
}

function decorateEditColumn(column, printerNumber) {
    column.html("<a href='" + printerNumber + "/'><button class='btn btn-default'>" + $("#js-edit").val() + "</button></a>");
}

function decorateSendTestJobColumn(column, printerNumber) {
    column.html("<button type='button' class='btn btn-default' title='" + $("#js-sendTestJob").val() + "' onclick='testPrinter(" + printerNumber + ")'>" + $("#js-test").val() + "</button>");
}

function decorateShowPrintersColumn(column, printerNumber) {
    column.html("<button type='button' class='btn btn-default' title='" + $("#js-showPrintersTitle").val() + "' onclick='getPullPrinterGroupSection(" + printerNumber + ")'>" + $("#js-showPrinters").val() + "</button>");
}

function decorateRow (nRow, aData) {
    var displayedColumnIndex = 0;
    var columnIndex = 0;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decoratePrinterNameColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["printeronName"], aData["printeronNumber"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        // Do nothing for the printeronName column, it's already decorated
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateDeviceColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["device"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateEditColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["printeronNumber"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateSendTestJobColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["printeronNumber"]);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateShowPrintersColumn($("td:eq(" + displayedColumnIndex + ")", nRow), aData["printeronNumber"]);
    }
}

function getPullPrinterGroupSection(printerAliasNum)
{
    $("#pullTitle").text($("[data-printernum='" + printerAliasNum + "']").html());
    getPullPrinterGroup(printerAliasNum);
    $("#pdsLinkPullGroupDialog").modal("show");
}

function getPullPrinterGroup(printerAliasNum)
{
    ajax({
        url: window.location.pathname + "/link",
        data : {"pullPrinter" : printerAliasNum, "uuid" : uuid },
        method: "GET",

        success: function (data) {

            fillPullGroup(data);
            stopLinkedPrintersSpinner();
            $("#pullPrinterAliasNum").html(printerAliasNum);
            $("#pdsUuid").val(uuid);
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
            stopLinkedPrintersSpinner();

            stopSpinnerOnButton("#linkPullPrintersSubmit");

            $("#linkPullPrintersDialog").modal("hide");
        }
    })
}

function fillPullGroup (data) {
    $("#pdsLinkPullGroupWrapper").html(data);
}

function stopLinkedPrintersSpinner () {
    stopSpinner("#pdsPullGroupSpinner");
    $("#pdsPullGroupSpinner").hide();
    $("#pdsLinkPullGroupWrapper").show();
}

function testPrinter(printerNumber){
    notifyInfo($("#sendingPrintJob").val());

    ajax({
        type: "POST",
        url: window.location.pathname + "/sendTestPrintJob",
        data: "printerNumber=" + printerNumber,
        success : function(response) {

            if(response) {
                notifySuccess($("#sendPrintJobSuccess").val());
            }
            else {
                notifyError($("#sendPrintJobFailed").val());
            }

        },
        error : function(e) {
            notifyError($("#sendPrintJobFailed").val());
        }
    });

}

function deletePrintersPrompt(){
    if (dtGetSelectedRowIndexes($("#pdsPrinters")).length > 0)
        $("#dialog-confirm").modal("show");
}

function deletePrinters(){
    notifyInfo($("#deleting-printers").val());

    ajax({
        type: "POST",
        url: window.location.pathname + "/delete",
        data: dtGetTableParamsForAjax($("#pdsPrinters")),
        success: function () {
            notifySuccess($("#printers-deleted-refreshing").val());

            dtResetSelectedRows("#pdsPrinters");
            dtRedraw(true, "#pdsPrinters");
        },
        error: function (e) {
        }
    });
}

function closeModalPopup(modalPopupName) {
    $("#" + modalPopupName).modal("hide");

    notifySuccess($("#js-syncSettingsUpdated").val());

}
