/**
 * Register a change handler for the mode.
 */
$('#cpsLdapModeTypeDropDownInput').change(function() {

    var value = $(this).val();

    if(value == $("#advancedOption").val()) {
        $("#advanced").collapse("show");
        $("#basic").collapse("hide");
    } else {
        $("#advanced").collapse("hide");
        $("#basic").collapse("show");
    }

});

/**
 * On click for the test ldap details button.
 */
$('#testDetailButton').click(function() {

    var uuid = $("#uuid").val();
    var url = "";

    if(uuid) {
        url = CONTEXT + "/cps/" + uuid + "/authentication/testLdapDetail";
    } else {
        url = CONTEXT + "/authentication/testLdapDetail/";
    }

    ajax({
        url: url,
        context: document.body,
        type: 'POST',
        data: $('#cpsLdapDetailsModel').serialize(),
        beforeSend: function() {
            startSpinnerOnButton('#testDetailButton');
        },
        success: function() {
            notifySuccess($("#bindSuccess").val());
        },
        error: function() {
            notifyError($("#bindError").val());
        },
        complete: function() {
            stopSpinnerOnButton('#testDetailButton');
        }
    });
});