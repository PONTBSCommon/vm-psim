/**
 * Created by oliveib on 11/21/2016.
 */
$(document).ready(function ()
{

    useAjaxForForm($("#addRuleForm"), {
        beforeSend: function () {
            startSpinnerOnButton($("#addRuleSaveButton"));
        },
        success: function (data) {
            dtUnload("#accessControl-table");
            loadRuleTable();
            $("#addRuleModal").modal("hide");
            enableDisableEditButton();
            notifySuccess(data);
        },
        complete: function () {
            stopSpinnerOnButton($("#addRuleSaveButton"));
        }
    });

    $("#addRule").click(function ()
    {
        $("#accessRuleTitle").html($("#js-accessRuleTitleCreate").val());
        addOrEditAccessRule(false);
    });

    $("#editRule").click(function ()
    {
        $("#accessRuleTitle").html($("#js-accessRuleTitleEdit").val());
        addOrEditAccessRule(true);
    });

    $("#accessControl-table").one("draw.dt", function () {
        $(this).on("dt.selection.updated", function () {
            enableDisableEditButton();
        });
    });

    $("#deleteRule").click(function () {
        ajax({
            url: CONTEXT + "/users/accessControl/delete",
            method: "POST",
            data: dtGetTableParamsForAjax("#accessControl-table"),
            beforeSend: function () {
                startSpinnerOnButton($("#deleteRule"));
            },
            success: function (data) {
                dtUnload("#accessControl-table");
                loadRuleTable();
                notifySuccess(data);
            },
            complete: function () {
                stopSpinnerOnButton($("#deleteRule"));

            }
        });
    });

    loadRuleTable();

});

function addOrEditAccessRule(isEdit)
{

    resetErrorsOnForm("#addRuleForm");

    var modal = $("#addRuleModal");

    modal.one("transitionend", function ()
    {
        $("#addRuleForm").parent(".modal-body").scrollTop(0);
    });

    $('#role').selectize({
        create: false,
        sortField: 'text',
        placeholder: 'Select one Role'
    });

    var row = $("#accessControl-table tr.selected");

    if (isEdit) {

        var role = "use";

        switch (row.data("role")) {
            case "USER":
                role = "use";
                break;
            case "ADMIN":
                role = "admin";
                break;
        }

        $('#role').selectize()[0].selectize.setValue(role);

        $("#name").val(row.data("ruleName"));

        $("#uuid").val(row.data("uuid"));
    }
    else //adding a rule
    {
        $("#uuid").val("");

        $("#name").val("");

        $('#role').selectize()[0].selectize.setValue("use");

    }

    $.getJSON(CONTEXT +  "/users/accessControl/users",
        function(result)
        {
            var optgroup = $('<optgroup>');
            optgroup.attr('label','Users');

            $.each(result, function(i, field)
            {
                optgroup
                    .append($("<option></option>")
                        .attr("value",field["value"] + ":USER:" + field["text"])
                        .text(field["text"] + " - USER"));
            });

            $('#actor').append(optgroup);

            $.getJSON(CONTEXT +  "/users/accessControl/groups",
                function(result)
                {
                    var optgroup = $('<optgroup>');
                    optgroup.attr('label','Groups');

                    $.each(result, function(i, field)
                    {
                        optgroup
                            .append($("<option></option>")
                                .attr("value",field["value"] + ":GROUP:" + field["text"])
                                .text(field["text"] + " - GROUP"));
                    });

                    $('#actor').append(optgroup);

                    var actorSelect = $('#actor').selectize({
                        create: false,
                        sortField: 'text',
                        placeholder: 'Select one User or Group'
                    });

                    if (isEdit)
                    {
                        actorSelect[0].selectize.setValue(actorSelect[0].selectize.search(row.data("actor")).items[0].id);
                    }
                    else
                    {
                        $('#actor').selectize()[0].selectize.setValue("");
                    }
                });
        });

    $.getJSON(CONTEXT +  "/users/accessControl/printers",
        function(result)
        {
            var printerGroup = $('<optgroup>');
            printerGroup.attr('label','Printers');

            $.each(result, function(i, field)
            {
                printerGroup
                    .append($("<option></option>")
                        .attr("value",field["value"] + ":PRINTER")
                        .text(field["text"]));
            });

            $('#scopes').append(printerGroup);

            $.getJSON(CONTEXT +  "/users/accessControl/pds",
                function(result)
                {
                    var pdsGroup = $('<optgroup>');
                    pdsGroup.attr('label','PDS');

                    $.each(result, function(i, field)
                    {
                        pdsGroup
                            .append($("<option></option>")
                                .attr("value",field["value"] + ":PDS")
                                .text(field["text"]));
                    });

                    $('#scopes').append(pdsGroup);


                    $.getJSON(CONTEXT +  "/users/accessControl/departments",
                        function(result)
                        {
                            var departmentGroup = $('<optgroup>');
                            departmentGroup.attr('label','Departments');

                            $.each(result, function(i, field)
                            {
                                departmentGroup
                                    .append($("<option></option>")
                                        .attr("value",field["value"] + ":DEPARTMENT")
                                        .text(field["text"]));
                            });

                            $('#scopes').append(departmentGroup);

                            var scopeSelect = $('#scopes').selectize({
                                create: false,
                                sortField: 'text',
                                placeholder: 'Select one Object'
                            });

                            if (isEdit)
                            {
                                scopeSelect[0].selectize.setValue(scopeSelect[0].selectize.search(row.data("scope")).items[0].id);
                            }
                            else
                            {
                                $('#scopes').selectize()[0].selectize.setValue("");
                            }

                            // When we first press it the change rule doesn't apply for some reason so do it manually
                            if ($('#role').selectize()[0].selectize.getValue() === "admin"){
                                $('#scopes').selectize()[0].selectize.disable();
                            }
                            else{
                                $('#scopes').selectize()[0].selectize.enable();
                            }

                            addAdminRule();
                        });
                });
        });

    modal.modal("show");
}

function enableDisableEditButton()
{
    var indexes = dtGetSelectedRowIndexes("#accessControl-table");

    $("#editRule").prop("disabled", false);
    $("#deleteRule").prop("disabled", false);

    if (indexes.length <= 0) {
        $("#deleteRule").prop("disabled", true);
    }

    if (indexes.length != 1){
        $("#editRule").prop("disabled", true);
    }
}


function decorateRow (nRow, aData) {
    // add the data to the rows that we need
    $(nRow).data("uuid", aData['uuid']);
    $(nRow).data("ruleName", aData['ruleName']);
    $(nRow).data("role", aData['role']);
    $(nRow).data("scope", aData['actuator']);
    $(nRow).data("actor", aData['actor']);

    decoratePermissions($("td.grant", nRow), aData['grant']);
    decoratePermissions($("td.revoke", nRow), aData['revoke']);
}

function decoratePermissions (column, permissions)
{
    var html = "";

    for (var index in permissions)
    {
        switch (permissions[index])
        {
            case "USER":
                html += "<span class='label label-success permissions'>user</span>";
                break;
            case "ADMIN":
                html += "<span class='label label-danger permissions'>admin</span>";
                break;
        }
    }

    column.html(html);
}

function loadRuleTable()
{
    dtLoad("#accessControl-table", {
        fnRowCallback: function( nRow, aData ) { return decorateRow(nRow, aData); },
        ajax: {
            url: CONTEXT + "/users/accessControl/list"
        },
        serverSide: true,
        columns: [
            {data: "uuid"},
            {data: "ruleName"},
            {data: "actor"},
            {data: "actorType"},
            {data: "actuator"},
            {data: "scopeType"},
            {data: "role"}
        ],
        selectableRows: true,
        multiSelectRows: true
    });
}

function addAdminRule(){
    $('#role').selectize()[0].selectize.off('change');

    $('#role').selectize()[0].selectize.on('change', function(){
        if ($('#role').selectize()[0].selectize.getValue() === "admin"){
            $('#scopes').selectize()[0].selectize.disable();
        }
        else{
            $('#scopes').selectize()[0].selectize.enable();
        }
    });
}