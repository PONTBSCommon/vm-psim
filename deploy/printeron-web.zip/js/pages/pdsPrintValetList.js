/**
 * Created by bershaa on 1/29/2015.
 */
var currentForm;

$(function () {
    $('#deletePrinterForm').submit(function (e) {
        currentForm = this;

        $('#dialog-confirm').modal('show');

        return false;
    });
});

function dialogConfirmYES () {
    currentForm.submit();
}

