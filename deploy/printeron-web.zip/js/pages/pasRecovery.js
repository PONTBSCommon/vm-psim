/**
 * Created by bershaa on 1/5/2015.
 */

$(document).ready(function()
{
    $('#cleanFullPath option').prop('selected', false);
    $('#cleanTemp option').prop('selected', false);

    $('#pas').submit(function(ev)
    {
        // to stop the form from submitting
        ev.preventDefault();

        $('#cleanFullPath option').prop('selected', true);
        $('#cleanTemp option').prop('selected', true);

        // If all the validations succeeded
        this.submit();
    });

});


$(function(){
    disableDay();
    disableStartTime();

    $( "#systemMonitorRun" ).change(function() {
        disableDay();
        disableStartTime();
    });

    $('#systemMonitorTime').timepicker();

});

function disableDay(){
    var value = $('#weekly').val();

    if($('#systemMonitorRun').val() == value) {
        $('#systemMonitorRunDay').removeAttr('disabled');
    }else{
        $('#systemMonitorRunDay').attr('disabled', true);
    }
}

function disableStartTime() {
    var value = $("#never").val();

    if($('#systemMonitorRun').val() != value) {
        $('#systemMonitorTime').removeAttr('disabled');
    } else {
        $('#systemMonitorTime').attr('disabled', true);
    }
}

function removeFull() {
    $("#cleanFullPath option:selected").remove();
}

function removeTemp() {
    $("#cleanTemp option:selected").remove();
}

function addCleanup() {
    var path = $("#addPath").val();
    var nonEmptyPath = path.trim();
    var option = new Option(path, path);

    if (path && nonEmptyPath) {
        if (path.indexOf(":\\") >= 0) {
            $('#cleanFullPath').append($(option));
        }
        else {
            $('#cleanTemp').append($(option));
        }

        $("#addPath").val('');
    }
}