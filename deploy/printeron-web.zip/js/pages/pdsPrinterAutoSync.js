/**
 * Created by leibolr on 9/25/2017.
 * JS Helper functions for PDS Standalone Auto Sync Popup
 */

$(document).ready(function() {
    var action = getQueryParameter("saved");

    if (action == "true") {
        parent.closeModalPopup("synchronizationSettingsModal"); // call the parent frame to close the modal popup and reload the entire page with new data
    }

    $("#enablePDSAutoSync").on('change', function() { showHideSyncIntervalInput(this); });

    // onload set the correct display for the Sync Interval textbox
    showHideSyncIntervalInput($("#enablePDSAutoSync")[0]);

});

function showHideSyncIntervalInput(control) {
    if (control.checked) {
        if ($("#syncIntervalPDS").val() == -1) { // -1 is used to store if syncInterval is disabled, clear it out if it's -1 for the UI
            $("#syncIntervalPDS").val('');
        }
        $("#syncIntervalInputDiv").show();
    }
    else {
        $("#syncIntervalInputDiv").hide();
    }
}