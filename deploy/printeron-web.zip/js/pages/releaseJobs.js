/**
 * Created by bershaa on 10/16/2015.
 */

/**
 * Created by bershaa on 10/2/2015.
 */

var releaseCode = -1;


function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

$(function(){
    dtErrorMode("throw");

    releaseCode = getUrlVars()["releasecode"];
    var url;
    var username;
    var password;

    if (typeof releaseCode == 'undefined') {
        username = getUrlVars()["username"];
        password = getUrlVars()["password"];

        url = "/user?mode=user&username=" + username + "&password=" + password;
    }else {
        url = "/releasecode?privacyReleaseCode=" + releaseCode;
    }

            // Initialize datatable
    dtLoad('#queueMonitorTable', {

        "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
            decorateRow(nRow);
            return nRow;
        },
        tableTools: {
            "sRowSelect": "single"
        },
        searching: false,
        ajax:  window.location.pathname + url,
        "columns": [
            { "data": "PTID" },
            { "data": "timeReceived" },
            { "data": "pages" },
            { "data": "documentName" },
            { "data": "statusText" }
        ]
        ,
        "order": [[ 1, "desc" ]]
    });


    $('#button').click( function () {
        table.row('.selected').remove().draw( false );
    } );

    $('#queueMonitorTable tbody').on( 'click', 'tr', function () {
        $(this).toggleClass('selected');

        var table = $('#queueMonitorTable').DataTable();
        var data = table.rows('.selected').data();
        var printable = false;
        var deleteable = false;
        var pauseable = false;

        for(var i = 0; i < data.length; i++){
            if(!printable)
                printable = data[i].printable || data[i].reprintable;

            if(!deleteable)
                deleteable = data[i].deleteable;

            if(!pauseable)
                pauseable = data[i].pauseable;
        }

        if(printable)
            $("#printButton").removeAttr("disabled");
        else
            $("#printButton").attr("disabled", true);

        if(deleteable)
            $("#deleteButton").removeAttr("disabled");
        else
            $("#deleteButton").attr("disabled", true);
    } );
});

function getPrintJobs ()
{
    releaseCode = $('#privacyReleaseCode').val();

    var table = $('#queueMonitorTable').DataTable();

    table.ajax.url( window.location.pathname + '/releasecode?privacyReleaseCode=' + releaseCode ).load();

    $("#printJobs").show();

    return false;
}

function decorateRow(row) {
    $(row).children().each(function(index, td){
        if ($(td).html().length > 20) {
            if($(td).html().indexOf("glyphicons") < 0) {
                var truncated = $(td).html().substring(0, 20);
                truncated += "...";
                $(td).html(truncated + "<span title=\"" + $(td).html() + "\" class='more-bottom glyphicons glyphicons-more'></span>");
            }
        }
    });
}

function setAndSubmit(printJobId, actionType){
    $("#printJobId").val(printJobId);
    $("#actionType").val(actionType);
    $("#queuemonitor").submit();
}

function refresh(){
    notifyInfo($("#refreshingJobs").val());
    var table = $('#queueMonitorTable').DataTable();

    table.ajax.reload( function ( json ) {
    } );

    $("#printButton").attr("disabled", true);
    $("#deleteButton").attr("disabled", true);
}

function printJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].printable || data[i].reprintable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    var printerNumber = "";

    printerNumber = getUrlVars()["printerNumber"];

    ajax({
        type : "POST",
        url : window.location.pathname + "/jobaction",
        data : "jobIds=" + ids + "&actionType=print&printerNumber=" + printerNumber,
        success : function(response) {
            notifyInfo($("#printingJobs").val());
            refresh();
        },
        error : function(e) {

        }
    });
}

function deleteJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].deleteable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : window.location.pathname + "/",
        data : "jobIds=" + ids + "&actionType=delete",
        success : function(response) {
            refresh();
        },
        error : function(e) {

        }
    });
}

function pauseJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].pauseable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : window.location.pathname + "/",
        data : "jobIds=" + ids + "&actionType=pause",
        success : function(response) {
            refresh();
        },
        error : function(e) {

        }
    });
}