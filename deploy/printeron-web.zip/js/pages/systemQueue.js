/**
 * Created by bershaa on 12/15/2015.
 */

/**
 * Created by bershaa on 10/2/2015.
 */

$(document).ready( function () {

    dtErrorMode("throw");

    // Initialize datatable
    dtLoad('#queueMonitorTable', {

        "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
            decorateRow(nRow, aData);
            return nRow;
        },
        tableTools: {
            "sRowSelect": "single"
        },
        "processing": true,
        "serverSide": true,
        ajax: {url: window.location.pathname + '/ajax/'},
        "columns": [
            { "data": "jobDesc" },
            { "data": "userEmail" },
            { "data": "documentType" },
            { "data": "datestamp"},
            { "data": "ptid" },
            { "data": "size" },
            { "data": "pages" },
            { "data": "printerId" },
            { "data": "status" },
            { "data": "submissionMethod" }
        ],
        "order": [[ 3, "desc" ]]
    });

    $('#button').click( function () {
        table.row('.selected').remove().draw( false );
    } );

    $('#queueMonitorTable tbody').on( 'click', 'tr', function () {
        $(this).toggleClass('selected');

        var table = $('#queueMonitorTable').DataTable();
        var data = table.rows('.selected').data();
        var printable = false;
        var deleteable = false;
        var pauseable = false;

        for(var i = 0; i < data.length; i++){
            if(!printable)
                printable = data[i].printable || data[i].reprintable;

            if(!deleteable)
                deleteable = data[i].deleteable;

            if(!pauseable)
                pauseable = data[i].pauseable;
        }

        if(printable)
            $("#printButton").removeAttr("disabled");
        else
            $("#printButton").attr("disabled", true);

        if(deleteable)
            $("#deleteButton").removeAttr("disabled");
        else
            $("#deleteButton").attr("disabled", true);

        if(pauseable)
            $("#pauseButton").removeAttr("disabled");
        else
            $("#pauseButton").attr("disabled", true);
    } );
} );

function decorateRow(row, data) {
    var printerNumber = 0;

    $(row).children().each(function(index, td){
        if ($(td).html().length > 20) {
            if($(td).html().indexOf("glyphicons") < 0) {
                var truncated = $(td).html().substring(0, 20);
                truncated += "...";
                $(td).html(truncated + "<span title=\"" + $(td).html() + "\" class='more-bottom glyphicons glyphicons-more'></span>");
            }
        }
    });

    var date = new Date(0);
    date.setUTCMilliseconds(data['datestamp']);

    $("td:eq(3)", row).html(date.toLocaleString());
}

function refresh(showSpinner){

    if(showSpinner) {
        startSpinnerOnButton("#refreshButton")
    }

    var table = $('#queueMonitorTable');

    dtUnloadUUID(table);
    dtRedraw(false, table);

    $("#printButton").attr("disabled", true);
    $("#deleteButton").attr("disabled", true);

    if(showSpinner) {
        stopSpinnerOnButton("#refreshButton")
    }
}
