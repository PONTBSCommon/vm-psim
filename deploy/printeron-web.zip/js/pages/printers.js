var synchInProgress = false;
var confirmationRequiredAction;
var confirmationRequiredProperty;
var _rows;
var editingPrinter;
var deletePrinterUrl;

var dataTableWrapper = $("#dataTable-wrapper");

var printerClass = $("#pagePrinterClass").val();

/**
 * Happens on page load.
 */
$(document).ready(function() {
    $("#bulkImportButton").on("click", function () {
        $("#importForm")[0].reset();
    });

    // And the printer synchronize
    $("#synchronize").click(synchronizePrinters);

    $("#synchronizationSettingsModalButton").click(function () {
        $("#synchronizationSettingsModal").modal("show");
    });

    $("#syncNowModalButton").click(function () {
        $("#synchronize").trigger("click");
        $("#synchronizationSettingsModal").modal("hide");
    });

    $("#copyPrinterDialog").on('hidden.bs.modal', function ()
    {
        var toTable = $("#toTable");

        var fromTable = $("#fromTable");

        dtUnload(toTable);
        dtRedraw(true, toTable);

        dtUnload(fromTable);
        dtRedraw(true, fromTable);
    });

    if (disconnected) {

        $("#lastSynch").hide();

        $("#currencyId").on("change", function() {
            var currencyId = $(this).val();

            changeCurrencySymbol(getSymbolByCurrencyId(currencyId));

        });

        var currencyId = $('#currencyId').find(":selected").text();

        changeCurrencySymbol(getSymbolByCurrencyId(currencyId));

        $("#importForm").fileUpload({

            before: function(xhr) {

                startSpinnerOnButton($("#importUploadButton"));
            },

            success: function (data, textStatus, jqXHR) {

                $("#bulkImportModal").modal("hide");
                stopSpinnerOnButton($("#importUploadButton"));
                notifySuccess(data);
                prepareDataTable();
                $("#csvFile").val("");
            },
            error: function (jqXHR, textStatus, errorThrown) {

                notifyError(jqXHR.responseText);
                stopSpinnerOnButton($("#importUploadButton"));
            }
        });

        $("#configurePrinterSubmit").click(function () {

            $("input[name=paperSizes]").remove();

            dtQueryRows("input[name='paperSizes-temp']:checked", "#paperSizes").each(function () {
                $("#configurePrinterForm").append("<input type='hidden' name='paperSizes' value='" + $(this).val() + "'/>")
            });
            $("#configurePrinterForm").submit();
        });

        $("#linkPrinters").click(getLinkedPrintersSection);

        $(document).on("click", ".configurePrinter", function () {
            clearConfigurePrinterForm();
            var url = CONTEXT + "/printer/configure?printerNumber=" + $(this).data("printernumber");
            configurePrinter(url);
        });

        $(document).on("click", "#deletePrinters", function () {

            var aData = dtGetTableParamsForAjax($("#printerTable"));
            var confirmationMessage = $("#confirmation-bulk-delete").val();

            if(aData.selectedIndexes.length > 0)
            {
                $("#bulkDeleteConfirmationPrompt").html(confirmationMessage.replace("%1",aData.selectedIndexes.length));

                $("#bulkDeleteConfirmDialog").modal("show");
            }
            else
            {
                notifyError($("#bulkDeleteEmptyFailed").val());
            }
        });

        $(document).on("click", ".deletePrinter", function () {
            deletePrinterUrl = CONTEXT + "/printer/delete?printerNumber=" + $(this).data("printernumber");
            $("#deleteConfirmDialog").modal("show");
        });

        $("#deletePrinterModalButton").click(function () {
            deletePrinter();
        });

        $("#bulkDeletePrinterModalButton").click(function () {
            bulkDeletePrinters();
        });


        $(document).on("click", ".copyPrinter", function () {
            var url = CONTEXT + "/printers/bulk/copy/" + $(this).data("printernumber");
            copyPrinter(url);
        });

        $(document).on("click", ".linkPullPrinter", function ()
        {
            var printerAliasNum = $(this).data("printernumber");

            var printerName = $(this).data("printername");

            getLinkedPullPrintersSection(printerAliasNum, printerName);
        });

        $("#linkPullPrintersForm").submit(function()
        {
            if($("input[name='tableUUID']").val() !== "undefined")
            {
                var url = CONTEXT + "/printer/pull/link";

                startSpinnerOnButton($("#linkPullPrintersSubmit"));

                ajax({
                    method: "POST",
                    url: url,
                    data: $("#linkPullPrintersForm").serialize(), // serializes the form's elements.
                    success: function(data)
                    {
                        stopSpinnerOnButton($("#linkPullPrintersSubmit"));
                        $("#linkPullPrintersDialog").modal("hide");
                        notifySuccess(data);
                    },
                    error: function (xhr) {
                        notifyError(xhr.responseText);
                        stopSpinnerOnButton($("#linkPullPrintersSubmit"));
                    }
                });
            }
            else
            {
                notifyError($("#linkedPrinterEmptyMessage").val());
            }

            return false; // avoid to execute the actual submit of the form.
        });
        
        useAjaxForForm("#copyPrinterForm",{
            beforeSend: function ()
            {
                startSpinnerOnButton($("#copyPrinterSubmit"));
            },
            success: function(data)
            {
                $("#copyPrinterDialog").modal("hide");
                prepareDataTable();

                var toTable = $("#toTable");
                var fromTable = $("#fromTable");

                dtUnloadUUID(toTable);
                dtRedraw(true, toTable);

                dtUnloadUUID(fromTable);
                dtRedraw(true, fromTable);

                notifySuccess(data);
            },
            complete: function ()
            {
                stopSpinnerOnButton($("#copyPrinterSubmit"));

            }
        });

        $("#addPrinter").click(function () {
            var classType = $(this).data('class');
            startSpinnerOnButton($(this));
            clearConfigurePrinterForm();

            ajax({
                url: CONTEXT + "/printer/configure" + "?printerClass=" + classType,
                method: "PUT",
                success: function (data) {
                    stopSpinnerOnButton($("#addPrinter"));

                    if (!data) {
                        $("#licenseExceededDialog").modal("show");
                    }
                    else {
                        prepareDataTable();
                    }
                },
                error: function (xhr) {
                    notifyError(xhr.responseText);
                    stopSpinnerOnButton($("#addPrinter"));
                }

            });
        });

        $("#manageDepartments").click(getDepartments);

        $('#duplexingType').on('change', function() {
            var value = $(this).val();

            if(this.value < 2)
            {
                $(".simplexCol").show();

                $(".duplexCol").hide();
            }

            if(this.value == 2)
            {
                $(".simplexCol").hide();

                $(".duplexCol").show();
            }

            if(this.value > 2)
            {
                $(".simplexCol").show();

                $(".duplexCol").show();
            }

        });


        $("#addDepartment").click(function () {
            $("input").removeClass("error");
            $("select").removeClass("error");
            $(".errorMessage").html("");

            $(".extraAddDepartmentRow").remove();
            $("#departmentName").val("");
            $("#manageDepartmentsDialog").modal("hide");
            $("#addDepartmentDialog").modal("show");
        });

        $("#cancelAddDepartment").click(function () {
            $("#addDepartmentDialog").modal("hide");
            $("#manageDepartmentsDialog").modal("show");
        });

        $("#departments-linkPrintersCancel").click(function () {
            $("#departments-linkPrintersDialog").modal("hide");
            getDepartments();
        });

        useAjaxForForm("#addDepartmentForm", {
            beforeSend: function () {
                startSpinnerOnButton("#addDepartmentSubmit");
            },
            success: function (data) {
                stopSpinnerOnButton("#addDepartmentSubmit");
                $("#addDepartmentDialog").modal("hide");
                notifySuccess(data);
                getDepartments();
            },
            error: function (xhr) {
                stopSpinnerOnButton("#addDepartmentSubmit");
            }
        });
    }

    prepareDataTable();
});

function prepareDataTable() {
    // Disable the link printers button until we know we have at least one printer
    $("#linkPrinters").attr("disabled", true);

    // Send an ajax request for the printer info
    ajax({
        url: CONTEXT + "/printers/list",
        data: {printerClass: printerClass},
        type: "GET",
        beforeSend: function(xhr) {
            dataTableWrapper.hide();
            startSpinner("#printersPanelBody", spinner.large);
        },
        success: function (resp) {
            // Destroy the old table (if it's there), removing it from the DOM
            dtDestroy('#printerTable');

            dataTableWrapper.html(resp);
            renderDataTable();
            stopSpinner("#printersPanelBody");
            dataTableWrapper.show();

            if(disconnected)
            {
                var table = $("#printerTable").DataTable();

                if(table.data().length <= 0)
                {
                    $("#linkPrinters").prop("disabled", true);
                }
                else
                {
                    $("#linkPrinters").prop("disabled", false);
                }
            }
        },
        error: function () {
            stopSpinner("#printersPanelBody");
            dataTableWrapper.show();
            notifyError($("#synchFailed").val());
        }
    });

}

function decorateRow(nRow, aData) {
    // We have at least one printer, so enable the link printers button if it is disabled
    var linkPrintersButton = $("#linkPrinters");
    if (linkPrintersButton.attr("disabled") == "disabled") {
        linkPrintersButton.attr("disabled", false);
    }

    var printerNum = aData["printerId"];
    var printerName = aData["printeronName"];
    var enabled = aData["enabled"];
    var pdsUUIDs = aData["pdsUUIDs"];
    var airDisplay = aData["airDisplay"];
    var device = aData["device"];
    var guest = aData["guest"];
    var approval = aData["approvalRequired"];
    var pqms = aData["pqmsMapped"];
    var gcp = aData["googleMapped"];
    var discovery = aData["airEnabled"];

    var disconnected = $("#js-disconnected").val();
    var isPull = $("#js-isPull").val();


    $(nRow).data("printernumber", printerNum);

    var displayedColumnIndex = 0;
    var columnIndex = 0;
    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateChildRowColumn($("td:eq(" + displayedColumnIndex + ")", nRow));
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateEnabledColumn($("td:eq(" + displayedColumnIndex + ")", nRow), enabled, printerNum, printerName, pdsUUIDs, isPull, disconnected);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decoratePrinterNameColumn($("td:eq(" + displayedColumnIndex + ")", nRow), printerName, printerNum, airDisplay, pdsUUIDs);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateDeviceColumn($("td:eq(" + displayedColumnIndex + ")", nRow), device, printerNum);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateGuestColumn($("td:eq(" + displayedColumnIndex + ")", nRow), guest, printerNum);
        displayedColumnIndex++;
    }
    else
    {
        //the column won't be visible, therefore the guest printer will be disabled
        sendPrinterUpdate(printerNum, "guest", "disable");
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateApprovalColumn($("td:eq(" + displayedColumnIndex + ")", nRow), approval, printerNum);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decoratePqmsColumn($("td:eq(" + displayedColumnIndex + ")", nRow), pqms, printerNum);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateGcpColumn($("td:eq(" + displayedColumnIndex + ")", nRow), gcp, printerNum);
        displayedColumnIndex++;
    }
    columnIndex++;

    if (!$("#dt-hide-column-" + columnIndex).length) {
        decorateDiscoveryColumn($("td:eq(" + displayedColumnIndex + ")", nRow), discovery, printerNum);
    }
}

function decorateDiscoveryColumn (column, discovery, printerNum) {
    column.addClass("col-md-1 printers-glyphicon-align text-center");

    if (discovery) {
        column.data("order", "1");
        column.attr("id", printerNum + "-discovery");
        column.html("<span id='" + printerNum + "-discovery-disable' class=\"glyphicons glyphicons-ok x1 green hoverable\"></span>");
    }
    else if (!discovery) {
        column.data("order", "2");
        column.attr("id", printerNum + "-discovery");
        column.html("<span id='" + printerNum + "-discovery-enable' class=\"glyphicons glyphicons-remove x1 red hoverable\"></span>");
    }
    else {
        column.data("order", "3");
        column.html($("#js-na").val());
    }
}

function decorateGcpColumn (column, gcp, printerNum) {
    column.addClass("col-md-1 printers-glyphicon-align text-center");

    if (gcp) {
        column.data("order", "1");
        column.attr("id", printerNum + "-gcp");
        column.html("<span class=\"glyphicons glyphicons-ok x1 green\"></span>");
    }
    else if (!gcp) {
        column.data("order", "2");
        column.attr("id", printerNum + "-gcp");
        column.html("<span class=\"glyphicons glyphicons-remove x1 red\"></span>");
    }
    else {
        column.data("order", "3");
        column.html($("#js-na").val());
    }
}

function decoratePqmsColumn (column, pqms, printerNum) {
    column.addClass("col-md-1 printers-glyphicon-align text-center");

    if (pqms) {
        column.attr("id", printerNum + "-pqms");
        column.data("order", "1");
        column.html("<span class=\"glyphicons glyphicons-ok x1 green\"></span>");
    }
    else if (!pqms) {
        column.attr("id", printerNum + "-pqms");
        column.data("order", "2");
        column.html("<span class=\"glyphicons glyphicons-remove x1 red\"></span>");
    }
    else {
        column.data("order", "3");
        column.html($("#js-na").val());
    }
}

function decorateApprovalColumn (column, approval, printerNum) {
    var html = "";

    column.addClass("col-md-1 printers-glyphicon-align text-center");
    column.attr("id", printerNum + "-approval");

    if (approval) {
        column.data("order", "1");
        html += "<span id=\"" + printerNum + "-approval-disable\" class=\"glyphicons glyphicons-ok x1 green hoverable\"></span>";
    }
    else {
        column.data("order", "2");
        html += "<span id=\"" + printerNum + "-approval-enable\" class=\"glyphicons glyphicons-remove x1 red hoverable\"></span>";
    }

    column.html(html);
}

function decorateGuestColumn (column, guest, printerNum) {
    var html = "";

    column.addClass("col-md-1 printers-glyphicon-align text-center");
    column.attr("id", printerNum + "-guest");

    if (guest) {
        column.data("order", "1");
        html += "<span id=\"" + printerNum + "-guest-disable\" class=\"glyphicons glyphicons-ok x1 green hoverable\"></span>";
    }
    else if (!guest) {
        column.data("order", "2");
        html += "<span id=\"" + printerNum + "-guest-enable\" class=\"glyphicons glyphicons-remove x1 red hoverable\"></span>";
    }

    column.html(html);
}

function decorateDeviceColumn (column, device, printerNum) {
    if (!device || 0 === device.length) {
        column.html($("#js-unknown").val());
    }
    else {
        column.html(device);
    }

    column.addClass("glyph-table-text col-md-2");
    column.attr("id", printerNum + "-device");
}

function decorateChildRowColumn (column) {
    column.html("<span data-controls=\"childRow\" class=\"halflings plus-minus-toggle\">");
    column.addClass("childRow-icon");
}

function decorateEnabledColumn (column, enabled, printerNum, printerName, pdsUUIDs, isPull, disconnected) {
    var html = "";

    column.addClass("col-md-1 printers-glyphicon-align text-center");
    column.attr("id", printerNum + "-printer");

    if (enabled) {
        column.data("order", "1");
        html += "<span id=\"" + printerNum + "-printer-disable\" class=\"glyphicons glyphicons-ok x1 green hoverable\"></span>";
    } else {
        column.data("order", "2");
        html += "<span id=\"" + printerNum + "-printer-enable\" class=\"glyphicons glyphicons-remove x1 red hoverable\"></span>";
    }

    html += "<div class=\"dataTable-childRow\">";

    if (isPull == "true" && disconnected == "true") {
        html += "<button data-printernumber=\"" + printerNum + "\" data-printername=\"" + printerName + "\" class=\"linkPullPrinter btn btn-default\" type=\"button\">" + $("#js-pullPrinterLinking").val() + "</button>";
    }

    html +=     "<button class=\"btn btn-default\" id=\"" + printerNum + "-details\">" + $("#js-buttonDetails").val() + "</button>";

    if (disconnected == "true") {
        html += "<button data-printernumber=\"" + printerNum + "\" class=\"configurePrinter btn btn-default\" type=\"button\">" + $("#js-buttonConfigure").val() + "</button>";
        html += "<button data-printernumber=\"" + printerNum + "\" class=\"copyPrinter btn btn-default\" type=\"button\">" + $("#js-buttonCopy").val() + "</button>";
        html += "<button data-printernumber=\"" + printerNum + "\" class=\"deletePrinter btn btn-danger\" type=\"button\">" + $("#js-buttonDelete").val() + "</button>";
    }

    html += "</div>";

    column.html(html);
}

function decoratePrinterNameColumn (column, printerName, printerNum, displayName, pdsUUIDs) {
    column.data("search", printerName + " " + displayName);
    column.addClass("col-md-2 glyph-table-text");

    var html = "";
    if (displayName != null && displayName.length > 25) {
        html += "<span title=\"" + printerName + "\" id=\"" + printerNum + "\">" + displayName.substring(0,25) + "&nbsp;<span title=\"" + displayName + "\" class=\"more-bottom glyphicons glyphicons-more\"></span></span>";
    }
    else {
        html += "<span title=\"" + printerName + "\" id=\"" + printerNum + "\">" + displayName + "</span>";
    }

    html += "<input type=\"hidden\" id=\"" + printerNum + "-pdsUUIDs\" value=\"" + pdsUUIDs + "\"/>";

    column.html(html);
}

function renderDataTable() {

    var table = $('#printerTable');

    if (table.length) {

        confirmationRequiredAction = null;
        confirmationRequiredProperty = null;
        _rows = null;
        editingPrinter = null;

        // Load the datatable
        dtLoad(table, {
            "order": [[$("#printerName").index(), 'desc']],
            fnRowCallback: function( nRow, aData, iDisplayIndex ) { return decorateRow(nRow, aData); },
            serverSide: true,
            selectableRows: true,
            multiSelectRows: true,
            ajax: {
                "url" : CONTEXT + '/printers/list/ajax',
                "data" : {printerClass: printerClass}
            },
            columns: [
                {data: "printerId"},
                {data: "enabled"},
                {data: "printeronName"},
                {data: "device"},
                {data: "guest"},
                {data: "approvalRequired"},
                {data: "pqmsMapped"},
                {data: "googleMapped"},
                {data: "airEnabled"},
                {data: "pdsUUIDs"},
                {data: "airDisplay"}
            ]
        });

        // Rebind events when the table is drawn
        table.on("draw.dt", function () {
            // Register event handlers for enable/disable, in all rows (even hidden ones)
            dtQueryRows("[id$='-enable'], [id$='-disable']", table).click(setProperty);

            // Register event handlers for the header row
            table.find("th").find("[id$='-enable'], [id$='-disable']").click(setProperty);
        });

        // And for printer info for all rows
        $(document).on("click", "[id$='-details']", showDetails);

        // And for printer edit for all rows
        $(document).on("click", "[id$='-edit']", showEdit);

        // Register an event handler for the yes button in the modal
        $("#confirmationButton").click(function () {
            sendPrinterUpdate("all", confirmationRequiredProperty, confirmationRequiredAction);
        });

        // Reset the details scroll when the modal is hidden
        $("#printerDetailsDialog").on('hide.bs.modal', function (e) {
            $("#printerDetailsDialog").find('.modal-body').scrollTop(0);
        });

        var goToPrinter = $("#goToPrinter");
        var goToPrinterNum = goToPrinter.val();
        if (goToPrinter.length) {
            table.DataTable().page.jumpToRow("[data-printernumber='" + goToPrinterNum + "']");
            // Put inside of a timeout in order to stop the tray animation from sketching out
            setTimeout(function () {table.DataTable().$("[data-printernumber='" + goToPrinterNum + "']").find("[data-controls='childRow']").trigger("click")}, 100);
            goToPrinter.remove();
        }
    }

    if(!disconnected)
    {
        $("#lastSynch").show();
        $("#synchStatus").html($("#lastSynch-string").val());
    }
    else
    {
        $("#synchStatus").html("");
    }

}

function deletePrinter () {
    ajax({
        "method": "delete",
        url: deletePrinterUrl,
        beforeSend: function(xhr) {
            startSpinnerOnButton("#deletePrinterModalButton");
        },
        success: function (data) {
            notifySuccess(data);
            stopSpinnerOnButton("#deletePrinterModalButton");
            $("#deleteConfirmDialog").modal("hide");
            prepareDataTable();
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
            stopSpinnerOnButton("#deletePrinterModalButton");
        }
    });
}

function bulkDeletePrinters()
{
    var url = CONTEXT + "/printers/bulk/delete";
    var table = $("#printerTable");
    var aData = dtGetTableParamsForAjax(table);

    ajax({
        "method":"POST",
        url: url,
        data: aData,
        beforeSend: function(xhr) {
            startSpinnerOnButton("#bulkDeletePrinterModalButton");
        },
        success: function (data) {
            notifySuccess($("#bulkDeleteSuccess").val());
            stopSpinnerOnButton("#bulkDeletePrinterModalButton");
            $("#bulkDeleteConfirmDialog").modal("hide");
            synchronizePrinters();
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
            stopSpinnerOnButton("#bulkDeletePrinterModalButton");
        }
    });
}

function configurePrinter (url)
{
    ajax({
        "method":"get",
        url: url,
        success: function (data) {
            updatePrinterForm(data);
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
        }
    });
}

function copyPrinter (url)
{
    ajax({
        "method":"get",
        url: url,
        success: function (data)
        {
            $("#bulkCopyTableWrapper").html(data);

            setUpCopyPrinterModal(url);

            $("#copyPrinterDialog").modal("show");
            startSpinnerOnBulkCopyModal();
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
        }
    });
}

function startSpinnerOnBulkCopyModal () {
    $("#copyPrinterSubmit").attr("disabled", true);
    $("#bulkCopyTableWrapper").hide();
    $("#bulkCopySpinner").show();
    startSpinner("#bulkCopySpinner");
}

function stopSpinnerOnBulkCopyModal () {
    $("#copyPrinterSubmit").attr("disabled", false);
    $("#bulkCopySpinner").hide();
    $("#bulkCopyTableWrapper").show();
    stopSpinner("#bulkCopySpinner");
}

function setUpCopyPrinterModal(url)
{
    //Create LinkedTables
    linkedDataTables({
        "#toTable":
        {
            "oLanguage": {"sLengthMenu": "Display _MENU_"},
            "bInfo" : false,
            ajax: {
                url: url + "/linked"
            },
            serverSide: true,
            form: "#copyPrinterForm",
            columns : [
                {data: "label"},
                {data: "department.name"}
            ]
            ,
            fnDrawCallback: function () {
                $("#toTable_wrapper").find(".dataTables_length").parent().css("width", "130px");
                $("#toTable_paginate").parent().removeClass("col-sm-6").addClass("col-sm-12");
            }
        },
        "#fromTable":
        {
            "oLanguage": {"sLengthMenu": "Display _MENU_"},
            "bInfo" : false,
            ajax: {
                url: url + "/available",
                complete: stopSpinnerOnBulkCopyModal
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ]
            ,
            fnDrawCallback: function () {
                $("#fromTable_wrapper").find(".dataTables_length").parent().css("width", "130px");
                $("#fromTable_paginate").parent().removeClass("col-sm-6").addClass("col-sm-12");
            }
        }
    });

    //Add select All Copy Settings toggle
    $('#selectAllCopySettings').click(function() {
        var c = this.checked;
        $('.copyOptionCheckbox').prop('checked',c);
    });
}

function updatePrinterForm (data) {
    var newGroupId = 0;
    var crsId2 = "";

    for (var key in data)
    {
        if (key == "printerNumber") {
            $("#printerNumber").html(data[key]);
            $("#configurePrinterForm").attr("action", CONTEXT + "/printer/configure?printerNumber=" + data[key]);
            $("#pdsLinkPrinterNum").html("/" + data[key]);
            $("#pdhLinkPrinterNum").html("/" + data[key]);

            var qrAuth = $("#qrAuth");

            var qrAuthLabel = $("#qrAuthLabel");

            var td = $("#" + data[key] + "-guest");

            if(authenticationMethod == "NO_LOGIN" || authenticationMethod == "UNDEFINED")
            {
                qrAuth.prop("checked", false);
                qrAuth.addClass("disabled");
                qrAuth.attr("onclick", 'return false');
                qrAuth.attr("change", 'return false');

                qrAuthLabel.addClass("disabled");
                qrAuthLabel.attr("onclick", 'return false');
            }
            else if((authenticationMethod == "AAA_LOGIN" || authenticationMethod == "LDAP_LOGIN"
                || authenticationMethod == "PON_USERS" || authenticationMethod == "AZURE_AD")
                && td.length == 0)
            {
                qrAuth.prop("checked", true);
                qrAuth.addClass("disabled");
                qrAuth.attr("onclick", 'return false');
                qrAuth.attr("change", 'return false');

                qrAuthLabel.addClass("disabled");
                qrAuthLabel.attr("onclick", 'return false');
            }
            else
            {
                if ((typeof td !== "undefined") && td.find("span").length > 0 && td.find("span").attr("id") !== "undefined") {
                    qrAuth.prop('checked', (td.find("span").attr("id").indexOf("-enable") > -1));
                }
                else {
                    qrAuth.prop('checked', true);
                }
            }

        }
        else if (key == "newGroupId") {
            newGroupId = data[key];
        }
        else if (key == "groups") {
            var html = "";
            for (var groupId in data[key]) {
                if(groupId == $("#noDepartmentId").val()) {
                    html += "<option value='" + groupId + "'>" + $("#noDepartmentLabel").val() + "</option>"
                } else {
                    html += "<option value='" + groupId + "'>" + data[key][groupId] + "</option>"
                }
            }
            $("#newGroupId").html(html);
        }
        else if (key == "ponExternalUidModel" && data[key]) {
            $("#ponExternalUidId").val(data[key].id);
            $("#externalUidType").val(data[key].externalUidType);
            $("#ponExternalUidValue").val(data[key].externalUid);
        }
        else if (key == "mediaModelList") {

            var index = 0;

            for (var object in data[key])
            {
                var id = data[key][object].num;
                var name = data[key][object].name;
                var simplexPrice = data[key][object].simplexPrice;
                var duplexPrice = data[key][object].duplexPrice;

                if(simplexPrice == 0)
                {
                    simplexPrice = "";
                }

                if(duplexPrice == 0)
                {
                    duplexPrice = "";
                }

                if(!paperSizePriceExists(id))
                {
                    addMediaPrice(id, name, index, simplexPrice, duplexPrice);
                }
                else
                {
                    removeMediaPriceById(id);
                    addMediaPrice(id, name, index, simplexPrice, duplexPrice);
                }

                index ++;
            }

            showPrices($("#duplexingType").val());

            toggleIncludeTaxes();

            var payPerPrint = $("#payPerPrint");

            if(!data["payPerPrint"]) {
                $("#paymentOptions").hide();
            }
            payPerPrint.attr('checked', data["payPerPrint"]);

        }
        else if (key == "printerDesc") {
            $("#printerDesc").val(data[key]);
            $("#summary-printerDesc").html(data[key]);
        }
        else if (key == "paperSizes") {
            for (var paperKey in data[key]) {
                dtQueryRows("#paperSize-" + data[key][paperKey], "#paperSizes").prop("checked", true);
            }
        }
        else if (key == "defaultPaperSize") {
            changeDefaultPaperSize(data[key], dtQueryRows("#paperSizeDisplay-" + data[key], "#paperSizes").html());
        }
        else if (key == "releaseMode") {
            $("input[name='releaseMode'][value='" + data[key] + "']").prop("checked", true);
        }
        else if (key == "defaultLanguage") {
            $("#defaultLanguage").val(data[key]);
            $("#currentLabelLanguage").val(data[key]);
        }
        else if (key =="printerOnName") {
            $("#summary-printerOnName").html(data[key]);
            $("#printerOnName").val(data[key]);
        }
        else if (key == "networkLoginLabelByLanguage" || key == "clientUidLabelByLanguage" ||
            key == "sessionMetaDataLabelByLanguage" || key == "releaseCodeLabelByLanguage")
        {
            for (var lang in data[key]) {
                $("#" + key + "-" + lang).val(data[key][lang]);
            }
        }
        else if (key == "clientUidUse") {
            $("#clientUidUse").val(data[key]);
            $("input[name='clientUidUse']").val(data[key]);
        }
        else if (key == "pdhLinkProtocol") {

            //If is null, undefined or empty set http:// as default protocol
            if(!data[key] || data[key] === "")
            {
                $("#" + key).html('http://');
            }
            else
            {
                $("#" + key).html(data[key]);
            }

            updatePDHLink();
        }
        else if (key == "pdhLink") {
            $("#" + key).val(data[key]);
            updatePDHLink();
        }
        else if(key == "pdsLinkProtocol") {
            $("#pdsLinkProtocol").html(data[key]);
            $("#ippLinkProtocol").html(data[key]);
            updatePDSLink();
            updateIppLink();
        }
        else if(key == "pdsLink") {
            $("#ippLink").val(data[key]);
            $("#pdsLink").val(data[key]);
            updatePDSLink();
            updateIppLink();
        }
        else if (key == "crsId2") {
            // The crsId2 select is re-created after toggleAdditionalIntegration is called
            //So store the value and update the select after that call.
            crsId2 = data[key];
        }
        else if(key == "pdsUUID") {
            var mapPrinters = $("#mapPrinters");
            var mapNetworkPrinters = $("#mapNetworkPrinters");

            mapPrinters.attr("data-pds", data[key]);
            mapNetworkPrinters.attr("data-pds", data[key]);

            if (data[key] == "null" || data[key] == null) {
                mapPrinters.prop("disabled", true);
                mapNetworkPrinters.prop("disabled", true);
            }
            else {
                mapPrinters.prop("disabled", false);
                mapNetworkPrinters.prop("disabled", false);
            }
        }
        else if (data[key] === true || data[key] === false) {
            $("input[name='" + key + "']").prop("checked", data[key]);
        }
        else if (data[key] == "null") {
            $("#" + key).val("");
        }
        else {
            $("#" + key).val(data[key]);
        }
    }

    $("#newGroupId").val(newGroupId);

    updatePrinterEmails();

    bindConfigurePrinterForm();

    $("#editPrinterDialog").modal("show");

    createQrCode();

    togglePrintDriverInfo();

    togglePrintManagementService();

    if(data["releaseCodeAutoGenerate"] == true && data["releaseCodeForceNumeric"] == true) {
        toggleReleaseCodeOptions();
    }

    setLabelLanguage();

    updateRemoteReleaseUrl();

    updatePrinterModelSuggestions();

    toggleUsePDH();

    toggleEmailPrint();

    toggleAdditionalIntegration();

    toggleIppPrinterSettings();

    togglePaymentOptions();

    if (crsId2 == null) {
        $("#crsId2").val("null");
    }
    else {
        $("#crsId2").val(crsId2);
    }

    $("input.form-control[type='text']").on("change keyup paste", clearMessageError);

    changeCurrencySymbol(getSymbolByCurrencyId(data["currencyId"]));

    setUpAdvancedView(ADVANCED_VIEW_ENABLED);

    updateAaaCheckboxes();
}

function updateAaaCheckboxes () {
    if ($("#userAuthUrl").val().length) {
        $("#userAuthUrlEnable").prop("checked", true);
    }

    if ($("#webAuthUrl").val().length) {
        $("#webAuthUrlEnable").prop("checked", true);
    }

    if ($("#mobileAuthUrl").val().length) {
        $("#mobileAuthUrlEnable").prop("checked", true);
    }

    enableDisableAuthUrls();
}

function enableDisableAuthUrls () {
    var mobileAuthUrl = $("#mobileAuthUrl");
    var mobileAuthUrlSampleButton = $(".sampleUrlButton[data-destination='#mobileAuthUrl']");

    var userAuthUrl = $("#userAuthUrl");
    var userAuthUrlSampleButton = $(".sampleUrlButton[data-destination='#userAuthUrl']");

    var webAuthUrl = $("#webAuthUrl");
    var webAuthUrlSampleButton = $(".sampleUrlButton[data-destination='#webAuthUrl']");

    if (!$("#mobileAuthUrlEnable").is(":checked")) {
        mobileAuthUrl.addClass("disabled");
        mobileAuthUrl.attr("onclick", 'return false');
        mobileAuthUrlSampleButton.attr("disabled", true);
    }
    else
    {
        mobileAuthUrl.removeClass("disabled");
        mobileAuthUrl.attr("onclick", '');
        mobileAuthUrlSampleButton.attr("disabled", false);
    }

    if (!$("#userAuthUrlEnable").is(":checked")) {
        userAuthUrl.addClass("disabled");
        userAuthUrl.attr("onclick", 'return false');
        userAuthUrlSampleButton.attr("disabled", true);
    }
    else
    {
        userAuthUrl.removeClass("disabled");
        userAuthUrl.attr("onclick", '');
        userAuthUrlSampleButton.attr("disabled", false);
    }

    if (!$("#webAuthUrlEnable").is(":checked")) {
        webAuthUrl.addClass("disabled");
        webAuthUrl.attr("onclick", 'return false');
        webAuthUrlSampleButton.attr("disabled", true);
    }
    else
    {
        webAuthUrl.removeClass("disabled");
        webAuthUrl.attr("onclick", '');
        webAuthUrlSampleButton.attr("disabled", false);
    }
}

function showPrices(duplexingType)
{
    var duplexPrices = $(".duplexCol");
    var simplexPrices = $(".simplexCol");

    switch(duplexingType)
    {
        case "0":
        case "1":
            duplexPrices.hide();
            simplexPrices.show();
            break;
        case "2":
            duplexPrices.show();
            simplexPrices.hide();
            break;
        default:
            duplexPrices.show();
            simplexPrices.show();
            break;
    }
}

function bindConfigurePrinterForm ()
{
    useAjaxForForm("#configurePrinterForm", {
        beforeSend:function () {
            startSpinnerOnButton("#configurePrinterSubmit");

            $(".collapse-panel-container").each( function () {
                $(this).find(".panel-title").removeClass("errorHeading");
            });

        },
        success: function (resp) {
            if (resp != null && resp != "") {
                notifySuccess(resp);
            }

            $("#editPrinterDialog").modal("hide");

            prepareDataTable();
        },
        error: function (xhr) {
            // We need to handle the error messages for the labels seperatly
            // Error message must contain a list of languages the error occurs on
            if(xhr.status == 400) {
                var errors = JSON.parse(xhr.responseText);

                for (var error in errors) {

                    if (errors[error].field  == "networkLoginLabelByLanguage" || errors[error].field  == "clientUidLabelByLanguage" ||
                        errors[error].field  == "sessionMetaDataLabelByLanguage" || errors[error].field  == "releaseCodeLabelByLanguage") {

                        var languages = "";

                        var target = $("input[name^='" + errors[error].field + "']").filter(function () {
                            return $(this).val() == "";
                        });

                        target.each(function () {
                            var lang = $(this).data("language");
                            if (languages.indexOf(lang) == -1) {
                                if (languages.length != 0) {
                                    languages += ",";
                                }

                                languages += " " + lang;
                            }
                        });

                        addErrorToField(target, $("#valuesMayNotBeBlank").val() + languages);
                    }
                }
            }
            //If there are errors in a panel, turn the panel heading red
            $(".collapse-panel-container").each( function () {
                if ($(this).find(".error").length) {
                    $(this).find(".panel-title").addClass("errorHeading");
                }
            });
        },
        complete: function () {
            stopSpinnerOnButton("#configurePrinterSubmit");
        }
    });
}


/**
 * Sets a printer property via AJAX.
 *
 * @param event The click event.
 */
function setProperty(event) {

    // prevent clicking of sort button
    preventPropogation(event);

    // Get the ID
    var id = getIdFromEvent(event);

    // Blur the select box outta here
    $("#" + id).parent().blur();

    // Split the id on hyphens
    var parts = id.split('-');

    var printerId = parts[0];
    var property = parts[1];
    var action = parts[2];

    // Show confirmation dialog, the ok button will send the printer update
    if(printerId == "all") {

        // Get the appropriate dialog message
        var message = $("#confirmation-" + property + "-" + action).val();

        // Set the message
        var dialog = $("#confirmationDialog");
        dialog.find(".modal-body").html(message);

        // Save the current action and property, so saying yes on the modal can do it
        confirmationRequiredProperty = property;
        confirmationRequiredAction = action;

        // Set up the dialog
        dialog.modal("show");

    } else {
        sendPrinterUpdate(printerId, property, action);
    }
}

/**
 * Toggles a list entry option.
 *
 * @param printerId The id of the printer.
 * @param property The property we set.
 * @param action The action that was completed.
 * @param rows The DT rows, so you don't have re-query them (optional).
 * @param updateHead Whether to update the head option as required (optional, default true).
 */
function toggleListEntryOption(printerId, property, action, rows, updateHead) {

    // If rows were not supplied, query the table for them
    if (typeof rows === "undefined") {
        rows = dtGetAllRows($("#printerTable"));
    }

    // If update head is not supplied, default it to true
    if (typeof updateHead === "undefined") {
        updateHead = true;
    }

    // Grab the right td, tr, and the datatable (for api calls)
    var table = $('#printerTable').DataTable();
    var td = $("#" + printerId + "-" + property, rows);
    var tr = td.parent();

    // And the glyph inside
    var glyph = $("#" + printerId + "-" + property + "-" + action, td);

    // Replace check with x, or x with check
    if (action == 'disable') {

        // Change the glyph
        glyph.removeClass("glyphicons-ok");
        glyph.removeClass("green");
        glyph.addClass("glyphicons-remove");
        glyph.addClass("red");
        glyph.attr("id", printerId + "-" + property + "-enable");

        // Change the data order of the span
        td.attr('data-order', 2);
    } else {

        // Change the glyph
        glyph.removeClass("glyphicons-remove");
        glyph.removeClass("red");
        glyph.addClass("glyphicons-ok");
        glyph.addClass("green");
        glyph.attr("id", printerId + "-" + property + "-disable");

        // Change the data order of the span
        td.attr('data-order', 1);
    }

    // If we need to update the header option, go through the rows and see if any are disabled
    if (updateHead) {

        // Check for the status of the "all" flag
        var notEnabledList = rows.find("[id$=" + property + "] .glyphicons-remove");

        if (notEnabledList.length == 0) {
            toggleListHeaderOption(property, "enable", false);
        } else {
            toggleListHeaderOption(property, "disable", false);
        }
    }
}

/**
 * Toggles a list heading option.
 *
 * @param property The property that was changed.
 * @param action The completed action.
 * @param toggleAll Flag specifying whether we should toggle all the entries.
 */
function toggleListHeaderOption(property, action, toggleAll) {

    var span = $("#all-" + property + "-" + action);

    // Replace check with x, or x with check
    if(action == 'disable') {
        span.attr("id", "all-" + property + "-enable");
        span.removeClass("glyphicons-ok");
        span.removeClass("green");
        span.addClass("glyphicons-remove");
        span.addClass("red");
    } else {
        span.attr("id", "all-" + property + "-disable");
        span.removeClass("glyphicons-remove");
        span.removeClass("red");
        span.addClass("glyphicons-ok");
        span.addClass("green");
    }

    if(toggleAll) {

        var rows = dtGetAllRows($("#printerTable"));

        // Toggle all the options in the list
        $("[id$=" + property + "]", rows).each(function () {

            // Get the id and split it up
            var props = $(this).attr('id').split("-");

            // Toggle the right div
            toggleListEntryOption(props[0], props[1], action, rows, false);
        });
    }
}

/**
 * Gets the printer info, and displays it in a model.
 *
 * @param event The click event.
 */
function showDetails(event) {

    // Get the ID
    var id = getIdFromEvent(event);

    // Get the dialog
    var dialog = $("#printerDetailsDialog");
    var dialogDetails = dialog.find("#details");
    var dialogError = dialog.find("#error");

    // Hide the details, show the spinner
    dialogDetails.addClass("hidden");
    dialogError.addClass("hidden");
    startSpinner("#printerDetailsBody", spinner.large);

    // Show the dialog
    dialog.modal("show");

    // Split the id, so you can get the printer ID
    var printerId = id.split("-")[0];

    // Send an ajax request for the printer info
    ajax({
        url: CONTEXT + "/printers/" + printerId + "/details",
        type: "GET",
        success: function (resp) {

            // Address information in the dialog
            dialogDetails.find("#locationDesc").html(resp.locationDesc);
            dialogDetails.find("#addressLine1").html(resp.addressLine1);

            if(resp.addressLine2) {
                dialogDetails.find("#addressLine2").html(resp.addressLine2);
                dialogDetails.find("#addressLine2").removeClass("hidden");
            } else {
                dialogDetails.find("#addressLine2").addClass("hidden");
            }

            dialogDetails.find("#cityProvincePostal").html(resp.city + ", " + resp.province + ", " + resp.postal);
            dialogDetails.find("#country").html(resp.country);


            // Fill in usage information
            dialogDetails.find("#printerDetailName").html(resp.printerName);
            dialogDetails.find("#emailAddressName").html('<a href="mailto:'+resp.emailAddressName+'">' + resp.emailAddressName + '</a>');
            dialogDetails.find("#emailAddressNum").html('<a href="mailto:'+resp.emailAddressNumber+'">' + resp.emailAddressNumber + '</a>');
            dialogDetails.find("#printerNumber").html(resp.printerId);
            dialogDetails.find("#lprUrl").html(resp.lprUrl);

            // Hide the e-mails if they're null
            if(!resp.emailAddressName && !resp.emailAddressNumber) {
                dialogDetails.find("#emails").addClass("hidden");
            } else {
                dialogDetails.find("#emails").removeClass("hidden");

                if(resp.emailAddressName) {
                    dialogDetails.find("#emailAddressName").removeClass("hidden");
                } else {
                    dialogDetails.find("#emailAddressName").addClass("hidden");
                }

                if(resp.emailAddressNumber) {
                    dialogDetails.find("#emailAddressNum").removeClass("hidden");
                } else {
                    dialogDetails.find("#emailAddressNum").addClass("hidden");
                }
            }

            // Fill in features information
            dialogDetails.find("#model").html(resp.model);

            if(resp.jobRelease.toUpperCase() === "REQUIRED") {
                dialogDetails.find("#jobRelease").html($("#jobPickupRequiredMessage").val());
            } else if(resp.jobRelease.toUpperCase() === "OPTIONAL") {
                dialogDetails.find("#jobRelease").html($("#jobPickupOptionalMessage").val());
            } else {
                dialogDetails.find("#jobRelease").html($("#jobPickupNoneMessage").val());
            }

            dialogDetails.find("#color").html(resp.color ? $("#colorMessage").val() : $("#bwMessage").val());
            dialogDetails.find("#coverPage").html(resp.coverPage ? $("#coverRequiredMessage").val() : $("#coverNoneMessage").val());

            // Fill in pricing information
            var pricingInfo = "";
            var isPayPerPrint = resp["payPerPrint"];

            if(resp.printerMedia.length != 0) {

                pricingInfo += '<table class="table"><thead><tr><th class="col-xs-4 text-left">' + $("#paperSizeTitle").val() + "</th>";

                if(isPayPerPrint)
                {
                    $("#paperTitle").hide();
                    $("#priceAndPaperTitle").show();

                    if (resp.duplexPermit.toLowerCase() !== "duplex_only")
                    {
                        pricingInfo += '<th class="col-xs-3 text-right">' + $("#singleSidedTitle").val() + "</th>"
                    }

                    if (resp.duplexPermit.toLowerCase() !== "simplex_only")
                    {
                        pricingInfo += '<th class="col-xs-3 text-right">' + $("#doubleSidedTitle").val() + "</th>"
                    }
                }
                else
                {
                    $("#paperTitle").show();
                    $("#priceAndPaperTitle").hide();

                    pricingInfo += '<th class="col-xs-3 text-right"></th>';
                    pricingInfo += '<th class="col-xs-3 text-right"></th>';
                }

                pricingInfo += "</tr></thead><tbody>";

                resp.printerMedia.forEach(function (media) {

                    if(media['default']) {
                        pricingInfo += '<tr class="info">';
                    } else {
                        pricingInfo += '<tr>';
                    }

                    pricingInfo += "<td>" + media.dimensions + "</td>";

                    if(isPayPerPrint)
                    {
                        pricingInfo += '<td class="text-right">' + (media.simplexPrice ? media.simplexPrice : "") + '</td>';
                        pricingInfo += '<td class="text-right">' + (media.duplexPrice ? media.duplexPrice : "") + '</td>';
                    }
                    else
                    {
                        pricingInfo += '<td class="text-right"></td>';
                        pricingInfo += '<td class="text-right"></td>';
                    }

                    pricingInfo += '</tr>';
                });

                pricingInfo += "</tbody></table>";

                if(resp.minJobCharge) {
                    dialogDetails.find("#minJobChargeRow").removeClass("hidden");
                    dialogDetails.find("#minJobCharge").html(resp.minJobCharge);
                } else {
                    dialogDetails.find("#minJobChargeRow").addClass("hidden");
                }

                if(resp.taxRate) {
                    dialogDetails.find("#taxRateRow").removeClass("hidden");
                    dialogDetails.find("#taxRate").html(resp.taxRate+"%");
                } else {
                    dialogDetails.find("#taxRateRow").addClass("hidden");
                }

            } else {
                pricingInfo = $("#noPricing").val();
                $("#minJobChargeRow").addClass("hidden");
                $("#taxRateRow").addClass("hidden");

                $("#paperTitle").show();
                $("#priceAndPaperTitle").hide();

                pricingInfo += '<th class="col-xs-3 text-right"></th>';
                pricingInfo += '<th class="col-xs-3 text-right"></th>';
            }

            $("#pricing").html(pricingInfo);

            // Fill in additional information if required
            var additionalInfo = $("#additionalInfoPanel");
            if(resp.location || resp.description || resp.info || resp.hoursOfOperation) {

                $("#location").html(resp.location);
                $("#description").html(resp.description);
                $("#info").html(resp.info);
                $("#hours").html(resp.hoursOfOperation);

                if(resp.location) {
                    $("#additionalLocation").removeClass("hidden");
                } else {
                    $("#additionalLocation").addClass("hidden");
                }

                if(resp.description) {
                    $("#additionalDescription").removeClass("hidden");
                } else {
                    $("#additionalDescription").addClass("hidden");
                }

                if(resp.info) {
                    $("#additionalInfo").removeClass("hidden");
                } else {
                    $("#additionalInfo").addClass("hidden");
                }

                if(resp.hoursOfOperation) {
                    $("#additionalHours").removeClass("hidden");
                } else {
                    $("#additionalHours").addClass("hidden");
                }

                additionalInfo.removeClass("hidden");
            } else {
                additionalInfo.addClass("hidden");
            }

            // hide the spinner, show the data
            stopSpinner("#printerDetailsBody");
            dialogError.addClass("hidden");
            dialogDetails.removeClass("hidden");
        },
        error: function (resp) {

            // Show error text
            stopSpinner("#printerDetailsBody");
            dialogError.removeClass("hidden");
            dialogDetails.addClass("hidden");
        }
    });
}

/**
 * Shows the printer edit page, in a iframe modal.
 *
 * @param event The click event.
 */
function showEdit(event) {

    // Get the ID and split it for the printer id
    var printer = getIdFromEvent(event).split("-")[0];

    // Serialize the list into an array of uuids
    var uuids = $("#" + printer + "-pdsUUIDs").val();

    // No PDS uuids defined, do nothing
    if(!uuids) {
        return;
    }

    uuids = uuids.split(",");

    if(uuids.length == 1) {

        showEditFrame(printer, uuids[0]);

    } else {

        // Clear existing list in the modal
        var pdsList = $("#pdsList");
        pdsList.find("li").remove();

        for(var i = 0; i < uuids.length; i++) {

            // Get the host name
            var host = $("#pdsHost_" + uuids[i].trim()).val();

            // Add host name to server list, with an onclick if it's online
            pdsList.append('<li><a onclick="showEditFrame(\'' + printer + '\',\'' + uuids[i].trim() + '\')">' + host + '</a></li>');
        }

        $("#pdsSelectDialog").modal("show");
    }
}

/**
 * Shows the edit frame.
 *
 * @param printer The printer ID.
 * @param uuid The pds UUID to use.
 */
function showEditFrame(printer, uuid) {

    // Close the edit select modal if it's open
    $("#pdsSelectDialog").modal("hide");

    // Keep track of the printer you're editing
    editingPrinter = printer;

    // Hide printers panel
    $("#printersPanel").addClass("hidden");

    // Start the spinner
    startSpinner("#wrap", spinner.large);

    // Add the Iframe with the guest settings
    $("#printerEdit").html($('<iframe id="printerSettingsFrame" onload="editFrameLoad()" width="100%" scrolling="no" frameborder="0" src="' + CONTEXT + '/iframe/pds/' + uuid + "/printers/" +  printer + '/"/>'));
}

/**
 * Synchronizes printers and refreshes the page.
 *
 * @param event The click event.
 */
function synchronizePrinters(event) {
    if(!synchInProgress) {
        $("#lastSynch").hide();

        $("#synchronize").hide();

        $("#loading-synch").show();

        synchInProgress = true;

        // Send ajax request
        ajax({
            url: CONTEXT + "/printers/synchronize",
            type: "POST",
            data: {
                "syncCPS": $("#syncCPSCheckbox").is(":checked"),
                "syncPDG": $("#syncPDGCheckbox").is(":checked"),
                "syncPDS": $("#syncPDSCheckbox").is(":checked")
            },
            beforeSend: function(xhr) {
                dataTableWrapper.hide();
                startSpinner("#printersPanelBody", spinner.large);
                startSpinner("#loading-synch", spinner.small, false);

                // Say you're working
                $("#synchStatus").html($("#synchWorking").val());
            },
            success: function (resp) {
                $("#synchronize").show();

                stopSpinner("#loading-synch");
                $("#loading-synch").hide();


                prepareDataTable();
                synchInProgress = false;
            },
            error: function (resp) {
                dataTableWrapper.show();
                stopSpinner("#printersPanelBody");

                $("#synchronize").show();

                stopSpinner("#loading-synch");
                $("#loading-synch").hide();

                // Display that there was an error.
                $("#synchStatus").html('<span class="halflings halflings-remove-sign pad-left"></span>' + resp.responseText);

                // Clear in progress so that they can try again
                synchInProgress = false;
            }
        });
    }

}

/**
 * Sends an ajax request to modify printer info.
 *
 * @param printerId The printer ID, or "all".
 * @param property The property we're setting.
 * @param action The action we want.
 */
function sendPrinterUpdate(printerId, property, action) {

    // Post to printers
    ajax({
        url: CONTEXT + "/printers/" + printerId + "/" + property + "/" + action + "?printerClass=" + printerClass,
        type: "POST",
        beforeSend: function(xhr) {

            // Set the contents of the modal to a spinner
            startSpinnerOnButton("#confirmationButton");
        },
        success: function (resp) {

            if(printerId == "all") {

                // Toggle the buttons
                toggleListHeaderOption(property, action, true);

            } else {

                // Toggle the list entry option
                toggleListEntryOption(printerId, property, action);
            }

            // Hide the modal
            $('#confirmationDialog').modal("hide");
        },
        error: function (resp) {

            if(printerId == "all") {
                notifyError($("#updateAllFailed").val());
            } else {
                notifyError($("#updateOneFailed").val());
            }
        },
        complete: function() {
            stopSpinnerOnButton("#confirmationButton");
        }
    });
}

/**
 * Called on load of the edit frame.
 */
function editFrameLoad() {

    if (!$("#saveSuccess", $("#printerSettingsFrame").contents()).length) {

        // Hide the spinner
        stopSpinner("#wrap");

        // Show the frame
        $("#printerEdit").removeClass("hidden");

        // Change the height of the iframe
        var frame = $("#printerSettingsFrame");
        frame[0].height = frame[0].contentWindow.document.body.scrollHeight;

        // Overload the cancel to hide the panel and show the printer panel
        $("#cancelButton", frame.contents()).click(function (event) {

            preventPropogation(event);

            $("#printersPanel").removeClass("hidden");
            $("#printerEdit").addClass("hidden");

            return false;
        });

        // Override the apply button, and add device updating for printers
        $("#applyButton", frame.contents()).click(function (event) {

            // Change the device in the printer list
            $("#" + editingPrinter + "-device").html($("#knownScheme", frame.contents()).val() + $("#device", frame.contents()).val());

        });

    } else {

        // Hide the loading spinner
        $("#editLoading").addClass("hidden");

        // Show the frame
        $("#printerEdit").addClass("hidden");

        // Hide printers panel
        $("#printersPanel").removeClass("hidden");

        notifySuccess($("#saveSuccess", $("#printerSettingsFrame").contents()).val());
    }

    var iFrame = "#printerSettingsFrame";
    var contents = $(iFrame).contents();

    contents.find("body").on('click', function(){

        parent.$('#printerSettingsFrame').trigger('click');

    });
}
