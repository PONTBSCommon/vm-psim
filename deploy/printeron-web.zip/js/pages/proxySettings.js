

$(function(){
    var enabled = $("#enableProxy").prop('checked');

    if(enabled != true)
        $("#proxyDiv :input").attr("disabled", true);

    $('#enableProxy').click(function() {
        $("#proxyDiv :input").attr("disabled", enabled);
        enabled = !enabled;
    });
});


function doAjaxPost() {

    $("#proxyTestResult").val("Testing...");
    $("#proxyTestResultSsl").val("Testing...");

    var proxyUsername = $('#proxyUser').val();
    var proxyPort = $('#proxyPort').val();
    var proxyUrl = $('#proxyUrl').val();
    var proxyPassword = $('#proxyPassword').val();

    ajax({
        type : "POST",
        url : window.location.pathname + "/testProxy",
        data : "proxyUrl=" + proxyUrl + "&proxyPort=" + proxyPort + "&proxyUsername="
        + proxyUsername + "&proxyPassword=" + proxyPassword,
        dataType:"json",
        success : function(response) {
            $("#proxyTestResult").val(response.nonssl);
            $("#proxyTestResultSsl").val(response.ssl);
        },
        error : function(e) {

            // TODO: localize?
            $("#proxyTestResult").val("Test Failed");
            $("#proxyTestResultSsl").val("Test Failed");
        }
    });
}