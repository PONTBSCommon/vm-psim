/**
 * Created by bershaa on 2/3/2015.
 */
var currentForm;

$(document).ready(function() {

    $('form').submit(function(e) {
        currentForm = this;
        $('#set-confirm').modal('show');

        return false;
    });

});

function submitForm()
{
    $('#set-confirm').modal("hide");
    currentForm.submit();
}

function autoConfigure(){
    $("#autoConfigureWarning").modal("show");
}

function autoConfigureWarningYES() {
    $("#autoConfigureWarning").modal("hide");
    notifyInfo($("#autoConfigureInProgress").val());
    performAutoConfigure();
}

function performAutoConfigure(){

    ajax({
        type : "POST",
        url : CONTEXT + "/pas/" + pasUuid + "/applications/autoConfigure",
        success : function(response) {

            notifySuccess($("#autoConfigured").val());

            setTimeout( function(){
                location.reload();
            }, 2000 );
        },
        error : function(e) {

        }
    });
}