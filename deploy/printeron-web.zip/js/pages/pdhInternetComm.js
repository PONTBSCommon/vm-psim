var disableInputsLookup = {
    'enableXMPPListener1' : ['#xmppServerName', '#xmppServerPort', '#xmppAccountID', '#xmppPassword']
};

function disableInputs (element) {
    var inputsToDisable = disableInputsLookup[element.attr('id')],
        input;
    for (input in inputsToDisable) {
        $(inputsToDisable[input]).prop('disabled', !element.is(':checked'));
    }
}

$(document).on('click', '.disables-inputs', function () {disableInputs($(this))});

$(document).ready( function () {

    if(!$("#enableRegisterClient").is(":checked")) {

        // Disable the deregister box
        $("label[for='enableDeregisterClient']").attr('onclick', 'return false;').addClass("disabled");
    }

    enablePort();

    for (inputs in disableInputsLookup) {
        disableInputs($('#' + inputs));
    }

    $("#enhancedClientAuthenticationPolicy").change(function() {
        authenticationPolicyChange();
    });

    authenticationPolicyChange();

    $("#enableRegisterClient").click(function() {

        if($("#enableRegisterClient").is(":checked")) {

            // Enabled register client, enable deregister
            $("#enableDeregisterClient").prop('checked', true);
            $("label[for='enableDeregisterClient']").attr('onclick', '').removeClass("disabled");

        } else {

            // Disabled register client, can't enable deregister
            $("#enableDeregisterClient").prop('checked', false);
            $("label[for='enableDeregisterClient']").attr('onclick', 'return false;').addClass("disabled");
        }
    });
});

function authenticationPolicyChange(){
    var authenticationPolicy = $("#enhancedClientAuthenticationPolicy").val();

    if(authenticationPolicy == "ALWAYS"){
        $("#password").attr("disabled", true);
    }else {
        $("#password").removeAttr("disabled");
    }
}

function enablePort() {
    var isChecked = $("#defaultIPPPortEnabled").is(':checked');

    if (isChecked) {
        $('#enableSSLLocalListener1').removeAttr('disabled');
        $('#defaultIPPPort').removeAttr('disabled');
    } else {
        $('#enableSSLLocalListener1').attr('disabled', 'disabled');
        $('#defaultIPPPort').attr('disabled', 'disabled');
    }

    isChecked = $("#additional1PortEnabled").is(':checked');

    if (isChecked)
    {
        $('#enableSSLLocalListener2').removeAttr('disabled');
        $('#additional1Port').removeAttr('disabled');
    }
    else {
        $('#enableSSLLocalListener2').attr('disabled', 'disabled');
        $('#additional1Port').attr('disabled', 'disabled');
    }

    isChecked = $("#additional2PortEnabled").is(':checked');

    if(isChecked) {
        $('#enableSSLLocalListener3').removeAttr('disabled');
        $('#additional2Port').removeAttr('disabled');
    }
    else {
        $('#enableSSLLocalListener3').attr('disabled', 'disabled');
        $('#additional2Port').attr('disabled', 'disabled');
    }
}

$(document).on('click', '#xmppTest', function () {

    notifyInfo($("#runXmppTest").val());

    ajax({
        url: "internetComm/testXMPP",
        type: "POST",
        data: {
            xmppServerName: $("#xmppServerName").val(),
            xmppServerPort: $("#xmppServerPort").val(),
            xmppAccountID: $("#xmppAccountID").val(),
            xmppPassword: $("#xmppPassword").val()
        },
        success: function (JSON) {
            if (JSON.connectionSuccess) {

                notifySuccess($("#runXmppTestSuccess").val());
            }
            else {

                notifyError(JSON.message);
            }
        }
    })
});