var _chartMap = {};

$(document).ready(function () {Chart.defaults.global.responsive = true;});

function destroyChart(table) {
    table = $(table);

    if (typeof _chartMap[table.attr("id")] !== "undefined") {
        _chartMap[table.attr("id")].destroy();
    }
}

function destroyChartAndDT(table) {
    dtDestroy(table);
    destroyChart(table);
}

function findAndCreateAllChartsAndDTs() {
    findAndCreateBarChartsAndDTs();
    findAndCreatePieChartsAndDTs();
}

function findAndCreateBarChartsAndDTs() {
    $("table[data-charttype='bar']").each(function () {
        dtLoad($(this));
        createBarChartFromDT($(this));
    });
}

function findAndCreateBarChartsFromDTs() {
    $("table[data-charttype='bar']").each(function () {
        createBarChartFromDT($(this));
    });
}

function findAndCreatePieChartsAndDTs() {
    $("table[data-charttype='pie']").each(function () {
        dtLoad($(this));
        createPieChartFromDT($(this));
    });
}

function findAndCreatePieChartsFromDTs() {
    $("table[data-charttype='pie']").each(function () {
        createPieChartFromDT($(this));
    });
}

function createChartAndDT (table, options) {
    if (table.data("charttype") == "bar") {
        dtLoad(table);
        createBarChartFromDT(table);
    }
    else if (table.data("charttype") == "pie") {
        dtLoad(table);
        createPieChartFromDT(table, options);
    }
}

function createChartFromDT (table, options) {
    if (table.data("charttype") == "bar") {
        createBarChartFromDT(table);
    }
    else if (table.data("charttype") == "pie") {
        createPieChartFromDT(table, options);
    }
}

function createBarChartFromDT (table, options) {

    // Destroy the chart if it exists
    destroyChart(table);

    table = $(table);

    var data = {};
    data.datasets = [];

    if (typeof options === "undefined") {
        options = {multiTooltipTemplate: "<%= datasetLabel %> - <%= value %>"};
    }

    var canvas = $(table.data("canvas"));
    var ctx = canvas.get(0).getContext("2d");

    var numSeries = table.data("numseries");

    var series = {};
    var labels = [];

    for (var i = 0; i < numSeries; i++)
    {
        series[i] = [];
    }

    dtGetAllRows(table).each(function () {
        $(this).find("[data-series]").each(function () {
            series[$(this).data("series")].push($(this).data("value"))
        });

        labels.push($(this).find("[data-chartlabel]").data("chartlabel"));
    });

    for (var j = 0; j < numSeries; j++) {
        var d = {};
        d.label = table.data("label" + j);
        d.fillColor = canvas.data("fillcolor" + j);
        d.strokeColor = canvas.data("strokecolor" + j);
        d.highlightFill = canvas.data("highlightfill" + j);
        d.highlightStroke = canvas.data("highlightstroke" + j);
        d.data = series[j];

        data.datasets.push(d);
    }

    data.labels = labels;

    if (data.datasets.length && data.datasets[0].data.length) {
        _chartMap[table.attr("id")] = new Chart(ctx).Bar(data, options);
    }
    else {
        console.log("No data present. Skipping chart creation.");
    }
}

function createPieChartFromDT(table, options) {

    // Destroy the chart if it exists
    destroyChart(table);

    table = $(table);

    if (typeof options === "undefined") {
        options = {multiTooltipTemplate: "<%= datasetLabel %> - <%= value %>"};
    }

    var canvas = $(table.data("canvas"));
    var ctx = canvas.get(0).getContext("2d");

    var data = [];

    dtGetAllRows(table).each(function () {
        var d = {};
        d.label = $(this).data("chartlabel");
        d.highlight = $(this).data("highlight");
        d.color = $(this).data("color");
        d.value = $(this).data("value");

        data.push(d);
    });

    if (data.length) {
        _chartMap[table.attr("id")] = new Chart(ctx).Pie(data, options);
    }
    else {
        console.log("No data present. Skipping chart creation.");
    }
}

function createLineChart(canvas, data, options) {

    // Destroy the chart if it exists
    destroyChart(canvas);

    canvas = $(canvas);

    var ctx = canvas.get(0).getContext("2d");

    if (typeof options === "undefined") {
        options = {
            multiTooltipTemplate: "<%= datasetLabel %> - <%= value %>",
            tooltipTemplate: "<%= label %> - <%= value %> "
        };
    }

    _chartMap[canvas.attr("id")] = new Chart(ctx).Line(data, options);
}

function createPieChart(canvas, data, options) {

    // Destroy the chart if it exists
    destroyChart(canvas);

    canvas = $(canvas);

    var ctx = canvas.get(0).getContext("2d");

    if (typeof options === "undefined") {
        options = {
            multiTooltipTemplate: "<%= datasetLabel %> - <%= value %>",
            tooltipTemplate: "<%= label %> - <%= value %> "
        };
    }

    _chartMap[canvas.attr("id")] = new Chart(ctx).Pie(data, options);
}