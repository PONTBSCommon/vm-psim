var startDate = $("#startDate");
var endDate = $("#endDate");
var dateError = $("#dateErrors");
var messages = $("#messages");
var reportPanel = $("#reportPanel");
var reportData = $("#reportData");
var spinner = $("#loading");

/**
 * Generates a report, based on the data in the selector divs.
 */
function generateReport() {

    // Get printer Id
    var printerAlias = encodeURIComponent($("#printerSelect").val());

    // Get the start/end time
    var start = startDate.datepicker("getDate");
    var end = endDate.datepicker("getDate");

    // If the start or end are null, something's up
    if (start == null || end == null || (start > end)) {
        return;
    }

    // Adjust the end to the end of the day
    end.setHours(23);
    end.setMinutes(59);
    end.setSeconds(59);
    end.setMilliseconds(999);

    // Convert to epoch millis
    start = start.getTime();
    end = end.getTime();

    // Get the report
    ajax({

        url: CONTEXT + "/reports/printer/" + start + "/" + end + "?displayName=" + encodeURI($("#printerSelect").find("option:selected").data("display")) + "&aliasTail=" + printerAlias,
        type: "GET",

        beforeSend: function(xhr) {

            // Display the panel
            reportPanel.removeClass('hidden');

            // Show the spinner
            reportData.addClass('hidden');
            spinner.removeClass('hidden');
            messages.addClass('hidden');

            // Remove error from daterange
            startDate.removeClass("error");
            endDate.removeClass("error");
            dateError.addClass("hidden");

        },

        success: function (html) {

            var displayName = $("#printerSelect").find("option:selected").data("displayname");
            var chartPagesTooltip =  {tooltipTemplate: "<%= label %> - <%= value %> <% if (value == 1){%>" + $("#localizedJob").val() + "<%} else{%>" + $("#localizedJobs").val() + "<%}%>"};
            var chartImpressionsTooltip = {tooltipTemplate: "<%= label %> - <%= value %> <% if (value == 1){%>" + $("#localizedImpression").val() + "<%} else{%>" + $("#localizedImpressions").val() + "<%}%>"};

            // Hide the spinner and messages
            spinner.addClass('hidden');
            messages.addClass('hidden');

            // Clear the datatable
            dtDestroy("#reportTable");

            $("#reportData").html(html);

            var reportTable = $("#reportTable");

            var colorJobs = $("#colourPrintJobs").val(),
                colourImpressions = $("#colourImpressions").val(),
                bwJobs = $("#bwPrintJobs").val(),
                bwImpressions = $("#bwImpressions").val(),
                duplex = {},
                duplexImpressions = {},
                user = {},
                userImpressions = {};

            //No report data found, no activity
            if(colorJobs == 0 && bwJobs == 0) {
                messages.html($("#emptyReport").val());
                messages.removeClass("hidden");

                $("#reportCharts").hide();
                reportTable.hide();
                reportData.removeClass("hidden");
                return;
            }
            else {
                $("#reportCharts").show();
                reportTable.show();
            }

            dtLoad(reportTable);

            $(".userReport").each(function () {
               user[$(this).data("user")] = $(this).val();
            });

            $(".userImpressions").each(function () {
                userImpressions[$(this).data("user")] = $(this).val();
            });

            $(".duplexReport").each(function () {
               duplex[$(this).data("duplex")] = $(this).val();
            });

            $(".duplexImpressions").each(function () {
                duplexImpressions[$(this).data("duplex")] = $(this).val();
            });

            if (colorJobs != 0 || bwJobs != 0) {
                if ($("#advReporting").length) {
                    var cvbPanel = $("#colorVsBwChartPanel");
                    var data = [
                        {
                            label: $("#localizedColor").val(),
                            color: $("#pieChartColor-0").val(),
                            highlight: $("#pieChartHighlightColor-0").val(),
                            value: colorJobs
                        },
                        {
                            label: $("#localizedBw").val(),
                            color: $("#pieChartColor-1").val(),
                            highlight: $("#pieChartHighlightColor-1").val(),
                            value: bwJobs
                        }
                    ];

                    cvbPanel.show();
                    createPieChart("#colorVsBwChart", data, chartPagesTooltip);

                    var userChartData = [];
                    var userCount = 0;
                    for (var email in user) {
                        var userJson = {
                            label: email,
                            color: $("#pieChartColor-" + (userCount % 10)).val(),
                            highlight: $("#pieChartHighlightColor-" + (userCount % 10)).val()
                        };
                        $.extend(true, userJson, {value: user[email]});
                        userChartData.push(userJson);
                        userCount ++;
                    }

                    $("#userChartPanel").show();
                    createPieChart("#userChart", userChartData, chartPagesTooltip);

                    if ($("#disconnected").length) {
                        var cvbiPanel = $("#colorVsBwImpressionChartPanel");
                        data = [
                            {
                                label: $("#localizedColor").val(),
                                color: $("#pieChartColor-0").val(),
                                highlight: $("#pieChartHighlightColor-0").val(),
                                value: colourImpressions
                            },
                            {
                                label: $("#localizedBw").val(),
                                color: $("#pieChartColor-1").val(),
                                highlight: $("#pieChartHighlightColor-1").val(),
                                value: bwImpressions
                            }
                        ];

                        cvbiPanel.show();
                        createPieChart("#colorVsBwImpressionChart", data, chartImpressionsTooltip);

                        var userChartImpressionData = [];
                        var userImpressionCount = 0;
                        for (var email in userImpressions) {
                            var userJson = {
                                label: email,
                                color: $("#pieChartColor-" + (userImpressionCount % 10)).val(),
                                highlight: $("#pieChartHighlightColor-" + (userImpressionCount % 10)).val()
                            };
                            $.extend(true, userJson, {value: userImpressions[email]});
                            userChartImpressionData.push(userJson);
                            userImpressionCount ++;
                        }

                        $("#userImpressionChartPanel").show();
                        createPieChart("#userImpressionChart", userChartImpressionData, chartImpressionsTooltip);

                        var chartData = [];
                        var count = 0;
                        for (var key in duplex) {
                            var json = {
                                label: key,
                                color: $("#pieChartColor-" + count).val(),
                                highlight: $("#pieChartHighlightColor-" + count).val()
                            };
                            $.extend(true, json, {value: duplex[key]});
                            chartData.push(json);
                            count ++;
                        }

                        $("#duplexingChartPanel").show();
                        createPieChart("#duplexingChart", chartData, chartPagesTooltip);

                        var duplexImpressionData = [];
                        var impressionCount = 0;
                        for (var key in duplexImpressions) {
                            var json = {
                                label: key,
                                color: $("#pieChartColor-" + impressionCount).val(),
                                highlight: $("#pieChartHighlightColor-" + impressionCount).val()
                            };
                            $.extend(true, json, {value: duplexImpressions[key]});
                            duplexImpressionData.push(json);
                            impressionCount ++;
                        }

                        $("#duplexingImpressionChartPanel").show();
                        createPieChart("#duplexingImpressionChart", duplexImpressionData, chartImpressionsTooltip);
                    }
                }
            }
            else
            {
                $("#colorVsBwChartPanel").hide();
                $("#duplexingChartPanel").hide();
                $("#userChartPanel").hide();
            }

            dtQueryRows(".convertDateTime", reportTable).each(function () {
                // Make a date object out of the date
                var time = new Date(0);
                time.setUTCMilliseconds($(this).html());
                time = time.toLocaleString();

                $(this).html(time);
            });

            // Display the report
            reportData.removeClass("hidden");
        },

        error: function () {

            // Hide the spinner
            spinner.addClass('hidden');

            // Display that there was an error with the report
            messages.html($("#internalError").val());
            messages.removeClass('hidden');

            $("#colorVsBwChartPanel").hide();
            $("#duplexingChartPanel").hide();
            $("#userChartPanel").hide();
        }
    });
}

function setExportLink () {

    // Get printer Id
    var printerAlias = encodeURIComponent($("#printerSelect").val());
    var displayName = $("#printerSelect").find("option:selected").data("display");

    // Get the start/end time
    var start = startDate.datepicker("getDate");
    var end = endDate.datepicker("getDate");

    // If the start or end are null, something's up
    if (start == null || end == null || (start > end)) {
        return;
    }

    // Adjust the end to the end of the day
    end.setHours(23);
    end.setMinutes(59);
    end.setSeconds(59);
    end.setMilliseconds(999);

    // Convert to epoch millis
    start = start.getTime();
    end = end.getTime();

    $("#reportDownload").attr("href", CONTEXT + "/reports/printer/" + start + "/" + end + "/report.csv" + "?displayName=" + displayName + "&aliasTail=" + printerAlias);
}

/**
 * On load.
 */
$(document).ready(function() {
    initDatePickers({startDate: "-89d"});

    $("input, select").change(setExportLink);

    // Register change event for start date
    startDate.change(function() {

        // This is null, set the error and add a tooltip
        if(startDate.datepicker("getDate") == null) {

            // Add an error class
            startDate.addClass("error");

            // Display error
            dateError.removeClass("hidden");

        // It's not null, remove the error, remove the tooltip if both not null
        } else {

            startDate.removeClass("error");

            if(endDate.datepicker("getDate") != null) {
                dateError.addClass("hidden");
            }
        }
    });

    // Register change event for end date
    endDate.change(function() {

        if(endDate.datepicker("getDate") == null) {

            // Add an error class
            endDate.addClass("error");

            // Display error
            dateError.removeClass("hidden");
        } else {

            endDate.removeClass("error");

            if(startDate.datepicker("getDate") != null) {
                dateError.addClass("hidden");
            }
        }
    });

    setExportLink();
});