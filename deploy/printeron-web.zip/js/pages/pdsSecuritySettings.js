var currentForm;

$(function (){
    disablePanel();

    $( "#encryptionPolicy" ).change(function() {
        disablePanel();
    });

    var action = getUrlParameter("rsagenerated");

    if(action == "true") {
        notifySuccess($("#rsaKeyGeneratedSuccess").val());
    }

    var action = getUrlParameter("deleted");

    if(action == "true") {
        notifySuccess($("#rsaKeyDeletedSuccess").val());
    }

    $("#submitForm").click(function() {
        var form = $("#securityForm");

        form.attr("action", $("#formAction").val());

        form.submit();
    });

    $('form').submit(function(e) {
        currentForm = this;
        if (isDelete) {
            $('#delete-confirm').modal('show');
        } else {
            return true;
        }

        return false;
    });
});

function deleteConfirmYES() {
    currentForm.action = $("#formAction").val() + "/generateordelete?generate=false&delete=true"

    currentForm.submit();
}

function getUrlParameter(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

function disablePanel(){
    if( $("#encryptionPolicy option:selected").text() == "Never" ) {
        $('#rsaPanel :input').attr('disabled', true);

    }else{
        $('#rsaPanel :input').removeAttr('disabled');
        $('#rsaKeyPairTimestamp').attr('disabled', true);
    }
}

var isDelete = false;

function deleteKeys(){
    isDelete = true;
}

function generateKeys(){
    isDelete = false;

    this.securityForm.action = $("#formAction").val() + "generateordelete?generate=true&delete=false";
}

