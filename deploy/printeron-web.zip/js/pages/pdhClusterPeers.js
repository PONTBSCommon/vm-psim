/**
 * Created by bershaa on 2/9/2015.
 */
var currentForm;

$(function(){
    $('#deleteClusterForm').submit(function(e) {
        currentForm = this;

        $('#delete-prompt').modal('show');

        return false;
    });
});

function deletePromptYES() {
    currentForm.submit();
}