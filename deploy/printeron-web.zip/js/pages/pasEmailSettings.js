/**
 * Created by bershaa on 12/29/2014.
 */

$(function (){
    showHide($("#emailType").val());
    disableImap();
    disableSmtp();

    $("#emailType").change(function () {
        var emailType = $("#emailType").val();
        showHide(emailType);

        setUpAdvancedView(ADVANCED_VIEW_ENABLED);
    });

    $("#ewsEnableSMTP").change(function(){
        hideSmtp();
    })

    $("#ewsOAuthEnabled").change(function() {
        toggleOAuth();
    })

    $('#imap4EnablePolling').change(function() {
        hideImapPollingSettings();
    })

    $("#imapSslType").change(function () {
        disableImap();
    });

    $("#smtpSslType").change(function () {
        disableSmtp();
    });

    $("#mapiOverrideDefault").click(function () {
        if(this.checked)
            $("#mapiResponseAddress").attr("disabled", false);
        else
            $("#mapiResponseAddress").attr("disabled", true);
    });

    $( "#smtpSslType" ).change(function() {
        if( $('option:selected', this).text() == "None")
            $("#smtpServerPort").val("25");
        else if( $('option:selected', this).text() == "Implicit")
            $("#smtpServerPort").val("465");
        else if( $('option:selected', this).text() == "Explicit")
            $("#smtpServerPort").val("587");
    });

    $( "#imapSslType" ).change(function() {
        if( $('option:selected', this).text() == "None")
            $("#imap4Port").val("143");
        else if( $('option:selected', this).text() == "Implicit")
            $("#imap4Port").val("993");
        else if( $('option:selected', this).text() == "Explicit")
            $("#imap4Port").val("143");
    });
});

function hideSmtp(){
    if ($('#ewsEnableSMTP').prop('checked'))
        $("#smtpServerInformation").show();
    else
        $("#smtpServerInformation").hide();
}

function toggleOAuth(){
    if ($('#ewsOAuthEnabled').prop('checked'))
        $("#ewsOAuthConfigurationSettings").show();
    else
        $("#ewsOAuthConfigurationSettings").hide();
}

function hideImapPollingSettings(){
    if ($('#imap4EnablePolling').prop('checked')) {
        $("#pollingTimeRow").show();
        $("#pollingReconnectRow").show();
    }
    else{
        $("#pollingTimeRow").hide();
        $("#pollingReconnectRow").hide();
    }
}

function disableImap(){
    var imapSslType = $("#imapSslType").val();
    if(imapSslType == "None"){
        $('#imapStrictSsl').addClass('disabled');
        $('#imapStrictSsl').attr('onclick', 'return false;')
    } else {
        $('#imapStrictSsl').removeClass('disabled');
        $('#imapStrictSsl').attr('onclick', '');
    }
}

function disableSmtp(){
    var smtpSslType = $("#smtpSslType").val();
    if(smtpSslType == "None"){
        $('#smtpStrictSsl').addClass('disabled');
        $('#smtpStrictSsl').attr('onclick', 'return false;');
    } else {
        $('#smtpStrictSsl').removeClass('disabled');
        $('#smtpStrictSsl').attr('onclick', '');
    }
}

function showHide(emailType){
    if(emailType == "NONE"){
        $("#smtpServerInformation").hide();
        $("#ewsConfiguration").hide();
        $("#ewsOAuthConfiguration").hide();
        $("#imap4Configuration").hide();
        $("#dominoConfiguration").hide();
        $("#advancedSettings").hide();
    }else if(emailType == "EWS"){
        $("#smtpServerInformation").hide();
        $("#ewsConfiguration").show();
        $("#ewsOAuthConfiguration").show();
        $("#imap4Configuration").hide();
        $("#dominoConfiguration").hide();
        hideSmtp();
        toggleOAuth();
    }else if(emailType == "IMAP4"){
        $("#smtpServerInformation").show();
        $("#ewsConfiguration").hide();
        $("#ewsOAuthConfiguration").hide();
        $("#imap4Configuration").show();
        $("#dominoConfiguration").hide();
        hideImapPollingSettings();
    }else if(emailType == "DOMINO"){
        $("#ewsConfiguration").hide();
        $("#imap4Configuration").hide();
        $("#ewsOAuthConfiguration").hide();
        $("#smtpServerInformation").hide();
        $("#dominoConfiguration").show();
    }
}


function doEwsTest() {

    notifyInfo($("#testEws").val());

    var serviceUrl  = $('#ewsServiceUrl').val();
    var mailboxUserName  = $('#ewsMailboxUserName').val();
    var mailboxPassword  = $('#ewsMailboxPassword').val();
    var listenerPort  = $('#ewsListenerPort').val();
    var responseAddress   = $('#ewsResponseAddress').val();
    var acceptRequestToResponseAddress  = $('#ewsAcceptRequestToResponseAddress').prop('checked');
    var allFields = true;

    /** can not submit an empty serverURL, username, password **/
    if (!serviceUrl) {
        addErrorToField($('#ewsServiceUrl'),$("#emptyField").val());
        allFields = false;
    }
    else{
        $('#ewsServiceUrl').parents(".row").children(".errorMessage").html("");
        $('#ewsServiceUrl').removeClass('error');
    }
    if (!mailboxUserName) {
        addErrorToField( $('#ewsMailboxUserName'),$("#emptyField").val());
        allFields = false;
    }
    else{
        $('#ewsMailboxUserName').parents(".row").children(".errorMessage").html("");
        $('#ewsMailboxUserName').removeClass('error');
    }
    if (!mailboxPassword) {
        addErrorToField($('#ewsMailboxPassword'),$("#emptyField").val());
        $('#ewsMailboxPassword').addClass('error');
        allFields = false;
    }
    else{
        $('#ewsMailboxPassword').parents(".row").children(".errorMessage").html("");
        $('#ewsMailboxPassword').removeClass('error');
    }

    if (allFields) {
        ajax({
            type: "POST",
            url: window.location.pathname + "/testEws",
            data:
            "mailboxUserName=" + mailboxUserName
            + "&mailboxPassword=" + mailboxPassword
            + "&listenerPort=" + listenerPort
            + "&responseAddress=" + responseAddress
            + "&serviceUrl=" + serviceUrl
            + "&acceptRequestToResponseAddress=" + acceptRequestToResponseAddress,
            success: function (response) {
                if(response == "Test Successful") {
                    notifySuccess(response);
                }
                else {
                    notifyError(response);
                }
            },
            error: function (e) {
                notifyError("Error during test");
            }
        });
    }
    else{

       notifyError($('#errorInputFields').val());
       // $("#ewsNotify").notify("Please enter all required fields!", {style: "xButton", className: "error", autoHide: false, clickToHide: false, position: "bottom right", arrowShow: false});
    }

    return false;
}

function doImapTest() {

    notifyInfo($("#testImap").val());

    var imap4IpAddress  = $('#imap4IpAddress').val();
    var imap4Port  = $('#imap4Port').val();
    var imapSslType   = $('#imapSslType').val();
    var imapStrictSsl  = $('#imapStrictSsl').prop('checked');
    var imap4UserName  = $('#imap4UserName').val();
    var imap4Password  = $('#imap4Password').val();
    var imap4ResponseAddress  = $('#imap4ResponseAddress').val();
    var imap4AcceptRequestToResponseAddress  = $('#imap4AcceptRequestToResponseAddress').prop('checked');
    var allFields = true;

    /** can not submit an empty serveraddress, username, password **/
    if (!imap4IpAddress) {
        addErrorToField($('#imap4IpAddress'),$("#emptyField").val());
        allFields = false;
    }
    else{
        $('#imap4IpAddress').parents(".row").children(".errorMessage").html("");
        $('#imap4IpAddress').removeClass('error');
    }
    if (!imap4UserName) {
        addErrorToField($('#imap4UserName'),$("#emptyField").val());
        allFields = false;
    }
    else{
        $('#imap4UserName').parents(".row").children(".errorMessage").html("");
        $('#imap4UserName').removeClass('error');
    }
    if (!imap4Password) {
        addErrorToField( $('#imap4Password'),$("#emptyField").val());
        allFields = false;
    }
    else{
        $('#imap4Password').parents(".row").children(".errorMessage").html("");
        $('#imap4Password').removeClass('error');
    }

    if (allFields) {
        ajax({
            type: "POST",
            url: window.location.pathname + "/testImap",
            data:
            "imap4IpAddress=" + imap4IpAddress
            + "&imap4Port=" + imap4Port
            + "&imapSslType=" + imapSslType
            + "&imapStrictSsl=" + imapStrictSsl
            + "&imap4UserName=" + imap4UserName
            + "&imap4Password=" + imap4Password
            + "&imap4ResponseAddress=" + imap4ResponseAddress
            + "&imap4AcceptRequestToResponseAddress=" + imap4AcceptRequestToResponseAddress,
            success: function (response) {
                if(response == "Test Successful") {
                    notifySuccess(response);
                }
                else {
                    notifyError(response);
                }
            },
            error: function (e) {
                notifyError("Error during test");
            }
        });
    }
    else{
        notifyError($('#errorInputFields').val());
        //$("#imapNotify").notify("Please enter all required fields!", {style: "xButton", className: "error", autoHide: false, clickToHide: false, position: "bottom right", arrowShow: false});
    }
    return false;
}


function doSmtpTest() {

    notifyInfo($("#testSmtp").val());

    var smtpServerAddress  = $('#smtpServerAddress').val();
    var smtpServerPort  = $('#smtpServerPort').val();
    var smtpSslType  = $('#smtpSslType').val();
    var smtpStrictSsl   = $('#smtpStrictSsl').prop('checked');
    var smtpUserName  = $('#smtpUserName').val();
    var smtpUserPassword  = $('#smtpUserPassword').val();
    var smtpSenderName  = $('#smtpSenderName').val();
    var smtpSenderAddress  = $('#smtpSenderAddress').val();
    var smtpReplyToAddress  = $('#smtpReplyToAddress').val();
    var allFields = true;

    /** can not submit an empty smtpServer **/
    if (!smtpServerAddress) {
        addErrorToField($('#smtpServerAddress'),$("#emptyField").val());
        allFields = false;
    }
    else{
        $('#smtpServerAddress').parents(".row").children(".errorMessage").html("");
        $('#smtpServerAddress').removeClass('error');
    }

    if (allFields) {
        ajax({
            type: "POST",
            url: window.location.pathname + "/testSmtp",
            data:
            "smtpServerAddress=" + smtpServerAddress
            + "&smtpServerPort=" + smtpServerPort
            + "&smtpSslType=" + smtpSslType
            + "&smtpStrictSsl=" + smtpStrictSsl
            + "&smtpUserName=" + smtpUserName
            + "&smtpUserPassword=" + smtpUserPassword
            + "&smtpSenderName=" + smtpSenderName
            + "&smtpSenderAddress=" + smtpSenderAddress
            + "&smtpReplyToAddress=" + smtpReplyToAddress
            ,
            success: function (response) {
                if(response == "Test Successful") {
                    notifySuccess(response);
                }
                else {
                    notifyError(response);
                }
            },
            error: function (e) {
                notifyError("Error during test");
            }
        });
    }
    else{
        notifyError($('#errorInputFields').val());
        //$("#smtpNotify").notify("Please enter all required fields!", {style: "xButton", className: "error", autoHide: false, clickToHide: false, position: "bottom right", arrowShow: false});
    }
    return false;
}

function doSyncDomino() {
    notifyInfo($("#syncingDomino").val());

    var dominoServiceUrl   = $('#dominoServiceUrl').val();
    var dominoMailboxPassword  = $('#dominoMailboxPassword').val();
    var dominoResponseAddress  = $('#dominoResponseAddress').val();
    var dominoAcceptRequestToResponseAddress  = $('#dominoAcceptRequestToResponseAddress').prop('checked');
    var dominoPrinterName  = $('#dominoPrinterName').val();
    var dominoLotusNotesIniPath  = $('#dominoLotusNotesIniPath').val();
    var allFields = true;

    /** can not submit empty password or ini file for domino **/
    if (!dominoMailboxPassword) {
        addErrorToField($('#dominoMailboxPassword'),$("#emptyField").val());
        allFields = false;
    }
    else{
        $('#dominoMailboxPassword').parents(".row").children(".errorMessage").html("");
        $('#dominoMailboxPassword').removeClass('error');
    }

    if (!dominoLotusNotesIniPath) {
        addErrorToField($('#dominoLotusNotesIniPath'),$("#emptyField").val());
        allFields = false;
    }
    else{
        $('#dominoLotusNotesIniPath').parents(".row").children(".errorMessage").html("");
        $('#dominoLotusNotesIniPath').removeClass('error');
    }

    if(allFields) {
        ajax({
            type: "POST",
            url: window.location.pathname + "/syncDomino",
            data:
            "dominoServiceUrl=" + dominoServiceUrl
            + "&dominoMailboxPassword=" + dominoMailboxPassword
            + "&dominoResponseAddress=" + dominoResponseAddress
            + "&dominoAcceptRequestToResponseAddress=" + dominoAcceptRequestToResponseAddress
            + "&dominoPrinterName=" + dominoPrinterName
            + "&dominoLotusNotesIniPath=" + dominoLotusNotesIniPath,
            success: function (response) {
                if(response == "Sync Successful") {
                    notifySuccess(response);
                }
                else {
                    notifyError(response);
                }
            },
            error: function (e) {
                notifyError("Error during test");
            }
        });
    }
    else{
        notifyError($('#errorInputFields').val());
        //$("#dominoNotify").notify("Please enter all required fields!", {style: "xButton", className: "error", autoHide: false, clickToHide: false, position: "bottom right", arrowShow: false});
    }

    return false;
}