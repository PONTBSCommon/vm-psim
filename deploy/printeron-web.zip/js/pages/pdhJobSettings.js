var disableInputsLookup = {
    'enableAbandonedJobPurge1' : ['#abandonedJobPurgeInterval'],
    'enableMaximumJobSizeLimit1' : ["#maximumJobSizeLimit"]
};

function disableInputs (element) {
    var inputsToDisable = disableInputsLookup[element.attr('id')],
        input;
    for (input in inputsToDisable) {
        $(inputsToDisable[input]).prop('disabled', !element.is(':checked'));
    }
}

$(document).on('click', '.disables-inputs', function () {disableInputs($(this))});

$(document).ready( function () {
    for (inputs in disableInputsLookup) {
        disableInputs($('#' + inputs));
    }
});