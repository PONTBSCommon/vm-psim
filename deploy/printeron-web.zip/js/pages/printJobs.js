/**
 * Created by bershaa on 10/2/2015.
 */

$(document).ready( function () {

    dtErrorMode("throw");

    // Initialize datatable
    dtLoad('#queueMonitorTable', {

        fnRowCallback: function(nRow, aData, iDisplayIndex) { return decorateRow(nRow, aData); },
        tableTools: { sRowSelect: "multi" },
        processing: true,
        serverSide: true,
        selectableRows: true,
        multiSelectRows: true,
        ajax: {url: window.location.pathname + '/ajax/'},
        columns: [
            { data: "printeronID"},
            { data: "jobId" },
            { data: "documentName" },
            { data: "fileSize" },
            { data: "timeReceived" },
            { data: "printerName", className: "printerName" },
            { data: "userEmail" },
            { data: "statusText" },
            { data: "pages" },
            { data: "PTID" }
        ],
        order: [[ 4, "desc" ]]
    });

    $('#queueMonitorTable').on( 'dt.selection.updated', enableDisableButtons );
} );

function enableDisableButtons () {
    ajax({
        url: CONTEXT + "/printers/jobs/buttonState",
        method: "GET",
        data: dtGetTableParamsForAjax("#queueMonitorTable"),
        success: function (data) {
            if(data['printable'])
                $("#printButton").removeAttr("disabled");
            else
                $("#printButton").attr("disabled", true);

            if(data['deleteable'])
                $("#deleteButton").removeAttr("disabled");
            else
                $("#deleteButton").attr("disabled", true);

            if(data['pauseable'])
                $("#pauseButton").removeAttr("disabled");
            else
                $("#pauseButton").attr("disabled", true);
        }
    });
}

function decorateRow(row, data) {

    // Truncate all long columns
    $(row).children().each(function(index, td){
        if ($(td).html().length > 20) {
            if($(td).html().indexOf("glyphicons") < 0) {
                var truncated = $(td).html().substring(0, 20);
                $(td).html(truncated + "<span title=\"" + $(td).html() + "\" class='more-bottom glyphicons glyphicons-more'></span>");
            }
        }
    });

    var date = new Date(0);
    date.setUTCMilliseconds(data['timeReceived']);

    $("td:eq(2)", row).html(date.toLocaleString());

    // Update printer name field to a link
    var printerName = $("td.printerName", row);
    printerName.html("<span>" + printerName.html() + "</span>");

    return row;
}

function refresh(showSpinner){

    if(showSpinner) {
        startSpinnerOnButton("#refreshButton")
    }

    var table = $('#queueMonitorTable');
    dtUnloadUUID(table);
    dtRedraw(false, table);

    if(showSpinner) {
        stopSpinnerOnButton("#refreshButton")
    }

    table.one("dt.ajax.complete", enableDisableButtons);
}

function printJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids = "";
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].printable || data[i].reprintable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : window.location.pathname + "/print",
        data : "jobIds=" + ids,
        beforeSend: function() {
            startSpinnerOnButton("#printButton");
        },
        success : function() {
            stopSpinnerOnButton("#printButton");
            refresh(false);
        },
        error : function(e) {
            stopSpinnerOnButton("#printButton");
        }
    });
}

function deleteJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids = "";
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].deleteable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : window.location.pathname + "/delete",
        data : "jobIds=" + ids,
        beforeSend: function() {
            startSpinnerOnButton("#deleteButton");
        },
        success : function() {
            stopSpinnerOnButton("#deleteButton");
            refresh(false);
        },
        error : function(e) {
            stopSpinnerOnButton("#deleteButton");
        }
    });
}

function pauseJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids = "";
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].pauseable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : window.location.pathname + "/pause",
        data : "jobIds=" + ids,
        beforeSend: function() {
            startSpinnerOnButton("#pauseButton");
        },
        success : function() {
            stopSpinnerOnButton("#pauseButton");
            refresh(false);
        },
        error : function(e) {
            stopSpinnerOnButton("#pauseButton");
        }
    });
}