var isDelete = false;

function setFormAction(deleteaction)
{
    $("#listenerForm").attr('action', deleteaction);
    isDelete = true;
}

var currentForm;

$(function() {
    enablePort();
    enableFAPICheckbox();
    enableAutomaticPolling();


    // HP Roam config should only be visible if HP Roam is Enabled
    if ($('#hpRoamEnabled').val().toUpperCase() != "TRUE") {
        $('#hpRoamConfig').hide();
    }


    $('form').submit(function(e) {
        currentForm = this;
        if(isDelete)
            $('#dialog-confirm').modal('show');
        else
            currentForm.submit();
        return false;
    });
    
    var enabled = $("#proxyModel\\.enableProxy").prop('checked');

    $("#proxyDiv :input").attr("disabled", !enabled);
        

    $('#proxyModel\\.enableProxy').click(function() {
        $("#proxyDiv :input").attr("disabled", enabled);
        enabled = !enabled;
    });

});

function dialogConfirmYES()
{
    $("#dialog-confirm").modal("hide");
    currentForm.submit();
}

function enableFAPICheckbox()
{

    var isChecked = $("#additional1PortEnabled").is(':checked');

    if(!isChecked)  //if the first port is disabled check second port
        isChecked = $("#additional2PortEnabled").is(':checked');

    $("#enableFApiOnPorts").prop("disabled", !isChecked);
}

function enableAutomaticPolling()
{
    var isChecked = $("#automaticPollingEnabled").is(':checked');

    if (isChecked)
        $('#pollingRate').removeAttr('disabled');
    else
        $('#pollingRate').attr('disabled', 'disabled');

}

function enablePort()
{
    var isChecked = $("#defaultIPPPortEnabled").is(':checked');

    if (isChecked)
    {
        $('#enableSSLLocalListener1').removeAttr('disabled');
        $('#defaultIPPPort').removeAttr('disabled');
    }
    else
    {
        $('#enableSSLLocalListener1').attr('disabled', 'disabled');
        $('#defaultIPPPort').attr('disabled', 'disabled');
    }

    isChecked = $("#additional1PortEnabled").is(':checked');

    if (isChecked)
    {
        $('#enableSSLLocalListener2').removeAttr('disabled');
        $('#additional1Port').removeAttr('disabled');
    }
    else
    {
        $('#enableSSLLocalListener2').attr('disabled', 'disabled');
        $('#additional1Port').attr('disabled', 'disabled');
    }

    isChecked = $("#additional2PortEnabled").is(':checked');

    if(isChecked)
    {
        $('#enableSSLLocalListener3').removeAttr('disabled');
        $('#additional2Port').removeAttr('disabled');
    }
    else
    {
        $('#enableSSLLocalListener3').attr('disabled', 'disabled');
        $('#additional2Port').attr('disabled', 'disabled');
    }

    isChecked = $("#rqmEnabled").is(':checked');

    if(isChecked)
    {
        $('#rqmSslEnabled').removeAttr('disabled');
        $('#rqmPort').removeAttr('disabled');
    }
    else
    {
        $('#rqmSslEnabled').attr('disabled', 'disabled');
        $('#rqmPort').attr('disabled', 'disabled');
    }

    isChecked = $("#rqmBsiEnabled").is(':checked');

    if(isChecked)
    {
        $('#rqmBsiSslEnabled').removeAttr('disabled');
        $('#bsiPort').removeAttr('disabled');
    }
    else
    {
        $('#rqmBsiSslEnabled').attr('disabled', 'disabled');
        $('#bsiPort').attr('disabled', 'disabled');
    }
}

function doAjaxPost() {

    $("#proxyTestResult").val("Testing...");
    $("#proxyTestResultSsl").val("Testing...");

    var proxyUsername = $('#proxyModel\\.proxyUser').val();
    var proxyPort = $('#proxyModel\\.proxyPort').val();
    var proxyUrl = $('#proxyModel\\.proxyUrl').val();
    var proxyPassword = $('#proxyModel\\.proxyPassword').val();

    var url = window.location.pathname.replace(/listeners(\/)?/, "proxySettings/testProxy");

    ajax({
        type : "POST",
        url : url,
        data : "proxyUrl=" + proxyUrl + "&proxyPort=" + proxyPort + "&proxyUsername="
        + proxyUsername + "&proxyPassword=" + proxyPassword,
        dataType:"json",
        success : function(response) {
            $("#proxyTestResult").val(response.nonssl);
            $("#proxyTestResultSsl").val(response.ssl);
        },
        error : function(e) {

            // TODO: localize?
            $("#proxyTestResult").val("Test Failed");
            $("#proxyTestResultSsl").val("Test Failed");
        }
    });
}
