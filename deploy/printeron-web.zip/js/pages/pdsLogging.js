$(function (){
    disablePanel();
});

function disablePanel(){
    if($('#enablePrintLogging').is(':checked')) {
        $('#loggingDirPanel :input').removeAttr('disabled');
    }else{
        $('#loggingDirPanel :input').attr('disabled', true);
    }

    if($('#enablePMSNotification').is(':checked')) {
        $('#pmsPanel :input').removeAttr('disabled');
    }else{
        $('#pmsPanel :input').attr('disabled', true);
    }
}