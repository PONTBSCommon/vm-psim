var removeLanguageSelect = $("#removeLanguageSelect-wrapper > select");
var removeLanguageWrapper = $("#removeLanguage-wrapper");
var addLanguageSelect = $("#addLanguageSelect-wrapper > select");
var addLanguageWrapper = $("#addLanguage-wrapper");
var languageSelect = $("#defaultLocale");
var approvalCheckedAtStart;

function toggleLanguageSelect ()
{
    if (removeLanguageSelect.children("option").length <=1)
    {
        removeLanguageWrapper.hide();
    }
    else
    {
        removeLanguageWrapper.show();
    }

    if (addLanguageSelect.children("option").length == 0)
    {
        addLanguageWrapper.hide();
    }
    else
    {
        addLanguageWrapper.show();
    }
}

$(document).ready(function () {

    approvalCheckedAtStart = $("#jobApproval").is(':checked');

    toggleLanguageSelect();

    // Prepare the ajax form
    useAjaxForForm("#webPrintForm", {

        beforeSend: function(xhr) {
            startSpinnerOnButton("#confirmationButton");
        },
        success: function() {
            notifySuccess($("#settingsSaved").val());
            approvalCheckedAtStart = $("#jobApproval").is(':checked');
        },
        error: function() {
            notifyError($("#settingsError").val())
        },
        complete: function() {
            stopSpinnerOnButton("#confirmationButton");
            $("#confirmationDialog").modal("hide");
        }
    });

    $("#manageLanguages").on("click", function () {
        $("#manageLanguagesModal").modal("show");
    });

    $("#applySettings").on("click", function () {

        if($("#jobApproval").is(':checked') != approvalCheckedAtStart) {
            $("#confirmationDialog").modal("show");
            return false;
        }
    });

    $("#confirmationButton").on("click", function () {
        $("#webPrintForm").submit();
    });

    $("#addLanguagesForm").on("submit", function () {
        $("#addLanguageButton").hide();
        $("#loadingAdd").show();

        ajax({
            url: $(this).attr("action"),
            context: document.body,
            type: 'post',
            data: $(this).serialize(),
            success: function () {
                notifySuccess($("#settingsSaved").val());
                $("#addLanguageButton").show();
                $("#loadingAdd").hide();
                var text = addLanguageSelect.find("option[value='"+addLanguageSelect.val()+"']").html();
                removeLanguageSelect.append("<option value='"+addLanguageSelect.val()+"'>"+text+"</option>");
                languageSelect.append("<option value='"+addLanguageSelect.val()+"'>"+text+"</option>");
                addLanguageSelect.find("option[value='"+addLanguageSelect.val()+"']").remove();
                toggleLanguageSelect();
            },
            error: function (error) {
                notifyError(error.responseText);
                $("#addLanguageButton").show();
                $("#loadingAdd").hide();
            }
        });

        return false;
    });

    $("#removeLanguagesForm").on("submit", function () {
        $("#removeLanguageButton").hide();
        $("#loadingRemove").show();

        ajax({
            url: $(this).attr("action"),
            context: document.body,
            type: 'post',
            data: $(this).serialize(),
            success: function () {
                notifySuccess($("#settingsSaved").val());
                $("#removeLanguageButton").show();
                $("#loadingRemove").hide();
                var text = removeLanguageSelect.find("option[value='"+removeLanguageSelect.val()+"']").html();
                languageSelect.find("option[value='"+removeLanguageSelect.val()+"']").remove();
                addLanguageSelect.append("<option value='"+removeLanguageSelect.val()+"'>"+text+"</option>");
                removeLanguageSelect.find("option[value='"+removeLanguageSelect.val()+"']").remove();
                toggleLanguageSelect();
            },
            error: function (error) {
                notifyError(error.responseText);
                $("#removeLanguageButton").show();
                $("#loadingRemove").hide();
            }
        });

        return false;
    });
});