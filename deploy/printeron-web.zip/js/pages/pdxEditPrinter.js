$(function (){disablePanel();});

function disablePanel(){
    if($('#enableReprints').is(':checked')) {
        $('#reprintInterval').removeAttr('disabled');
        $('#maxReprints').removeAttr('disabled');
    }else{
        $('#reprintInterval').attr('disabled', true);
        $('#maxReprints').attr('disabled', true);
    }
}

function showMappingMessage(isNetwork){
    if(isNetwork) {
        notifyInfo($("#fetchingPrintServersNetwork").val());
    }
    else {
        notifyInfo($("#fetchingPrintServers").val());
    }
}