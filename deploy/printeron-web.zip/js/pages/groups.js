/**
 * Created by szawlom on 11/18/2016.
 */

$(document).ready(function () {

    useAjaxForForm($("#createGroupForm"), {
        beforeSend: function () {
           startSpinnerOnButton($("#addGroupConfirm"));
        },
        success: function (data) {
            dtUnload("#groups-table");
            loadGroupsTable();
            $("#createGroupDialog").modal("hide");
            applyRulesToGroupRow();
            notifySuccess(data);
        },
        complete: function () {
            stopSpinnerOnButton($("#addGroupConfirm"));
        }
    });

    useAjaxForForm($("#editGroupForm"), {
        beforeSend: function () {
            startSpinnerOnButton($("#editGroupConfirm"));
        },
        success: function (data) {
            dtUnload("#groups-table");
            loadGroupsTable();
            $("#editGroupDialog").modal("hide");
            applyRulesToGroupRow();
            notifySuccess(data);
        },
        complete: function () {
            stopSpinnerOnButton($("#editGroupConfirm"));
        }
    });

    if (!isPonUserEnabled){
        $("#createGroup").prop("disabled", true);
    }

    $("#addUser").prop("disabled", true);

    $("#groups-table").one("draw.dt", function () {
        applyRulesToGroupRow();
    });

    loadGroupsTable();

    $("#createGroup").click(function(){
        $("#name").val("");
        $("#description").val("");
        $("#createGroupDialog").modal("show");
    });

    $("#createGroupDialogClose").click(function () {
        $("#createGroupDialog").modal("hide");
    });

    $("#editGroup").click(function(){
        var selected = $("#groups-table tr.selected");
        $("#idEdit").val(selected.data("id"));
        $("#nameEdit").val(selected.data("name"));
        $("#descriptionEdit").val(selected.data("description"));
        $("#typeEdit").val(selected.data("type"));
        $("#editGroupDialog").modal("show");
    });

    $("#editGroupDialogClose").click(function () {
        $("#editGroupDialog").modal("hide");
    });

    $("#addUser").click(function(){
        var html = "";
        if ($("#group-users-table").data('current').length > 40) {
            html += $("#group-users-table").data('current').substring(0, 40) + "&nbsp;<span title='" + $("#group-users-table").data('current') + "' class='more-bottom glyphicons glyphicons-more' color='red'></span>";
        }
        else {
            html += $("#group-users-table").data('current');
        }
        $("#allUsersHeader").html($("#allUsersHeader").data('label') + " " + html);
        $("#allUsersDialog").modal("show");
        dtUnload("#users-table");
        dtLoad("#users-table", {
            fnRowCallback: function( nRow, aData ) { return decorateUserRow(nRow, aData, 20); },
            ajax: {
                url: CONTEXT + "/users/groups/" + $("#group-users-table").data('current-id') + "/users/all"
            },
            serverSide: true,
            columns: [
                {data: "userName", "class" : "userName"},
                {data: "firstName", "class" : "firstName"},
                {data: "lastName", "class" : "lastName"},
                {data: "roles", "class": "roles"},
                {data: "state", "class": "state"}
            ],
            selectableRows: true,
            multiSelectRows: true
        });
    });

    $("#allUserDialogClose").click(function () {
        $("#allUsersDialog").modal("hide");
    });

    $("#group-users-table").one("draw.dt", function () {
        $(this).on("dt.selection.updated", function () {

            if ($("#usersGroupHeader").data("deleted") == "true" || !isPonUserEnabled){
                return;
            }

            var indexes = dtGetSelectedRowIndexes("#group-users-table");

            if (indexes.length > 0) {
                $("#removeUsers").prop("disabled", false);
            }
            else {
                $("#removeUsers").prop("disabled", true);
            }
        });
    });

    $("#groups-table").one("draw.dt", function () {
        $(this).on("dt.selection.updated", function () {
            var indexes = dtGetSelectedRowIndexes("#groups-table");

            if(isPonUserEnabled){
                $("#editGroup").prop("disabled", false);
                $("#deleteGroups").prop("disabled", false);
            }
            else {
                $("#editGroup").prop("disabled", true);
                $("#deleteGroups").prop("disabled", true);
                $("#addUser").prop("disabled", true);
                return;
            }

            if (indexes.length <= 0) {
                $("#deleteUsers").prop("disabled", true);
            }
            else{
                // if we have something selected we want to enable this just in case it was disabled before
                $("#addUser").prop("disabled", false);
            }

            if (indexes.length != 1){
                $("#editGroup").prop("disabled", true);
            }

            $("#removeUsers").prop("disabled", true);
            $("#usersGroupHeader").data("deleted","false");
        });
    });

    $("#confirmDelete").click(function () {
        ajax({
            url: CONTEXT + "/users/groups/delete",
            method: "POST",
            data: dtGetTableParamsForAjax("#groups-table"),
            beforeSend: function () {
                startSpinnerOnButton($("#confirmDelete"));
            },
            success: function (data) {

            },
            complete: function () {
                stopSpinnerOnButton($("#confirmDelete"));
                dtUnload("#groups-table");
                loadGroupsTable();
                $("#addUser").prop("disabled", true);
                $("#editGroup").prop("disabled",true);
                applyRulesToGroupRow();
                $("#usersGroupHeader").text($("#usersGroupHeader").text() + " ***DELETED***");
                $("#usersGroupHeader").data("deleted","true");
                $("#removeUsers").prop("disabled", true);
                $("#deleteGroups").prop("disabled", true);
                $("#confirmDeleteModal").hide();
                notifySuccess(data);
            },
            error: function (xhr) {
               // notifyError(xhr.responseText);
            }
        });
    });

    $("#addUserConfirm").click(function () {
        ajax({
            url: CONTEXT + "/users/groups/" + $("#group-users-table").data('current-id') + "/users/add",
            method: "POST",
            data: dtGetTableParamsForAjax("#users-table"),
            beforeSend: function () {
                startSpinnerOnButton($("#addUserConfirm"));
            },
            success: function (data) {

            },
            complete: function () {
                stopSpinnerOnButton($("#addUserConfirm"));
                dtUnload("#group-users-table");
                loadUsersTable($("#group-users-table").data('current-id'));
                $("#allUsersDialog").modal("hide");
                notifySuccess(data);
            },
            error: function (xhr) {
                //notifyError(xhr.responseText);
            }

        });
    });

    $("#removeUsers").click(function () {
        ajax({
            url: CONTEXT + "/users/groups/" + $("#group-users-table").data('current-id') + "/users/remove",
            method: "POST",
            data: dtGetTableParamsForAjax("#group-users-table"),
            beforeSend: function () {
                startSpinnerOnButton($("#removeUsers"));
            },
            success: function (data) {
            },
            complete: function () {
                stopSpinnerOnButton($("#removeUsers"));
                var id = $("#group-users-table").data('current-id');
                dtUnload("#group-users-table");
                loadUsersTable(id);
                notifySuccess(data);
            },
            error: function (xhr) {
               // notifyError(xhr.responseText);
            }
        });
    });
});

function loadGroupsTable(){
    dtLoad("#groups-table", {
        fnRowCallback: function( nRow, aData ) { return decorateGroupRow(nRow, aData); },
        ajax: {
            url: CONTEXT + "/users/grouplist"

        },
        serverSide: true,
        columns: [
            {data: "name", "class":"name"}
        ],
        selectableRows: true,
        multiSelectRows: false
    });
};

function loadUsersTable(group){
    dtLoad("#group-users-table", {
         fnRowCallback: function( nRow, aData ) { return decorateUserRow(nRow, aData,10); },
        ajax: {
            url: CONTEXT + "/users/groups/" + group + "/users"
        },
        serverSide: true,
        columns: [
            {data: "userName", "class" : "userName"},
            {data: "firstName", "class" : "firstName"},
            {data: "lastName", "class" : "lastName"},
            {data: "state", "class": "state"},
            {data: "id"}
        ],
        selectableRows: true,
        multiSelectRows: true
    });
};

function decorateGroupRow(nRow, aData){

    $(nRow).data("name",aData['name']);
    $(nRow).data("id",aData['id']);
    $(nRow).data("description",aData['description']);
    $(nRow).data("type",aData['type']);

    decorateState($("td.state", nRow), aData['state']);
    decorateLongString($("td.name", nRow), aData['name'], 60);
}

function decorateUserRow (nRow, aData, maxDisplayLength) {
    decorateState($("td.state", nRow), aData['state']);
    decorateLongString($("td.userName", nRow), aData['userName'], maxDisplayLength);
    decorateLongString($("td.firstName", nRow), aData['firstName'], maxDisplayLength);
    decorateLongString($("td.lastName", nRow), aData['lastName'], maxDisplayLength);

}

function decorateState (column, state) {
    column.html("<div class='badge userAccountState-" + state + "'>" + $("#userAccountState-" + state).val() + "</div>");
}

function decorateLongString (column, attribute, length) {
    var html = "";
    if (attribute.length > length) {
        html += attribute.substring(0,length) + "&nbsp;<span title='" + attribute + "' class='more-bottom glyphicons glyphicons-more'></span>";
    }
    else {
        html += attribute;
    }

    column.html(html);
}

function applyRulesToGroupRow(){

    if (!isPonUserEnabled) {
        $("#selectLabel").text("Not Available");
        return;
    }


    var table = $('#groups-table').DataTable();

    $('#groups-table tbody').off('click', 'tr');

    $('#groups-table tbody').on('click', 'tr', function () {
        var data = table.row( this ).data();
        var html = "";
        if (data.name.length > 40) {
            html += data.name.substring(0,40) + "&nbsp;<span title='" + data.name + "' class='more-bottom glyphicons glyphicons-more'></span>";
        }
        else {
            html += data.name;
        }
        $("#usersGroupHeader").html($("#usersGroupHeader").data('label') + " " + html);
        $("#group-users-table").data('current', data.name);
        $("#group-users-table").data('current-id', data.id);
        dtUnload("#group-users-table");

        $("#selectLabel").hide();

        loadUsersTable(data.id);
    } );
}