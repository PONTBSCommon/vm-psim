function getDepartments ()
{
    var departmentsWrapper = $("#departmentsWrapper");
    var departmentsSpinner = $("#departmentsSpinner");

    departmentsSpinner.show();
    departmentsWrapper.hide();
    startSpinner("#departmentsSpinner");
    $("#manageDepartmentsDialog").modal("show");

    ajax({
        url: CONTEXT + "/departments",
        success: function (html) {
            departmentsWrapper.html(html);
            dtLoad("#departmentsTable");

            bindDepartmentEvents();

            departmentsSpinner.hide();
            departmentsWrapper.show();
            stopSpinner("#departmentsSpinner");
        }
    })
}

function bindDepartmentEvents() {
    dtQueryRows(".editDepartment-save", "#departmentsTable").click(function () {saveDepartment($(this))});
    dtQueryRows(".deleteDepartment", "#departmentsTable").click(function () {deleteDepartment($(this))});
    dtQueryRows(".editDepartment-edit", "#departmentsTable").click(function () {editDepartment($(this))});
    dtQueryRows(".editDepartment-cancel", "#departmentsTable").click(function () {cancelEditDepartment($(this))});
    dtQueryRows(".linkPrinterDepartments", "#departmentsTable").click(function () {getLinkedDepartmentPrinters($(this))});
}

function cancelEditDepartment(elem) {
    var row = elem.parents("tr");
    var name = row.find(".editDepartment-display-name").html();

    row.find(".editDepartment-display").show();
    row.find(".editDepartment").hide();
    row.find(".editDepartment-name").val(name);
}

function editDepartment(elem) {
    var row = elem.parents("tr");
    row.find(".editDepartment-display").hide();
    row.find(".editDepartment").show();
}

function saveDepartment(elem) {
    var row = elem.parents("tr");
    var name = row.find(".editDepartment-name").val();
    var id = row.find(".departmentId").val();

    startSpinnerOnButton(elem);

    ajax({
        url: CONTEXT + "/department/edit",
        method: "POST",
        data: {
            "id" : id,
            "name" : name
        },
        success: function (data) {
            notifySuccess(data);

            row.find(".editDepartment-display-name").html(name);
            row.find(".editDepartment-display").show();
            row.find(".editDepartment").hide();

            stopSpinnerOnButton(elem);
        },
        error : function (xhr) {

            // Copy code from helper.ajax.js, we need to override some logic
            if(xhr.status == 400) {

                var errors = JSON.parse(xhr.responseText);

                for (var error in errors) {
                    var target = row.find("input[name='" + errors[error].field + "']");

                    if (!target.length) {
                        target = $("#" + errors[error].field);
                    }

                    $(target).addClass("error");
                    var errorTarget = row.find(".errorMessage");
                    errorTarget.html("<span class='error-tooltip' title='" + errors[error].error + "'><span class='glyphicons glyphicons-circle-exclamation-mark'></span></span>");
                }
            }

            stopSpinnerOnButton(elem);
        }
    });
}

function deleteDepartment(elem) {
    var row = elem.parents("tr");
    var name = row.find(".editDepartment-name").val();
    var id = row.find(".departmentId").val();

    startSpinnerOnButton(elem);

    ajax({
        url: CONTEXT + "/department/delete",
        method: "POST",
        data: {
            "id" : id,
            "name" : name
        },
        success: function (data) {
            notifySuccess(data);
            dtRemoveRow(row, "#departmentsTable");
            dtRedraw(false, "#departmentsTable");
        },
        error : function (xhr) {
            defaultErrorFunction(xhr);
            stopSpinnerOnButton(elem);
        }
    });
}

function getLinkedDepartmentPrinters (elem) {
    var row = elem.parents("tr");
    var id = row.find(".departmentId").val();
    var name = row.find(".editDepartment-display-name").html();

    $("#linkDepartments-title").html($("#linkDepartments-title-stub").val().replace("%1", name));

    clearLinkedDepartments();
    clearLinkedDepartmentsSection();

    $("#manageDepartmentsDialog").modal("hide");
    $("#departments-linkPrintersDialog").modal("show");

    getDepartmentLinkedPrinters(id);
}

function getDepartmentLinkedPrinters (department) {
    startSpinnerOnLinkedDepartmentPrinters();
    ajax({
        url: CONTEXT + "/departments/link",
        data : {"department" : department},
        method: "GET",
        success: function (data) {
            //clearLinkedDepartments();
            $("#linkedDepartmentsWrapper").html(data);

            fillLinkedDepartments(department);

            useAjaxForForm("#departments-linkPrintersForm", {
                beforeSend: function (xhr) {
                    startSpinnerOnButton("#departments-linkPrintersSubmit");
                },
                success: function (resp) {
                    if (resp != null && resp != "") {
                        notifySuccess(resp);
                    }

                    $("#departments-linkPrintersDialog").modal("hide");
                    getDepartments();
                },
                complete: function() {
                    stopSpinnerOnButton("#departments-linkPrintersSubmit");
                }
            });
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
        }
    })
}

function fillLinkedDepartments (department) {

    linkedDataTables({
        "#departments-availablePrinters":{
            ajax: {
                url: CONTEXT + "/departments/link/available",
                complete: stopSpinnerOnLinkedDepartmentPrinters
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ],
            "fnServerParams": function ( aoData ) {
                aoData = $.extend(true, aoData, {
                    "department": department
                });
            }
        },
        "#departments-linkedPrinters":{
            ajax: {
                url: CONTEXT + "/departments/link/linked",
                complete: stopSpinnerOnLinkedDepartmentPrinters
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ],
            form: "#departments-linkPrintersForm",
            "fnServerParams": function ( aoData ) {
                aoData = $.extend(true, aoData, {
                    "department": department
                });
            }
        }
    });
}

function startSpinnerOnLinkedDepartmentPrinters () {
    $("#departments-linkPrintersSubmit").attr("disabled", true);
    $("#linkedDepartmentsWrapper").hide();
    $("#linkedDepartmentsSpinner").show();
    startSpinner("#linkedDepartmentsSpinner");
}

function stopSpinnerOnLinkedDepartmentPrinters () {
    $("#departments-linkPrintersSubmit").attr("disabled", false);
    stopSpinner("#linkedDepartmentsSpinner");
    $("#linkedDepartmentsSpinner").hide();
    $("#linkedDepartmentsWrapper").show();
}

function clearLinkedDepartmentsSection () {
    $("#linkedDepartmentsWrapper").html("");
}

function clearLinkedDepartments () {
    dtDestroy("#departments-availablePrinters");
    dtDestroy("#departments-linkedPrinters");
}