var hostPort = $("#hostPort");
var useDefaultPort = $("#useDefaultPort");

$(document).ready(function () {
    if(hostPort.val() == 443) {
        useDefaultPort.prop("checked", true);
    }

    useDefaultPort.click(function () {
        if ($(this).is(":checked")) {
            hostPort.val("443");
        }
    });

    hostPort.change(function () {
        if ($(this).val() == 443) {
            useDefaultPort.prop("checked", true);
        }
        else {
            useDefaultPort.prop("checked", false);
        }
    })
});

$(function (){
    $('input.defaultListener').on('change', function () {
        $('input.defaultListener').not(this).prop('checked', false);
    });

    disablePanelRemoteListener();
    disablePanelNetworkGateway();
    disablePanelCheckJobs();
    disablePanelClientNotification();
});



function onChangeAuthScheme(){
    if($("#authenticationScheme").val() == "Standard")
    {
        $("#password").prop('disabled', false);
    }
    else if($("#authenticationScheme").val() == "Enhanced")
    {
        $("#password").prop('disabled', true);
    }
}

function disablePanelRemoteListener(){
    if($('#enabledRemoteListener').is(':checked')) {
        $('#remoteListenerPanelBody :input').removeAttr('disabled');
    }else{
        $('#remoteListenerPanelBody :input').attr('disabled', true);
    }
}

function disablePanelNetworkGateway(){
    if($('#enableNetworkGateway').is(':checked')) {
        $('#networkGatewayPanel :input').removeAttr('disabled');
    }else{
        $('#networkGatewayPanel :input').attr('disabled', true);
    }
}

function disablePanelCheckJobs(){
    if($('#checkJobsEnabled').is(':checked')) {
        $('#checkJobsPanel :input').removeAttr('disabled');
    }else{
        $('#checkJobsPanel :input').attr('disabled', true);
    }
}

function disablePanelClientNotification(){
    if($('#clientNotificationEnabled').is(':checked')) {
        $('#clientNotificationPanel :input').removeAttr('disabled');
    }else{
        $('#clientNotificationPanel :input').attr('disabled', true);
    }
}


function testRemoteListener() {

    notifyInfo($("#status-remote-listener-test").val());

    var hostAddress = $('#hostAddress').val();
    var hostPort = $('#hostPort').val();
    var useSsl = $('#useSsl').is(':checked');
    var password = $('#password').val();
    var authentication = $('#authenticationScheme').val();
    var useNetworkGateway = $('#enableNetworkGateway').prop('checked');
    var networkGatewayUsername = $('#networkGatewayUsername').val();
    var networkGatewayPassword = $('#networkGatewayPassword').val();

    ajax({
        type: "POST",
        url: window.location.pathname + "/testRemoteListener",
        data: "hostAddress=" + hostAddress + "&hostPort=" + hostPort + "&useSsl="
        + useSsl + "&password=" + password + "&authentication=" + authentication + "&useNetworkGateway=" + useNetworkGateway + "&networkGatewayUsername=" + networkGatewayUsername
        + "&networkGatewayPassword=" + networkGatewayPassword,
        success: function (response) {
            if(response == "true"){
                notifySuccess($("#status-remote-listener-test-success").val());
            }else{
                if($("#" + response).val() != null) {
                    notifyError($("#status-remote-listener-test-failed").val() + " " + $("#" + response).val());
                }else{
                    notifyError($("#status-remote-listener-test-failed-general").val());
                }
            }
        },
        error: function (e) {
            notifyError("Error during test");
        }
    });
}

function testCheckJobsService() {

    notifyInfo($("#status-check-jobs-test").val());

    var hostAddress = $('#hostAddress').val();
    var checkJobsHostAddress = $('#checkJobsHostAddress').val();
    var useSsl = $('#checkJobsUsesSsl').is(':checked');
    var password = $('#password').val();
    var checkJobsPort = $('#checkJobsPort').val();
    var networkGatewayUsername = $('#networkGatewayUsername').val();
    var networkGatewayPassword = $('#networkGatewayPassword').val();

    ajax({
        type: "POST",
        url: window.location.pathname + "/testCheckJobsService",
        data: "hostAddress=" + hostAddress + "&checkJobsHostAddress=" + checkJobsHostAddress + "&useSsl="
        + useSsl + "&password=" + password + "&checkJobsPort=" + checkJobsPort
        + "&networkGatewayUsername=" + networkGatewayUsername + "&networkGatewayPassword=" + networkGatewayPassword,
        success: function (response) {
            if(response == true){
                notifySuccess($("#status-check-jobs-test-success").val())
            }else if(response == false){
                notifyError($("#status-check-jobs-test-failed").val());
            }
        },
        error: function (e) {
            notifyError("Error during test");
        }
    });
}