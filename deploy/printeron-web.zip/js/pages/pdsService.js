$(document).ready(function () {
    if ($("#convertEnd").val() == "true") {
        var endDate = $("#endDate");
        var d = new Date(0);
        d.setUTCSeconds(endDate.html());
        endDate.html(d.toLocaleDateString());
    }

    $("#logDownloadButton").click(function () {
        var newwindow = window.open(CONTEXT + "/logs/downloading", 'Download Support Package', "height=150,width=500px");
        if (window.focus) {newwindow.focus()}
        return false;
    });

    $("#licenseForm").fileUpload({
        success: function (data, textStatus, jqXHR) {

            $("#licenseUploadButtonWrapper").show();
            $("#loading").hide();
            $("#uploadLicense").modal("hide");

            //Get PDS List from Licence File
            if(addLicenseToSession)
            {
                ajax({
                    method: "GET",
                    url: CONTEXT + "/updateLicense/pdsSelect",
                    success: function (data)
                    {
                        $('#pdsSelect')
                            .find('option')
                            .remove()
                            .end();

                        // Add all the serial numbers
                        for(var serial in data) {
                            $('#pdsSelect')
                                .append($("<option></option>")
                                    .attr("value", serial)
                                    .text(data[serial]));
                        }

                        if(data.length == 0)
                        {
                            $("#licenseUpload").prop('disabled', true);
                        }
                        else
                        {
                            $("#licenseUpload").prop('disabled', false);
                        }


                        $("#uploadLicense").modal("hide");
                        $("#pdsSelectModal").modal("show");
                    },
                    error: function (xhr)
                    {
                        notifyError(xhr.responseText);
                        $("#uploadLicense").modal("hide");
                        $("#pdsSelectModal").modal("hide");
                    }
                });
            }
            else
            {
                notifySuccess($("#licenseUploaded").val());
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            notifyError(jqXHR.responseText);
            $("#licenseUploadButtonWrapper").show();
            $("#loading").hide();
        }
    });

    $("#updateLicenseButton").click(function () {
        ajax({
            method: "GET",
            url: CONTEXT + "/ajax/parent",
            success: function (data) {
                if (data.url !== "undefined" && data.url !== "" && data.url !== "null" && data.url !== null && data.connected === false) {
                    $("#disconnectedParentWarning").modal("show");
                }
                else {
                    $("#uploadLicense").modal("show");
                }
            },
            error: function () {
                $("#uploadLicense").modal("show");
            }
        })
    });

    useAjaxForForm($("#pdsSelectForm"), {

        beforeSend: function () {
            startSpinnerOnButton("#licenseUpload");
        },
        success: function () {
            $("#pdsSelectModal").modal("hide");
            stopSpinnerOnButton("#licenseUpload");
            refresh()
        },
        error: function (xhr){
            $("#pdsSelectModal").modal("hide");
            stopSpinnerOnButton("#licenseUpload");
            notifyError(xhr.responseText);
        }
    });
});