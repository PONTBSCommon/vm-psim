function showLoading(){
  $("#spinner").show();
  $("#renamePrinterPanel").hide();
}

