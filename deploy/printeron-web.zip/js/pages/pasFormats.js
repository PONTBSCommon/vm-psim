/**
 * Created by bershaa on 1/15/2015.
 */

$(document).ready(function() {
    $("#formats").accordion({
        heightStyle: "content"
    });

    $(".associatedFormatsList").change(function () {
        showApplicationHandler(this);
    });

    $(".associatedFormatsList").click(function () {
        showApplicationHandler(this);
    });

    var enabled = $("#useFileExt").prop('checked');

    if(enabled != true)
        $("#fileExtPrecedence").attr("disabled", true);

    $('#useFileExt').click(function() {
        $("#fileExtPrecedence").attr("disabled", enabled);
        enabled = !enabled;
    });

    $(".fileExtensionsList").change(function() {
        showFileExtensionsDeleteButton(this);
    });

});




function getUrlParameter(source,sParam)
{
    var n = source.lastIndexOf('?');
    var result = source.substring(n + 1);

    var sURLVariables = result.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

var id;
var perclass;
var verb;

function showEditHandlerPerFormat(lid, lperclass, lverb) {
    id = lid;
    perclass = lperclass;
    verb = lverb;

    showEditHandler();
}

function showEditHandler(){

    $("#edit-handler > .modal-dialog > .modal-content > .modal-body").html("<iframe src=\"modal/edithandler?id=" + id + "&perclass=" + perclass + "&verb=" + verb + "\"id='editHandlerFrame' ></iframe>");

    $('#editHandlerFrame').load(function() {
        onFrameLoad();
    });

    $("#edit-handler").modal("show");
}

function closeEditHandler(modalPopupName){
    $("#"+modalPopupName).modal("hide");

    notifySuccess($("#formatEditSuccess").val());

    setTimeout( function(){
            location.reload();
        }, 2000 );
}


function onFrameLoad(){
    var params = $("#editHandlerFrame").contents().find("#editHandlerForm")[0].action;
    var action = getUrlParameter(params,"saved");

    if(action == "true") {
        closeEditHandler("edit-handler");
    }
}

function showApplicationHandler(control){
    var showControl = $("#" + control.value);
    showControl.show();

    $('.appHandlerPanel').not(showControl).hide();
}


/* *************************************************************** */
/* File Extension Code */
/* *************************************************************** */
function showAddFileExtPopup(control) {
    var classFormatId = control.id.replace("AddButton", "");

    $("#add-fileext > .modal-dialog > .modal-content > .modal-body").html("<iframe src=\"modal/addFileExt?formatclassid=" + classFormatId + "\"id='addFileExtFrame' style='width:100%;' frameBorder='0'></iframe>");

    $("#add-fileext").modal("show");
}

function showFileExtensionsDeleteButton(control) {
    var deleteButtonId = control.id.replace("FileExtensionList", "DeleteButton");
    $("#" + deleteButtonId).show();
}

function deleteFileExtension(control) {
    var fileExtensionListId = control.id.replace("DeleteButton", "FileExtensionList");
    var fileExtensionValue = $("#" + fileExtensionListId).val();
    var formatClassId = control.id.replace("DeleteButton", "");

    if (fileExtensionValue != '') {

        var deleteFileExtensionURL = "fileext?formatclassid=" + formatClassId + "&fileext=" + fileExtensionValue;

        // ajax() method comes from helper.ajax.js and takes care of CSRF and XHR automatically
        ajax({
            type: "DELETE",
            //dataType: "json",
            url: deleteFileExtensionURL,
            success: function (data) {
                notifySuccess($("#formatEditSuccess").val());

                setTimeout( function(){
                    location.reload();
                }, 2000 );
            }
        });
    }

}
