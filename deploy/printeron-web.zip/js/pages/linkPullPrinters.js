/**
 * Created by oliveib on 10/16/2015.
 */

function startLinkedPullPrintersSpinner () {
    $("#linkPullPrintersSubmit").attr("disabled", true);
    $("#linkedPullPrintersWrapper").hide();
    $("#linkedPullPrintersSpinner").show();
    startSpinner("#linkedPullPrintersSpinner");
}

function stopLinkedPullPrintersSpinner () {
    $("#linkPullPrintersSubmit").attr("disabled", false);
    stopSpinner("#linkedPullPrintersSpinner");
    $("#linkedPullPrintersSpinner").hide();
    $("#linkedPullPrintersWrapper").show();
}

function getLinkedPullPrintersSection (printerAliasNum, printerName)
{
    startLinkedPullPrintersSpinner();
    getLinkedPullPrinters(printerAliasNum);
    $("#pullPrinterName").text(printerName);
    $("#linkPullPrintersDialog").modal("show");
}

function getLinkedPullPrinters (printerAliasNum) {

    ajax({
        url: CONTEXT + "/printer/pull/link",
        data : {"pullPrinter" : printerAliasNum},
        method: "GET",
        success: function (data) {
            clearLinkedPullPrinters();
            $("#linkedPullPrintersWrapper").html(data);
            fillLinkedPullPrinters(printerAliasNum);
            $("#pullPrinterAliasNum").val(printerAliasNum);
        },
        error: function (xhr) {
            notifyError(xhr.responseText);
            stopLinkedPullPrintersSpinner();
            stopSpinnerOnButton("#linkPullPrintersSubmit");
            $("#linkPullPrintersDialog").modal("hide");
        }
    })
}

function fillLinkedPullPrinters (printerAliasNum) {

    linkedDataTables({
        "#availablePullPrinters":{
            ajax: {
                url: CONTEXT + "/printer/pull/link/available",
                complete: stopLinkedPullPrintersSpinner
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ],
            "fnServerParams": function ( aoData ) {
                aoData = $.extend(true, aoData, {
                    "pullPrinter": printerAliasNum
                });
            }
        },
        "#linkedPullPrinters":{
            ajax: {
                url: CONTEXT + "/printer/pull/link/linked",
                complete: stopLinkedPullPrintersSpinner
            },
            serverSide: true,
            columns : [
                {data: "label"},
                {data: "department.name"}
            ],
            "fnServerParams": function ( aoData ) {
                aoData = $.extend(true, aoData, {
                    "pullPrinter": printerAliasNum
                });
            },
            form: "#linkPullPrintersForm"
        }
    });
}

function clearLinkedPullPrinters () {
    dtDestroy("#availablePullPrinters");
    dtDestroy("#linkedPullPrinters");
}

function clearLinkedPullPrintersSection () {
    $("#linkedPullPrintersWrapper").html("");
}