/**
 * Created by leibolr on 9/18/2017.
 * JS Helper functions for PAS File Extension popup
 */

$(document).ready(function() {
    var action = getQueryParameter("saved");

    if (action == "true") {
        parent.closeEditHandler("add-fileext"); // call the parent frame to close the modal popup and reload the entire page with new data
    }
});


