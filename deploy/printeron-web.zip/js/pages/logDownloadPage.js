$(document).ready(function () {
    window.location = CONTEXT + "/logs.zip";
});