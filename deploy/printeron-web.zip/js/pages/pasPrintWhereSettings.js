$(document).ready(function () {
    $( "#accordion" ).accordion({
        heightStyle: "content",
        collapsible: true,
        active: false
    });
});