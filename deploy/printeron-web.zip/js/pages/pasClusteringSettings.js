/**
 * Created by bershaa on 1/20/2015.
 */
var currentForm;

function deleteConfirmYES() {
    $("#delete-confirm").modal("hide");
    currentForm.action = currentForm.action + "/modal/delete/" + toDelete;
    currentForm.submit();
}

var toDelete;

function deleteCluster(index){
    $('#delete-confirm').modal('show');

    toDelete = index;

    currentForm = $("#clusterForm")[0];
    //  return false;
}

function closeAddEdit(){
    $('#clusterDialog').modal('hide');

    if(editId == -1)
        notifySuccess($("#clusterAddSuccess").val());
    else
        notifySuccess($("#clusterEditedSuccess").val());

    setTimeout( function(){
            location.reload();
        }, 2000 );
}


function getUrlParameter(source,sParam)
{
    var n = source.lastIndexOf('?');
    var result = source.substring(n + 1);

    var sURLVariables = result.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}


var editId = -1;

function showAddEdit(id) {

    editId = id;

    if (id != -1)
        $("#clusterDialog > .modal-dialog > .modal-content > .modal-body").html("<iframe src=\"modal/edit?index=" + id + "\" id='addEditFrame'></iframe>");
    else
        $("#clusterDialog > .modal-dialog > .modal-content > .modal-body").html("<iframe src='modal/add' id='addEditFrame'></iframe>");

    $('#addEditFrame').load(function() {
        onFrameLoad();
    });

    $('#clusterDialog').modal('show');
}

function onFrameLoad(){
    var params = $("#addEditFrame").contents().find("#addEditForm")[0].action;
    var action = getUrlParameter(params,"saved");

    if(action == "true") {
        closeAddEdit();
    }else{
        //$( "#clusterDialog" ).dialog( "option", "height", 'auto' );
    }
}