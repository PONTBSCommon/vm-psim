function initDatePickers(options) {
    var defaultOptions = {
        autoClose: true,
        endDate: "0d",
        language: "selected"
    };

    if (typeof options !== "undefined") {
        defaultOptions = $.extend(true, {}, defaultOptions, options);
    }

    // Set up some localized vars
    var days = $('#days').val().split(','),
        shortDays = $('#shortDays').val().split(','),
        months = $('#months').val().split(','),
        shortMonths = $("#shortMonths").val().split(','),
        dateFormat = $("#dateFormat").val().trim(),
        startDate = $(".startDate"),
        endDate = $(".endDate");

    // Set the datepicker locale info
    $.fn.datepicker.dates['selected'] = {
        days: days,
        daysShort: shortDays,
        daysMin: shortDays,
        months: months,
        monthsShort: shortMonths,
        format: dateFormat
    };

    // Get the datepicker's global class
    var dpg = $.fn.datepicker.DPGlobal;

    // Get today's date
    var today = new Date();

    // Convert to the same date, but in UTC. This is a hack around so we can use dpg.formatDate without advancing into the future.
    var utcToday = new Date(today.getTime() - (today.getTimezoneOffset() * 60000));

    startDate.val(dpg.formatDate(utcToday, dateFormat, 'selected'));
    endDate.val(dpg.formatDate(utcToday, dateFormat, 'selected'));

    // Enable datepicker
    $('.input-daterange').datepicker(defaultOptions);
}

function initDatePicker (elem, epoch, options) {
    var defaultOptions = {
        autoClose: true,
        language: "selected"
    };

    if (typeof options !== "undefined") {
        defaultOptions = $.extend(true, {}, defaultOptions, options);
    }

    // Set up some localized vars
    var days = $('#days').val().split(','),
        shortDays = $('#shortDays').val().split(','),
        months = $('#months').val().split(','),
        shortMonths = $("#shortMonths").val().split(','),
        dateFormat = $("#dateFormat").val().trim();

    // Set the datepicker locale info
    $.fn.datepicker.dates['selected'] = {
        days: days,
        daysShort: shortDays,
        daysMin: shortDays,
        months: months,
        monthsShort: shortMonths,
        format: dateFormat
    };

    // Get the datepicker's global class
    var dpg = $.fn.datepicker.DPGlobal;

    // Get today's date
    var today = new Date(0);
    today.setUTCMilliseconds(epoch);

    // Convert to the same date, but in UTC. This is a hack around so we can use dpg.formatDate without advancing into the future.
    //var utcToday = new Date(today.getTime() - (today.getTimezoneOffset() * 60000));

    elem.val(dpg.formatDate(today, dateFormat, 'selected'));

    // Enable datepicker
    elem.datepicker(defaultOptions);
}