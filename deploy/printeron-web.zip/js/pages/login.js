function confirmReset () {
    $("#passwordReset").modal("show");
}

function resetPassword () {

    // This is not using the helper because we shouldn't redirect on an unauthorized response
    $.ajax({
        type : "POST",
        url : window.location.pathname + "/resetpassword",
        data: {"siteAuth":$("#siteAuth").val()},
        beforeSend : function(xhr) {
            xhr.setRequestHeader($("meta[name='_csrf_header']").attr("content"), $("meta[name='_csrf']").attr("content"));
        },
        success : function() {
            $("#passwordReset").modal("hide");
            $("#passwordResetOK").modal("show");
        },
        error : function(e) {
            $("#passwordReset").modal("hide");
            $("#passwordResetERROR").modal("show");
        }
    });
}

function showFirstLoginHelp() {
    $("#loginHelp").toggle();
}
$(document).ready(function () {

    if ($("#badCredentials").length) {
        $("#badCredentials").modal("show");
    }

    if ($("#cpsOffline").length) {
        $("#cpsOffline").modal("show");
    }

    if ($("#locked").length) {
        $("#locked").modal("show");
    }

    if ($("#sessionExpired").length) {
        $("#sessionExpired").modal("show");
    }

});