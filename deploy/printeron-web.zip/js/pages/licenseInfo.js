//Get if services Configuration have been changed
var servicesConfigurationHasChanged = false;
var tableLoaded = false;

$(document).ready(function() {

    // Get the epoch times
    var start = $("#licenseStart").val();
    var end = $("#licenseEnd").val();
    var never = $("#expiryNever").val();
    var days = $("#days").val();

    // Get the divs to set
    var startDiv = $("#startDate");
    var endDiv = $("#endDate");

    // Set the start div
    var startDate = new Date(0);
    startDate.setUTCMilliseconds(start);
    startDiv.html(startDate.toLocaleDateString());

    // Set the end div
    if(end == 0) {
        endDiv.html(never);
    } else {
        var endDate = new Date(0);
        endDate.setUTCMilliseconds(end);
        endDiv.html(endDate.toLocaleDateString());
    }

    $("#btnApplySettings").click(function ()
    {
        if(servicesConfigurationHasChanged)
        {
            $("#changeConfirmDialog").modal("show");
        }
        else
        {
            $("#webServiceManager").submit();
        }
    });

    $("#confirmChangesModalButton").click(function ()
    {
        $("#webServiceManager").submit();
    });

    $("#licenseForm").fileUpload({
        success: function (data, textStatus, jqXHR) {

            $("#licenseUploadButtonWrapper").show();
            $("#loading").hide();
            $("#uploadLicense").modal("hide");

            if (data == "true") {
                $("#updateCredentialsDialog").modal("show");
            }
            else {
                notifySuccess($("#licenseUploaded").val());
                setTimeout(function () {
                    window.location.href = window.location.href;
                }, 5000)
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            notifyError(jqXHR.responseText);
            $("#licenseUploadButtonWrapper").show();
            $("#loading").hide();
        }
    });

    $(".updateCredentialsOK").click(function () {
        notifySuccess($("#licenseUploaded").val());
        $("#updateCredentialsDialog").modal("hide");

        setTimeout(function () {
            window.location.href = window.location.href;
        }, 1750)
    });

    $("#updateLicenseButton").click(function () {
        ajax({
            method: "GET",
            url: CONTEXT + "/ajax/parent",
            success: function (data) {
                if (data.url !== "undefined" && data.url !== "" && data.url !== "null" && data.url !== null && data.connected === false) {
                    $("#disconnectedParentWarning").modal("show");
                }
                else {
                    $("#uploadLicense").modal("show");
                }
            },
            error: function () {
                $("#uploadLicense").modal("show");
            }
        })
    });

    $("#disconnectedParentWarningOK").click(function () {
        $("#disconnectedParentWarning").modal("hide");
        $("#uploadLicense").modal("show");
    });
    
    $("#downloadCustomLicense").click(function ()
    {
        if(tableLoaded)
        {
            dtUnloadUUID($("#availableServers"));
            $("#selectNetworkPrinter").DataTable().ajax.url(CONTEXT + "/status/license/ponServers").load();
            dtRedraw(true, "#availableServers");

            dtUnloadUUID($("#linkedServers"));
            $("#selectNetworkPrinter").DataTable().ajax.url(CONTEXT + "/status/license/ponServersEmpty").load();
            dtRedraw(true, "#linkedServers");
        }
        else
        {
            linkedDataTables({
                "#availableServers":{
                    ajax: {
                        url: CONTEXT + "/status/license/ponServers",
                    },
                    serverSide: true,
                    columns : [
                        {data: "label"},
                        {data: "serialNumber"}
                    ]
                },
                "#linkedServers":{
                    ajax: {
                        url: CONTEXT + "/status/license/ponServersEmpty",
                    },
                    serverSide: true,
                    columns : [
                        {data: "label"},
                        {data: "serialNumber"}
                    ],
                    "form": "#linkServersForm"
                }
            });
            
            tableLoaded = true;
        }
        
        

        $("#pdsSelectModal").modal("show");
    });

    $("#pdsSelectModalOK").click(function ()
    {
        $("#linkServersForm").submit();
        
        $("#pdsSelectModal").modal("hide");
    });
});

function onChangeWebServiceType(){

    var selectedType = $("#webServiceManagerConnectionType").val();
    var savedType = $("#savedType").val();
    var savedUrl = $("#savedUrl").val();
    var directConnection = $("#directConnection").val();
    var urlField = $("#webServiceManagerUrl");

    // Direct connection is selected
    if(selectedType == directConnection) {

        urlField.prop('readonly', true);

        // Direct connection is saved value, or back to default
        if(savedType == directConnection) {
            urlField.val(savedUrl);
        } else {
            urlField.val($("#defaultRemoteServiceUrl").val());
        }

    } else {
        urlField.prop('readonly', false);

        // Display the saved value if flipping back and forth
        if(savedType != directConnection) {
            urlField.val(savedUrl);
        } else {
            urlField.val($("#defaultLocalServiceUrl").val());
        }
    }

    servicesConfigurationHasChanged = true;
}