$(document).ready(function () {

    if ($("#changePasswordError").length) {
        $("#changePasswordError").modal("show");
    }

    if ($("#locked").length) {
        $("#locked").modal("show");
    }

    $(document).keypress(function(e) {
        if(e.which == 13) {
            $("#loginBtn").trigger("click");
        }
    });

    $("#loginBtn").click(function () {
        var result = samsungPolicyEnforcementPassword("root", $("#password").val());
        var dialog;

        if (result == 0)
        {
            $("#loginForm").submit();
        }
        else if (result == 1)
        {
            dialog = $("#containsUsername");
        }
        else if (result == 2)
        {
            dialog = $("#wrongLength");
        }
        else
        {
            dialog = $("#badPassword");
        }

        if (typeof dialog != "undefined") {
            dialog.modal("show");
        }
    });
});