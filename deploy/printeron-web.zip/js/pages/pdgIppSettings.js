$(document).ready(function(){
    //$('input[type=checkbox]').click(function() {
    //    var s = $(this).parent('div').parent(".row").find('.key');
    //
    //    if(s.is(':disabled')) {
    //        s.removeAttr('disabled');
    //    } else {
    //        s.attr('disabled','true');
    //    }
    //});

    $('input[type=checkbox]').click(function() {
        var s = $(this).closest('tr').find('select');

        if(s.is(':disabled')) {
            s.removeAttr('disabled');
        } else {
            s.attr('disabled','true');
        }
    });

    //

    enablePort();

    dtLoad("#ippPrintersTable");

    
    $("#ippPrintersTable").on("draw.dt", function ()
    {
        //Resize parent iFrame when change the dataTables display row number
        parent.document.getElementById("workflowFrame").height = window.parent.document.body.scrollHeight;

    });
});

function enablePort() {
    var isChecked = $("#defaultIPPPortEnabled").is(':checked');

    if (isChecked) {
        $('#enableSSLLocalListener1').removeAttr('disabled');
        $('#defaultIPPPort').removeAttr('disabled');
    } else {
        $('#enableSSLLocalListener1').attr('disabled', 'disabled');
        $('#defaultIPPPort').attr('disabled', 'disabled');
    }

    isChecked = $("#additional1PortEnabled").is(':checked');

    if (isChecked)
    {
        $('#enableSSLLocalListener2').removeAttr('disabled');
        $('#additional1Port').removeAttr('disabled');
    }
    else {
        $('#enableSSLLocalListener2').attr('disabled', 'disabled');
        $('#additional1Port').attr('disabled', 'disabled');
    }

    isChecked = $("#additional2PortEnabled").is(':checked');

    if(isChecked) {
        $('#enableSSLLocalListener3').removeAttr('disabled');
        $('#additional2Port').removeAttr('disabled');
    }
    else {
        $('#enableSSLLocalListener3').attr('disabled', 'disabled');
        $('#additional2Port').attr('disabled', 'disabled');
    }

    isChecked = $("#lpdPortEnabled").is(':checked');

    if (isChecked)
    {
        $('#lpdPort').removeAttr('disabled');
    }
    else
    {
        $('#lpdPort').attr('disabled', 'disabled');
    }
}

function doAjaxPost() {

    $("#proxyTestResult").val("Testing...");
    $("#proxyTestResultSsl").val("Testing...");

    var proxyUsername = $('#proxyModel\\.proxyUser').val();
    var proxyPort = $('#proxyModel\\.proxyPort').val();
    var proxyUrl = $('#proxyModel\\.proxyUrl').val();
    var proxyPassword = $('#proxyModel\\.proxyPassword').val();

    var url = window.location.pathname.replace(/pdgIppSettings(\/)?/, "proxySettings/testProxy");

    ajax({
        type : "POST",
        url : url,
        data : "proxyUrl=" + proxyUrl + "&proxyPort=" + proxyPort + "&proxyUsername="
        + proxyUsername + "&proxyPassword=" + proxyPassword,
        dataType:"json",
        success : function(response) {
            $("#proxyTestResult").val(response.nonssl);
            $("#proxyTestResultSsl").val(response.ssl);
        },
        error : function(e) {

            // TODO: localize?
            $("#proxyTestResult").val("Test Failed");
            $("#proxyTestResultSsl").val("Test Failed");
        }
    });
}

function doAjaxPost() {
    notifyInfo($("#runCredentialsTest").val());

    var cpsUrl = $('#cpsUrl').val();

    var locationUrl = trailingSlash(window.location.pathname) + "/testCps";

    ajax({
        type: "POST",
        url: locationUrl,
        data: "cpsUrl=" + cpsUrl,
        success : function(response) {
            notifySuccess($("#credentialsTestSuccess").val());
        },
        error : function(e) {
            notifyError($("#credentialsTestFailed").val());
        }
    });
}