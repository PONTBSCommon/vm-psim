
/**
 * Disable ajax caching on GET and HEAD requests.
 */
$.ajaxSetup ({
    cache: false
});

/**
 * Binds to the form's submit event and submits via AJAX instead
 *
 * @param form The form to bind to
 * @param params optional parameters to pass to the AJAX call
 */
function useAjaxForForm (form, params) {
    form = $(form);

    if (typeof params === "undefined") {
        params = {};
    }

    var finalParams = jQuery.extend(true, {}, params);

    if (params.hasOwnProperty("url")) {
        finalParams.url = params.url;
    }
    else {
        finalParams.url = form.attr("action");
    }

    if (params.hasOwnProperty("type")) {
        finalParams.type = params.type;
    }
    else {
        finalParams.type = form.attr("method");
    }

    if (params.hasOwnProperty("success")) {
        finalParams.success = params.success;
    }
    else
    {
        finalParams.success = function (resp) {
            if (resp != null && resp != "") {
                notifySuccess(resp);
            }
        };
    }

    if (params.hasOwnProperty("error")) {
        finalParams.error = function (xhr) {
            defaultErrorFunction(xhr, form);

            params.error(xhr);
        }
    }
    else {
        finalParams.error = function(xhr) {
            defaultErrorFunction(xhr, form);
        }
    }

    finalParams.data = function () {return form.serialize()};

    //make sure there isn't another submit event binding
    form.unbind("submit");

    form.submit(function () {
        ajax(finalParams);
        return false;
    });
}

/**
 * General ajax call that does an ajax call with whatever params you supply, and adds the XHR token automatically.
 *
 * @param params The ajax params.
 */
function ajax(params) {

    // Make a copy of the object
    var ajaxParams = $.extend(true, {}, params);

    // Add the before send token, but preserve custom beforeSend
    ajaxParams.beforeSend = function(xhr, settings){

        xhr.setRequestHeader(CSFR_HEADER, CSFR_TOKEN);

        // Call the specified beforeSend afterward
        if(params.hasOwnProperty("beforeSend")) {
            params.beforeSend(xhr, settings);
        }
    };

    ajaxParams.error = function (xhr) {
        if (xhr.status == 401) {
            window.location = CONTEXT + "/login";
        }

        if (params.hasOwnProperty("error")) {
            params.error(xhr);
        }
    };

    if (ajaxParams.hasOwnProperty("data")) {
        if (jQuery.isFunction(ajaxParams.data)) {
            ajaxParams.data = ajaxParams.data();
        }
    }

    // Do the Ajax call
    $.ajax(ajaxParams);
}

function defaultErrorFunction (xhr, form) {
    if (typeof form === "undefined") {
        form = $("body");
    }

    if(xhr.status == 400) {
        var errors = JSON.parse(xhr.responseText);
        for (var error in errors) {
            var target = $("input[name='" + errors[error].field + "']", form);

            if (!target.length) {
                target = $("#" + errors[error].field);
            }

            addErrorToField(target, errors[error].error);
        }
    }
    else {
        notifyError(xhr.responseText);
    }
}