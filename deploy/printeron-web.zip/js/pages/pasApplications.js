/**
 * Created by bershaa on 1/14/2015.
 */

function closeEditApplication()
{
    $('#edit-application').modal('hide');

    notifySuccess($("#appEditSuccess").val());

    setTimeout( function(){
            location.reload();
        }, 2000 );
}


function getUrlParameter(source,sParam)
{
    var n = source.lastIndexOf('?');
    var result = source.substring(n + 1);

    var sURLVariables = result.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

var currentClassValue;
var editedField;
var remind = true;

$(document).ready(function() {
    $('.perClass').on('input', function() {
        if (remind) {
            editedField = this;
            currentClassValue = $("#current_" + this.id).val();
            $('#classChangeWarning').modal('show');
        }
    });

    $("#applications").accordion({
        heightStyle: "content"
    });

    $('input.selectPrinter').on('change', function () {
        $('input.selectPrinter').not(this).prop('checked', false);
    });

    $('#editApplicationFrame').load(function () {
        onFrameLoad();
    });
});

function autoConfigureWarningYES() {
    $("#autoConfigureWarning").modal("hide");
    notifyInfo($("#autoConfigureInProgress").val());
    performAutoConfigure();
}

function resetToDefaultsWarningYES() {
    $("#resetToDefaultsWarning").modal("hide");
    notifyInfo($("#resetToDefaultsInProgress").val());
    performReset();
}

function classChangeWarningYES() {
    if ($("#doNotRemind").is(":checked")) {
        remind = false;
    }
    $("#classChangeWarning").modal("hide");
}

function classChangeWarningNO() {
    $("#classChangeWarning").modal("hide");
    editedField.value = currentClassValue;
}

function onFrameLoad(){
    var params = $("#editApplicationFrame").contents().find("#editApplicationForm")[0].action;
    var action = getUrlParameter(params, "saved");

    if (action == "true") {
        closeEditApplication();
    }
}


function editApplication(id, timeout, recycleCount){
    $("#edit-application > .modal-dialog > .modal-content > .modal-body").html("<iframe src=\"modal/edit?id=" + id + "&timeout=" + timeout + "&recycleCount="  + recycleCount + "\" id='editApplicationFrame'></iframe>");

    $('#editApplicationFrame').load(function() {
        onFrameLoad();
    });

    $('#edit-application').modal('show');
}

function autoConfigure(){
    $("#autoConfigureWarning").modal("show");
}


function resetToDefaults(){
    $("#resetToDefaultsWarning").modal("show");
}

function performAutoConfigure(){

    ajax({
        type : "POST",
        url : window.location.pathname + "/autoConfigure",
        success : function(response) {

            notifySuccess($("#autoConfigured").val());

            setTimeout( function(){
                    location.reload();
                }, 2000 );
        },
        error : function(e) {

        }
    });
}

function performReset(){

    ajax({
        type : "POST",
        url : window.location.pathname + "/reset",
        success : function(response) {

            notifySuccess($("#resetSuccess").val());

            setTimeout( function(){
                    location.reload();
                }, 2000 );
        },
        error : function(e) {

        }
    });
}