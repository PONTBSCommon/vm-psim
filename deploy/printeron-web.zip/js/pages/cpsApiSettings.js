/**
 * On document ready, initialize click handlers.
 */
$(document).ready(function() {

    // Register the add user and key event handlers
    $("#addUserButton").click(addUser);
    $("#generateKeyButton").click(generateApiAccessKey);

    // And the remove user handler
    $(".removeUser").unbind().click(removeUser);
    $(".removeKey").unbind().click(removeKey);

    // Bind the error handler
    bindUserErrorHandler();
});

/**
 * Adds an api user.
 *
 * @param event Event that triggered the onClick.
 */
function addUser(event) {

    // Find the largest index in the table
    var userTable = $("#apiUsers");
    var tBody = userTable.find("tbody");
    var lastRow = tBody.find("tr:last");
    var index;

    // No entries found, start at 0
    if(lastRow.length == 0) {
        index = 0;
    } else {
        index = parseInt(lastRow.attr("id").split("-")[1]) + 1;
    }

    // Create a row
    var row = '<tr id="user-' + index + '">';
    row += "<td>";
    row += '<input id="apiUsers\'' + index + '\'.username" name="apiUsers[\'' + index + '\'].username" class="form-control" type="text" required="true">';
    row += "</td><td>";
    row += '<input id="apiUsers\'' + index + '\'.password" name="apiUsers[\'' + index + '\'].password" class="form-control" type="password" required="true">';
    row += '</td><td class="text-right"><span class="removeUser glyphicons glyphicons-circle-minus red hoverable x1" aria-hidden="true" id="removeUser-' + index + '"></span></td>';
    row += "</tr>";

    // Insert the row
    if(lastRow.length == 0) {
        tBody.html(row);
    } else {
        lastRow.after(row);
    }

    // Remove the borderless class, and change the headings to the right things
    if(userTable.hasClass("borderless")) {
        userTable.removeClass("borderless");
        $("#usernameHeading").html($("#usernameMessage").val());
        $("#passwordHeading").html($("#passwordMessage").val());
    }

    // Re-init the remove handler, so the new row gets it
    $(".removeUser").unbind().click(removeUser);

    // Add validation
    bindUserErrorHandler();
}

/**
 * Removes a user.
 *
 * @param event The event that spawned the onClick
 */
function removeUser(event) {

    // Get the button that spawned the on click
    var id = getIdFromEvent(event);

    // Split the id to get the index
    var index = id.split("-")[1];

    var userTable = $("#apiUsers");

    // Get all the rows in the body
    var rows = userTable.find("tbody tr");

    // Loop over all rows in the table, so you can edit their index
    var decrement = false;
    rows.each(function (i, row) {

        var rowIndex = $(row).attr("id").split("-")[1];

        if (rowIndex == index && !decrement) {

            // Remove the row
            $(row).remove();

            // Start decrementing following rows
            decrement = true;

        } else if (decrement) {
            changeUserRowIndex(row, rowIndex, rowIndex - 1);
        }
    });

    // If there are no more rows, make it look empty
    if(userTable.find("tbody tr").length == 0) {

        userTable.addClass("borderless");
        $("#usernameHeading").html($("#noUserMessage").val());
        $("#passwordHeading").html("");
    }
}

/**
 * Changes the index of a user row.
 *
 * @param row The row.
 * @param oldIndex The old index.
 * @param newIndex The desired index.
 */
function changeUserRowIndex(row, oldIndex, newIndex) {

    // Update the row id
    $(row).attr("id", "user-" + newIndex);

    // Update the username input
    var username = $("#apiUsers\\'" + oldIndex + "\\'\\.username");
    username.attr("name", "apiUsers['" + newIndex + "'].username");
    username.attr("id", "apiUsers'" + newIndex + "'.username");

    // And the password input
    var password = $("#apiUsers\\'" + oldIndex + "\\'\\.password");
    password.attr("name", "apiUsers['" + newIndex + "'].password");
    password.attr("id", "apiUsers'" + newIndex + "'.password");

    // And the delete button
    $('#removeUser-' + oldIndex).attr("id", "removeUser-" + newIndex);
}

/**
 * Binds an error handler to the form.
 */
function bindUserErrorHandler() {

    // Unbind the generic handler
    $("#cpsApiModel").unbind();

    // Register an invalid event handler
    $("form input").on("invalid", function(event) {

        var target = $(".errorMessage");

        // Add error class to input
        $(this).addClass("error");

        // Insert the error message
        var message = $("#emptyErrorMessage").val();
        target.html("<span class='error-tooltip' title='" + message + "'><span class='glyphicons glyphicons-circle-exclamation-mark'></span></span>");
    });
}

/**
 * Generates an API access key, and adds it to the listing.
 *
 * @param event Event that triggered the click.
 */
function generateApiAccessKey(event) {

    // Do the ajax call to generate a new key
    ajax({
        url: "generateKey",
        type: "GET",
        success: function (resp) {

            // Find the largest index in the table
            var keyTable = $("#accessKeys");
            var tBody = keyTable.find("tbody");
            var lastRow = tBody.find("tr:last");
            var index;

            // No entries found, start at 0
            if(lastRow.length == 0) {
                index = 0;
            } else {
                index = parseInt(lastRow.attr("id").split("-")[1]) + 1;
            }

            // Create a row
            var row = '<tr id="key-' + index + '">';
            row += "<td>";
            row += resp;
            row += '<input id="apiAccessKeys\'' + index + '\'" name="apiAccessKeys[\'' + index + '\']" type="hidden" value="' + resp + '">';
            row += "</td>";
            row += '<td class="text-right"><span class="removeKey glyphicons glyphicons-circle-minus red hoverable x1" aria-hidden="true" id="removeKey-' + index + '"></span></td>';
            row += "</tr>";

            // Insert the row
            if(lastRow.length == 0) {
                tBody.html(row);
            } else {
                lastRow.after(row);
            }

            // Remove the borderless class, and change the headings to the right things
            if(keyTable.hasClass("borderless")) {
                keyTable.removeClass("borderless");
                $("#keyHeading").html($("#keyMessage").val());
            }

            // Re-init the remove handler, so the new row gets it
            $(".removeKey").unbind().click(removeKey);

            // Add validation, with only a tooltip
            bindErrorHandler(true);
        },
        error: function() {

        }
    });
}

/**
 * Removes an API key.
 *
 * @param event The event that triggered the click.
 */
function removeKey(event) {

    // Get the button that spawned the on click
    var id = getIdFromEvent(event);

    // The keys table
    var keyTable = $("#accessKeys");

    // Split the id to get the index
    var index = id.split("-")[1];

    // Loop over all rows in the table, so you can edit their index
    var decrement = false;
    keyTable.find("tbody tr").each(function(i, row) {

        var rowIndex = $(row).attr("id").split("-")[1];

        if(rowIndex == index && !decrement) {

            // Remove the row
            $(row).remove();

            // Start decrementing following rows
            decrement = true;

        } else if(decrement) {
            changeKeyRowIndex(row, rowIndex, rowIndex - 1);
        }
    });

    // If there are no more rows, make it look empty
    if(keyTable.find("tbody tr").length == 0) {

        keyTable.addClass("borderless");
        $("#keyHeading").html($("#noKeyMessage").val());
        $("#passwordHeading").html("");
    }
}

/**
 * Changes a rows index.
 *
 * @param row The row.
 * @param oldIndex The rows old index.
 * @param newIndex The rows new index.
 */
function changeKeyRowIndex(row, oldIndex, newIndex) {

    // Update the row id
    $(row).attr("id", "key-" + newIndex);

    // And the hidden input
    var hidden = $("#apiAccessKeys\\'" + oldIndex + "\\'");
    hidden.attr("name", "apiAccessKeys['" + newIndex + "']");
    hidden.attr("id", "apiAccessKeys'" + newIndex + "'");

    // And the delete button
    $('#removeKey-' + oldIndex).attr("id", "removeKey-" + newIndex);
}