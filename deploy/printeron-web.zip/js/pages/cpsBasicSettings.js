var removeLanguageSelect = $("#removeLanguageSelect-wrapper > select");
var removeLanguageWrapper = $("#removeLanguage-wrapper");
var addLanguageSelect = $("#addLanguageSelect-wrapper > select");
var addLanguageWrapper = $("#addLanguage-wrapper");
var languageSelect = $("#localeDropdownInput");

function toggleLanguageSelect ()
{
    if (removeLanguageSelect.children("option").length <=1)
    {
        removeLanguageWrapper.hide();
    }
    else
    {
        removeLanguageWrapper.show();
    }

    if (addLanguageSelect.children("option").length == 0)
    {
        addLanguageWrapper.hide();
    }
    else
    {
        addLanguageWrapper.show();
    }
}

function toggleGuestDirectorySearch()
{
    var directorySearch = $("#dirSearchPonDirEnabledInput");

    $("#dirSearchGuestAccessEnabledInput").prop("disabled", !directorySearch.is(':checked'));

    if(!directorySearch.is(':checked'))
    {
        $("#dirSearchGuestAccessEnabledInput").attr('checked', false)
    }
}

$(document).ready(function () {

    toggleLanguageSelect();

    toggleGuestDirectorySearch();

    $("#manageLanguages").on("click", function () {
        $("#manageLanguagesModal").modal("show");
    });

    $("#dirSearchPonDirEnabledInput").click(function()
    {
        $("#dirSearchGuestAccessEnabledInput").prop("disabled", !$(this).is(':checked'));

        if(!$(this).is(':checked'))
        {
            $("#dirSearchGuestAccessEnabledInput").attr('checked', false)
        }
    });



    $("#addLanguagesForm").on("submit", function () {
        $("#addLanguageButton").hide();
        $("#loadingAdd").show();

        ajax({
            url: $(this).attr("action"),
            context: document.body,
            type: 'post',
            data: $(this).serialize(),
            success: function () {
                notifySuccess($("#settingsSaved").val());
                $("#addLanguageButton").show();
                $("#loadingAdd").hide();
                var text = addLanguageSelect.find("option[value='"+addLanguageSelect.val()+"']").html();
                removeLanguageSelect.append("<option value='"+addLanguageSelect.val()+"'>"+text+"</option>");
                languageSelect.append("<option value='"+addLanguageSelect.val()+"'>"+text+"</option>");
                addLanguageSelect.find("option[value='"+addLanguageSelect.val()+"']").remove();
                toggleLanguageSelect();
            },
            error: function (error) {
                notifyError(error.responseText);
                $("#addLanguageButton").show();
                $("#loadingAdd").hide();
            }
        });

        return false;
    });

    $("#removeLanguagesForm").on("submit", function () {
        $("#removeLanguageButton").hide();
        $("#loadingRemove").show();

        ajax({
            url: $(this).attr("action"),
            context: document.body,
            type: 'post',
            data: $(this).serialize(),
            success: function () {
                notifySuccess($("#settingsSaved").val());
                $("#removeLanguageButton").show();
                $("#loadingRemove").hide();
                var text = removeLanguageSelect.find("option[value='"+removeLanguageSelect.val()+"']").html();
                languageSelect.find("option[value='"+removeLanguageSelect.val()+"']").remove();
                addLanguageSelect.append("<option value='"+removeLanguageSelect.val()+"'>"+text+"</option>");
                removeLanguageSelect.find("option[value='"+removeLanguageSelect.val()+"']").remove();
                toggleLanguageSelect();
            },
            error: function (error) {
                notifyError(error.responseText);
                $("#removeLanguageButton").show();
                $("#loadingRemove").hide();
            }
        });

        return false;
    });

    /**
     * On click for drop down select of docApi url.
     */
    $(".docApiUrlSelectLink").click(function() {

        // Replace the value in the api input field
        $("#docApiUrlInput").val(this.innerHTML + $("#cpsSuffix").val());
    });
});