/**
 * Adds spinner functionality to invalid license page buttons.
 *
 * @author Lukas Rezek <lrezek@printeron.com>
 */
$(document).ready(function() {

    var connectedToParent = $("#connectedToParent") === "true";
    var master = $("#master") === "true";

    $("#buttons").find(".btn").click(function(){

        // If this is a child server and we're not connected to the parent, display a prompt
        if(!master && !connectedToParent) {
            $("#unconnectedParentPrompt").modal("show");
        }

        // Looks all good, just update it
        else {
            submitForm();
        }
    });

    // bind the confirmation modal
    $("#confirmationPromptOk").click(function() {

        // Show the modal and submit the form
        $("#unconnectedParentPrompt").modal("hide");
        submitForm();
    });
});

/**
 * Submits the update license form.
 */
function submitForm() {
    $("#buttons").hide();
    startSpinner("#button-wrapper");
    $("#licenseForm").submit();
}