/**
 * Created by bershaa on 1/29/2015.
 */
var isImport = true;
var currentForm;
var map = {};
var serialTable;
var sitesTable;

$(function (){
    currentForm = $("#importForm")[0];

    $('form').submit(function(e) {
        notifyInfo($("#status-importing").val());
    });

    var sPageURL = window.location.search.substring(1);

    if(typeof siteMap === 'undefined') {

        // Task was rejected
        if(getUrlParameter(sPageURL, "importRejected") == "true") {

            notifyError($("#status-import-rejected").val());

        // Task was not rejected, display the import/reset success as applicable
        } else {

            if (getUrlParameter(sPageURL, "success") == "true") {
                notifySuccess($("#status-imported-success").val());
            } else if (getUrlParameter(sPageURL, "success") == "false") {
                notifyError($("#status-imported-failure").val());
            }

            if (getUrlParameter(sPageURL, "reset") == "true") {
                notifySuccess($("#status-reset-success").val());
            } else if (getUrlParameter(sPageURL, "reset") == "false") {
                notifyError($("#status-reset-failure").val());
            }
        }
    }

    //if we brought back more than one site
    // load up the data table with a list of sites
    if(typeof siteMap !== "undefined" && siteMap.length > 0) {

        sitesTable = dtLoad("#sitesTable", {
            serverSide: false,
            data: siteMap,
            "columns": [
                {"data": "description"}
            ],
            selectableRows: true,
            multiSelectRows: false
        });

        sitesTable.on( 'search.dt', function () {
            sitesTable.$('tr.selected').removeClass('selected');
        } );

        $("#site-selection-modal").modal("show");
        $("#previous").hide();

        $.map(siteMap, function (val, i) {
            map[val.id] = val.portalMap;
        });

        $("#next").click(siteSelectionClicked);
        $("#previous").click(goToSiteSelection);
    }
});

//site selection was selected
function siteSelectionClicked() {

    var data = sitesTable.rows('.selected').data();

    if(data.length == 0) {
        notifyError($("#status-imported-failure").val());
    } else {

        // Get the server map for the first language
        var portalMap = data[0].portalMap;
        var serverMap = portalMap[Object.keys(portalMap)[0]].serverMap;

        // Initialize an array of serial numbers and an array of servers
        var serialNumbers = [];
        var servers = [];

        // Map the select values to an array
        $.each(serverMap, function (index, value) {
            serialNumbers.push(value.serialNumber);
            servers.push(value);
        });

        // Only show serial number selection if we have more than 1 serial
        if(serialNumbers.length > 1) {

            if(typeof serialTable != 'undefined')
            {
                serialTable.destroy();
            }

            serialTable = dtLoad("#serialNumbersTable", {
                serverSide: false,
                data: servers,
                "columns": [
                    {"data": "id"},
                    {"data": "serialNumber"}
                ],
                selectableRows: true,
                multiSelectRows: false
            });

            serialTable.on( 'search.dt', function () {
                serialTable.$('tr.selected').removeClass('selected');
            } );

            $("#previous").show();
            $("#siteDiv").hide();
            $("#serialNumbersDiv").show();
            $("#selectSite").hide();
            $("#selectSerial").show();

            $("#next").unbind();
            $("#next").click(serialSelected);

        // Only 1 serial, submit immediately
        } else if(serialNumbers.length == 1) {

            $("#serialNumber").val(serialNumbers[0]);
            $("#site-selection-modal").modal("hide");
            $("#importSubmit").click();

        // Clear out the serial number and give an error
        } else {

            $("#serialNumber").val("");
            $("#site-selection-modal").modal("hide");
            notifyError($("#status-imported-failure").val());
        }
    }
}

// Serial number selected
function serialSelected() {

    var serialData = serialTable.rows('.selected').data();

    if(serialData.length == 1)
    {
        $("#serialNumber").val(serialData[0].serialNumber);
    }
    else
    {
        var data = serialTable.rows('.selected').data();

        if(data.length > 0)
        {
            $("#serialNumber").val(data[0].serialNumber);
        }
    }

    $("#site-selection-modal").modal("hide");
    $("#importSubmit").click();
}

//this controls the previous button
function goToSiteSelection() {

    // Hide previous and the serial numbers
    $("#previous").hide();
    $("#selectSerial").hide();
    $("#serialNumbersDiv").hide();

    // Show the site selection and site div
    $("#selectSite").show();
    $("#siteDiv").show();

    // Clear the selected row
    dtResetSelectedRows("#sitesTable");

    // Clear the search when you go back
    sitesTable.search('')
        .columns().search('')
        .draw();

    $("#next").unbind();
    $("#next").click(siteSelectionClicked);
}

function resetConfirmYES() {

    $("#reset-confirm").modal("hide");

    currentForm.action = $("#resetAction").val();

    notifyInfo($("#status-resetting").val());

    currentForm.submit();
}

function resetCustomizationData() {

    isImport = false;
    $("#reset-confirm").modal("show");
}
