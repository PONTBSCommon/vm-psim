var associationOK = false;
var noAssociationModal = $("#noAssociationModal");
var printValetForm = $("#pdsAddEditPrintValet");
var serial = $('input[name="enableSerialPrintValets"]');
var ethernet = $("input[name='enableEthernetPrintValets1']");

function associationConfirmed () {
    associationOK = true;
    noAssociationModal.modal("hide");
    printValetForm.submit();
}

$(document).ready(function () {

    if ($('#serialPortName option').length < 1) {
        ethernet.prop("disabled", true);
        serial.prop("disabled", true);
        $('#serialPortName').prop("disabled", true);
    }

    //set initial disable
    if (serial.is(":checked")) {
        $("#portName").prop("disabled", true);
        ethernet.prop("checked", false);
        $('#serialPortName').prop("disabled", false);
    }
    else if (ethernet.is(":checked"))
    {
        $("#portName").prop("disabled", false);
        serial.prop("checked", false);
        $('#serialPortName').prop("disabled", true);
    }

    serial.on('click', function () {
        if ($(this).is(":checked")) {
            $("#portName").prop("disabled", true);
            ethernet.prop("checked", false);
            $('#serialPortName').prop("disabled", false);
        }
        else {
            $("#portName").prop("disabled", false);
            ethernet.prop("checked", true);
            $('#serialPortName').prop("disabled", true);
        }
    });

    ethernet.on("click", function () {
        if ($(this).is(":checked")) {
            $("#portName").prop("disabled", false);
            serial.prop("checked", false);
            $('#serialPortName').prop("disabled", true);
        }
        else {
            $("#portName").prop("disabled", true);
            serial.prop("checked", true);
            $('#serialPortName').prop("disabled", false);
        }
    });

    printValetForm.submit(function () {
        if (!$(".printerAssociation-checkboxes").length || !$("#printerCheckboxes").find("input:checked").length)
        {
           if (!associationOK) {
               noAssociationModal.modal("show");
               return false;
           }
        }

        return true;
    });
});

function refreshSerialPortList()  {

    notifyInfo($("#refresh").val());

    ajax({
        type: "GET",
        url: window.location.pathname + "/getSerialPorts",
        success: function (response) {

            $('#serialPortName')
                .find('option')
                .remove();

            notifySuccess($("#refreshSuccess").val());

            $.each(response, function(index, value){
                $('#serialPortName').append("<option value=\"" + value + "\">" + value + "</option>");
            });
        },
        error: function (e) {

            //TODO: localize?
            notifyError('Error: ' + e);
        }
    });

}
