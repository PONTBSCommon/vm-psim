var ctrlHeld = false;
var currentForm;

$(document).keydown(function(e) {
    if (e.ctrlKey) {
        ctrlHeld = true;
    }
});

$(document).keyup(function(e) {
    if (!e.ctrlKey) {
        ctrlHeld = false;
    }
});


$(document).on('click', '.list-group-item', function () {
    var multiSelect = $('.active').length > 1;
    //if they're not holding ctrl, make sure only one is active
    if (!ctrlHeld) {
        $('.active').not(this).removeClass('active');
    }

    //toggle active
    if($(this).hasClass('active')) {
        if (!multiSelect) {
            $(this).removeClass('active');
        }
    }
    else {
        $(this).addClass('active');
    }
});

$(function(){
    $('form').submit(function (e) {
        currentForm = this;

        $('#dialog-confirm').modal('show');

        return false;
    });
});

function dialogConfirmYES() {
    currentForm.submit();
}