$(function() {
    enableSslPort();
});


function enableSslPort() {
    var isChecked = $("#defaultIPPPortEnabled").is(':checked');

    if (isChecked) {
        $('#enableSSLLocalListener1').removeAttr('disabled');
        $('#defaultIPPPort').removeAttr('disabled');
    } else {
        $('#enableSSLLocalListener1').attr('disabled', 'disabled');
        $('#defaultIPPPort').attr('disabled', 'disabled');
    }

    isChecked = $("#additional1PortEnabled").is(':checked');

    if (isChecked)
    {
        $('#enableSSLLocalListener2').removeAttr('disabled');
        $('#additional1Port').removeAttr('disabled');
    }
    else {
        $('#enableSSLLocalListener2').attr('disabled', 'disabled');
        $('#additional1Port').attr('disabled', 'disabled');
    }

    isChecked = $("#additional2PortEnabled").is(':checked');

    if(isChecked) {
        $('#enableSSLLocalListener3').removeAttr('disabled');
        $('#additional2Port').removeAttr('disabled');
    }
    else {
        $('#enableSSLLocalListener3').attr('disabled', 'disabled');
        $('#additional2Port').attr('disabled', 'disabled');
    }
}