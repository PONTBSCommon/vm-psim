$(function() {
    $( "#accordion" ).accordion({
        heightStyle: "content"
    });
});

function setAndSubmit(printerNumber, printerName, serverName){
    $("#printerNumber").val(printerNumber);
    $("#mapToprintServerName").val(serverName);
    $("#mapToPrinterName").val(printerName);
    $("#mapForm").submit();
}