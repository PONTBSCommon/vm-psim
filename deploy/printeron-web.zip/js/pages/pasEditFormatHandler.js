/**
 * Created by bershaa on 1/16/2015.
 */

function showRecommendedDD(){
    $(".allApps").hide();
    $(".recommendedApps").show();
    $(".recommendedApps").attr("id", "handlerId");
    $(".recommendedApps").attr("name", "handlerId");

    $(".allApps").attr("id", "handlerId2");
    $(".allApps").attr("name", "handlerId2");
}

function showAllDD(){
    $(".allApps").show();
    $(".recommendedApps").hide();

    $(".allApps").attr("id", "handlerId");
    $(".allApps").attr("name", "handlerId");

    $(".recommendedApps").attr("id", "handlerId2");
    $(".recommendedApps").attr("name", "handlerId2");

}



function showLoading(){
    $("#spinner").show();
    $("#editHandlerPanel").hide();
}

$(function(){
    if($("#showRecommended").val() != "true"){
        showAllDD();
        $(".allApps").val($("#handlerId-hidden").val());
    }
});