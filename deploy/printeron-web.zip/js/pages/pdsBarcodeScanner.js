/**
 * Created by bershaa on 4/6/2016.
 */
var bound;

$(document).ready(function(){
    dtLoad("#scannerTable", {
        serverSide: true,
        ajax: {
            "url" : 'list/'
        },
        select: {
            "style": 'single'
        },
        columns: [
            {data: "entry"}
        ],
        rowId: "entry",
        initComplete: function( settings )
        {
            bound = $("#boundScannerName").val();

            if(bound.length > 0)
            {
                if(bound != "error")
                {
                    $("#" + bound).click();
                    $("#scannerBound").show();
                    $("#bindScannerButton").hide();
                }
                else
                {
                    $("#scannerUnbound").show();
                    $("#bindScannerButton").show();
                    $("#bindScannerPanel").show();
                    $("#driverName").text($("#noConnectMsg").val());
                    showHideButtons();
                }
            }
        },
        ordering: false,
        searching: false,
        lengthChange: false,
        selectableRows: true,
        multiSelectRows: false
    });

    $("#scannerTable").on("draw.dt", function () {
        $("#scannerTable").find("tr").off('click', getScannerEntry);
        $("#scannerTable").find("tr").on('click', getScannerEntry);
    });

    $("#driverLocationOld").val($("#driverLocation").val());
});

var driverName;

function getScannerEntry()
{
    driverName = $("#scannerTable").find("tr.selected").find("td").html();

    $("#bindScannerPanel").show();
    $("#driverName").text(driverName);

    showHideButtons();
}

function showHideButtons()
{
    if(bound != driverName)
    {
        $("#scannerBound").hide();
        $("#bindScannerButton").show();
        $("#unbindScannerButton").hide();
        $("#scannerUnbound").show();
        $("#testScannerButton").hide();
        $("#testResult").hide();
    }
    else
    {
        $("#scannerBound").show();
        $("#unbindScannerButton").show();
        $("#bindScannerButton").hide();
        $("#scannerUnbound").hide();
        $("#testScannerButton").show();
    }
}

function bindScanner()
{
    ajax({
        type: "POST",
        url: window.location.pathname + "/bindScanner",
        data: { scannerDriver : driverName },
        success: function (response) {
            if(response == "true")
            {
                notifySuccess($("#boundMsg").val());
                bound = driverName;
                showHideButtons();
            }
            else
            {
                notifyError($("#boundMsgFailure").val());
                showHideButtons();
            }
        },
        error: function() {
            notifyError("Error during bind");
        }
    });
}

function unbindScanner()
{
    ajax({
        type: "POST",
        url: window.location.pathname + "/unbindScanner",
        data: { scannerDriver : driverName },
        success: function (response) {
            notifySuccess($("#unboundMsg").val());
            bound = "";
            showHideButtons();
        },
        error: function() {
            notifyError("Error during bind");
        }
    });
}

function testScanner()
{
    $("#testResultText").text($("#inProgress").val());
    $("#testResult").show();

    ajax({
        type: "POST",
        url: window.location.pathname + "/testScanner",
        data: { scannerDriver : driverName },
        success: function (response)
        {
            if(response == "1")
                $("#testResultText").text($("#testFailed").val());
            else if(response == "2")
                $("#testResultText").text($("#testFailedTimeout").val());
            else
                $("#testResultText").text(response);
        },
        error: function()
        {
            $("#testResultText").text("Error during test");
        }
    });
}

function saveDriversLocationPrompt()
{
    $("#save-confirm").modal("show");
    $("#actionBlurb").text($("#changeLocationMsg").val());

    $("#saveButton").unbind();
    $("#saveButton" ).click(saveDriversLocation);

    return false;
}

function detectDriversPrompt()
{
    $("#save-confirm").modal("show");
    $("#actionBlurb").text($("#detectDriversMsg").val());

    $("#saveButton").unbind();
    $("#saveButton").click(detectDrivers);

    return false;
}

/**
 * Starts progress on a button.
 *
 * @param button The button jquery object, or a selector
 */
function startSpinnerOnButton(button) {

    // Wrap in a jquery selector so you can pass a selector or an object
    button = $(button);

    var l = _getLaddaButtonObject(button);

    if(l) {
        l.ladda("start");
    }
}

/**
 * Initializes ladda support on a button.
 *
 * @param button The button jquery object.
 * @returns {*} Ladda object.
 * @private
 */
function _getLaddaButtonObject(button) {

    // Cannot get ladda button object for a button that's hidden (The height is used to specify spinner size)
    if(button.height() && button.height() > 0) {

        var id = button.attr("id");

        if (!id) {
            console.log("Cannot get a Ladda object for a button without an ID");
            return null;
        }

        // Not in the buttons array, add it on
        if (!_laddaButtons[id]) {

            // Add the required attributes
            _addButtonAttributes(button);

            // Add it to the map
            _laddaButtons[id] = button.ladda();
        }

        return _laddaButtons[id];
    }

    return null;
}

/**
 * Stops the spinner on a button.
 *
 * @param button The button jquery object or selector.
 */
function stopSpinnerOnButton(button) {

    // Wrap in a jquery selector so you can pass a selector or an object
    button = $(button);

    var l = _getLaddaButtonObject(button);

    if(l) {
        l.ladda("stop");
    }
}

function isPdsReconnected()
{
    ajax({
        type: "POST",
        url: window.location.pathname + "/isPdsReconnected",
        success: function (response) {
            if (response == true)
            {
                $("#save-confirm").modal("hide");

                setTimeout(function(){window.location.reload(true); }, 1);
            }
        },
        error: function()
        {
        }
    });
}

function saveDriversLocation()
{
    ajax({
        type: "POST",
        url: window.location.pathname + "/saveDriversLocation",
        beforeSend: function () {
            startSpinnerOnButton("#saveButton");
        },
        data:
        {
            driversLocation : $("#driverLocation").val(),
            oldLocation : $("#driverLocationOld").val()
        },
        success: function (response)
        {
            interval = setInterval(isPdsReconnected, 5000);
        },
        error: function()
        {
            notifyError($("#couldNotCreateDirectory").val());
            $("#save-confirm").modal("hide");
        }
    });
}

var interval;
function detectDrivers()
{
    ajax({
        type: "POST",
        url: window.location.pathname + "/detectDrivers",
        beforeSend: function () {
            startSpinnerOnButton("#saveButton");
        },
        data:
        {
            driversLocation : $("#driverLocation").val(),
        },
        success: function (response)
        {
            interval = setInterval(isPdsReconnected, 5000);
        },
        error: function()
        {
            notifyError($("#settingsError").val());
        }
    });
}