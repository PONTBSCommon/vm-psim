/**
 * Created by bershaa on 10/5/2015.
 */

var releaseCode = -1;
var printerNum = 0;

$(function(){
    dtErrorMode("throw");

    // Get the printer number
    printerNum = $("#printerNum").val();

    // Initialize datatable
    dtLoad('#queueMonitorTable', {

        "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
            decorateRow(nRow);
            return nRow;
        },
        tableTools: {
            "sRowSelect": "single"
        },
        searching: false,
        ajax:  window.location.pathname + "/jobs?releaseCode=" + releaseCode,
        "columns": [
            { "data": "jobId" },
            { "data": "documentName" },
            { "data": "fileSize" },
            { "data": "timeReceived" },
            { "data": "userEmail" },
            { "data": "statusText" },
            { "data": "pages" },
            { "data": "PTID" }
        ]
        ,
        "order": [[ 3, "desc" ]]
    });


    $('#button').click( function () {
        table.row('.selected').remove().draw(false);
    } );

    $('#queueMonitorTable tbody').on( 'click', 'tr', function () {
        $(this).toggleClass('selected');

        var table = $('#queueMonitorTable').DataTable();
        var data = table.rows('.selected').data();
        var printable = false;
        var deleteable = false;
        var pauseable = false;

        for(var i = 0; i < data.length; i++){
            if(!printable)
                printable = data[i].printable || data[i].reprintable;

            if(!deleteable)
                deleteable = data[i].deleteable;

            if(!pauseable)
                pauseable = data[i].pauseable;
        }

        if(printable)
            $("#printButton").removeAttr("disabled");
        else
            $("#printButton").attr("disabled", true);

        if(deleteable)
            $("#deleteButton").removeAttr("disabled");
        else
            $("#deleteButton").attr("disabled", true);
    } );
});


function populateReleaseCode()
{
    releaseCode = $('#releaseCode').val();

    var table = $('#queueMonitorTable').DataTable();

    var releaseUrl = $("#releaseCodeUrl").attr("href");

    $("#releaseCodeUrl").attr("href", releaseUrl + releaseCode);

    return true;
}

function decorateRow(row) {
    $(row).children().each(function(index, td){
        if ($(td).html().length > 20) {
            if($(td).html().indexOf("glyphicons") < 0) {
                var truncated = $(td).html().substring(0, 20);
                truncated += "...";
                $(td).html(truncated + "<span title=\"" + $(td).html() + "\" class='more-bottom glyphicons glyphicons-more'></span>");
            }
        }
    });
}

function refresh(){
    notifyInfo($("#refreshingJobs").val());
    var table = $('#queueMonitorTable').DataTable();

    table.ajax.reload(function(json) {});

    $("#printButton").attr("disabled", true);
    $("#deleteButton").attr("disabled", true);
}

function printJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].printable || data[i].reprintable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : CONTEXT + '/mfp/jobs/print',
        data : "jobIds=" + ids + "&printerNum=" + printerNum,
        success : function(response) {
            notifyInfo($("#printingJobs").val());
            refresh();
        },
        error : function(e) {

        }
    });
}

function deleteJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].deleteable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : CONTEXT + '/mfp/jobs/delete',
        data : "jobIds=" + ids,
        success : function(response) {
            refresh();
        },
        error : function(e) {

        }
    });
}

function pauseJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].pauseable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : CONTEXT + '/mfp/jobs/pause',
        data : "jobIds=" + ids,
        success : function(response) {
            refresh();
        },
        error : function(e) {

        }
    });
}