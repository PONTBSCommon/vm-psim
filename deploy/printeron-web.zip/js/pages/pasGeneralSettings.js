/**
 * Created by bershaa on 12/22/2014.
 */

var loggingEnabled = false;
var useLicenseServerBool = false;

$(function(){
    loggingEnabled = $("#loggingEnabled").prop('checked');

    $("#loggingPanel :input").attr("disabled", !loggingEnabled);


    $('#loggingEnabled').click(function (){
        $("#loggingPanel :input").attr("disabled", loggingEnabled);
        loggingEnabled = !loggingEnabled;
    });

    useLicenseServerBool = $("#useLicenseServerBool").prop('checked');

    $("#licenseServerPanel :input").attr("disabled", !useLicenseServerBool);


    $('#useLicenseServerBool').click(function (){
        $("#licenseServerPanel :input").attr("disabled", useLicenseServerBool);
        useLicenseServerBool = !useLicenseServerBool;
    });

    $( document ).tooltip();
});