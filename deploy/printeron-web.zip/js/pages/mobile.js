var qrCode;
var docApiUrl = $("#docApiUrlInput");

$(document).ready(function () {
   useAjaxForForm("#mobileForm",{
      success: function(data) {
         $(".errorMessage").hide();
         $("#docApiUrlInput").removeClass("error");
         notifySuccess(data);
      },
      error: function () {
         $(".errorMessage").show();
      }
      });
   var el = document.getElementById("qrCodeWrapper");

   var options = {
      text: getQrLink(),
      height: 100,
      width: 100
   };

   qrCode = new QRCode(el, options);

   $("#qrDefault").change(function () {
      updateQrCode();
   });

   /**
    * On click for drop down select of docApi url.
    */
   $(".docApiUrlSelectLink").click(function() {

      // Replace the value in the api input field
      docApiUrl.val(this.innerHTML + $("#cpsSuffix").val());
      docApiUrl.trigger("change");
   });

   $("#overrideDocApiUrl").change(toggleDocApiUrl);

   docApiUrl.change(updateQrCode);

   toggleDocApiUrl();
});

function toggleDocApiUrl () {
   if ($("#overrideDocApiUrl").is(":checked")) {
      $(".docApiUrlGroup").prop("disabled", false);
   }
   else {
      docApiUrl.val($("#externalServiceUri").val());
      docApiUrl.trigger("change");

      $(".docApiUrlGroup").prop("disabled", true);
   }
}

function getQrLink () {
   var sdef = $("#qrDefault").is(":checked") ? 1 : 0;
   return "pon://?surl=" + docApiUrl.val() + "&sdef=" + sdef + "&sauth=" + $("#qrAuth").val();
}

function updateQrCode () {
   qrCode.clear();
   qrCode.makeCode(getQrLink());
}