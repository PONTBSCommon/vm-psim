/**
 * Created by oliveib on 11/21/2016.
 */
$(document).ready(function ()
{
    dtLoad("#actors-table", {
        ajax: {
            url: CONTEXT + "/users/accessControl/list"
        },
        serverSide: true,
        columns: [
            {data: "actor"},
            {data: "actorType"}
        ],
        selectableRows: true,
        multiSelectRows: false
    });

});