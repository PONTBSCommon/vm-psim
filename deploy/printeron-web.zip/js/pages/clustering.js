//default values
var defaultProcessingPort = 5200;
var defaultStatusPort = 5400;

//lookup variables for the two select boxes
var pasSelect = $("#selectedPas");
var modalSelect = $("#modalSelectedPas");

//lookup variables for main form
var serverStateBool = $("#serverStateBool");
var serverAddress = $("#serverAddress");
var serverPort = $("#serverPort");
var serverSerialNumber = $("#serverSerialNumber");
var serverSerialNumberWrapper = $("#serverSerialNumberWrapper");
var addModal = $("#addDialog");
var deleteModal = $("#deleteConfirm");

//control variables
var addType;
var deleteType;
var action;
var currentIndex;
var editUUID;
var deleteUUID;

$(document).ready(function () {
    $('#modalSelectedPas option:eq(1)').prop("selected", true);

    pasSelect.change(togglePanels);

    modalSelect.change(fillModalFields);

    dtLoad($("#processing_table"), {
        fnRowCallback: function( nRow, aData, index ) { return decorateRow(nRow, aData, index); },
        serverSide: true,
        ajax: {
            "url" : CONTEXT + '/clustering/processing/' + pasSelect.val() + '/list'
        },
        columns: [
            {data: "serverStateBool"},
            {data: "serverAddress"},
            {data: "serverPort"},
            {data: "serverSerialNumber"},
            {data: "serverAddress"},
            {data: "serverAddress"}
        ],
        selectableRows: true,
        multiSelectRows: true,
        moveableRows: true
    });

    $("#processing_table").on("dt-rows-moved", function () {
        $("#processing_table_save_order").attr("disabled", false);
    });

    $("#processing_table_save_order").click(function () {
       ajax({
           url: CONTEXT + "/clustering/processing/" + pasSelect.val() + "/saveOrder",
           method: "POST",
           data: dtGetTableParamsForAjax($("#processing_table")),
           success: function (data) {
               $("#processing_table_save_order").attr("disabled", true);
               notifySuccess(data);
           }
       })
    });

    togglePanels();

    dtLoad($("table").not("#processing_table"));
});

function decorateRow(nRow, aData, index)
{
    var uuid = $("#selectedPas").val();
    var idPrefix = "processing_" + uuid + "_list" + index;

    $(nRow).data("index", index);
    $(nRow).attr("id", uuid + "_" + index + "_processing");

    decorateEnabledColumn($("td:eq(0)", nRow), idPrefix, aData['serverStateBool'], index);
    decorateServerNameColumn($("td:eq(1)", nRow),idPrefix, aData['serverAddress']);
    decorateServerPortColumn($("td:eq(2)", nRow),idPrefix, aData['serverPort']);
    decorateSerialNumberColumn($("td:eq(3)", nRow),idPrefix, aData['serverSerialNumber']);
    decorateEditColumn($("td:eq(4)", nRow), uuid, index);
    decorateDeleteColumn($("td:eq(5)", nRow), uuid, index);
}

function decorateSerialNumberColumn(elem, idPrefix, serialNumber) {
    elem.html("<span id=\"" + idPrefix + "-serverSerialNumber\">" + serialNumber + "</span>");
}

function decorateServerPortColumn(elem, idPrefix, serverPort) {
    elem.html("<span id=\"" + idPrefix + "-serverPort\">" + serverPort + "</span>");
}

function decorateServerNameColumn(elem, idPrefix, serverAddress) {
    elem.html("<span id=\"" + idPrefix + "-serverAddress\">" + serverAddress + "</span>");
}

function decorateEnabledColumn (elem, idPrefix, enabled, index) {
    var html = "";

    if (enabled) {
        html += "<input type='checkbox' id='" + idPrefix +"-serverStateBool' checked disabled/>";
    }
    else {
        html += "<input type='checkbox' id='" + idPrefix +"-serverStateBool' disabled/>";
    }

    html += "<label for=\"processing_list" + index + "\"></label>";

    elem.html(html);
}

function decorateEditColumn (elem, pasUuid, index) {
    elem.html("<a id=\"processing_" + pasUuid + "_list" + index + "-edit\" onclick=\"showEditDialogProcessing('" + pasUuid + "'," + index + ")\" class=\"btn btn-default\">" + $("#editButtonText").val() + "</a>");
}

function decorateDeleteColumn (elem, pasUuid, index) {
    elem.html("<a id=\"processing_" + pasUuid + "_list" + index + "-delete\" type=\"button\" class=\"btn btn-danger\" onclick=\"confirmDeleteProcessor('" + pasUuid + "'," + index + ")\">" + $("#deleteButtonText").val() + "</a>");
}

function togglePanels () {
    var uuid = pasSelect.val();

    $("#processing_table_save_order").prop("disabled", true);

    $(".pasWrapper").hide();
    $("#wrapper_"+uuid).show();

    dtUnloadUUID($("#processing_table"));
    $("#processing_table").DataTable().ajax.url(CONTEXT + '/clustering/processing/' + pasSelect.val() + '/list');
    dtRedraw(true, "#processing_table");
}

function showAddDialogStatus () {
    addType = "status";
    action = "add";

    $(".clustering-status").show();
    $(".clustering-processing").hide();
    $(".clustering-edit").hide();
    $(".clustering-add").show();

    fillModalFields();

    modalSelect.show();
    addModal.modal("show");
}

function showAddDialogProcessing () {
    addType = "processing";
    action = "add";

    $(".clustering-status").hide();
    $(".clustering-processing").show();
    $(".clustering-edit").hide();
    $(".clustering-add").show();

    fillModalFields();

    modalSelect.show();
    addModal.modal("show");
}

function showEditDialogStatus (uuid, index) {
    addType = "status";
    action = "edit";
    currentIndex = index;
    editUUID = uuid;

    $(".clustering-edit").show();
    $(".clustering-status").show();
    $(".clustering-processing").hide();
    $(".clustering-add").hide();

    fillModalFieldsFromRow(uuid, index);

    addModal.modal("show");
}

function showEditDialogProcessing (uuid, index) {
    addType = "processing";
    action = "edit";
    currentIndex = index;
    editUUID = uuid;

    $(".clustering-status").hide();
    $(".clustering-processing").show();
    $(".clustering-edit").show();
    $(".clustering-add").hide();

    fillModalFieldsFromRow(uuid, index);

    addModal.modal("show");
}

/**
 * Fills the modal with the information from the selected row
 * @param uuid The PAS UUID
 * @param index The index of the connection
 */
function fillModalFieldsFromRow(uuid, index) {
    if (addType == "status") {
        serverStateBool.attr("checked", $("#status_" + uuid + "_list" + index + "-serverStateBool").is(":checked"));
        serverAddress.val($("#status_" + uuid + "_list" + index + "-serverAddress").html());

        serverSerialNumber.val("");
        serverSerialNumberWrapper.hide();

        serverPort.val($("#status_" + uuid + "_list" + index + "-serverPort").html());
    }
    else {
        serverStateBool.attr("checked", $("#processing_" + uuid + "_list" + index + "-serverStateBool").is(":checked"));
        serverAddress.val($("#processing_" + uuid + "_list" + index + "-serverAddress").html());
        serverSerialNumber.val($("#processing_" + uuid + "_list" + index + "-serverSerialNumber").html());

        serverPort.val($("#processing_" + uuid + "_list" + index + "-serverPort").html());
        serverSerialNumberWrapper.show();
    }
}

/**
 * Fills the modal fields based off the data attributes on the select box inside of the modal
 */
function fillModalFields () {
    if (modalSelect.val() == "new") {
        serverStateBool.attr("checked", true);
        serverAddress.val("");
        serverSerialNumber.val("");
        serverPort.val("");

        $(".clustering-add").hide();
        $(".clustering-manual").show();

        if (addType == "status") {
            serverPort.val(defaultStatusPort);
            serverSerialNumberWrapper.hide();
        }
        else {
            serverPort.val(defaultProcessingPort);
            serverSerialNumberWrapper.show();
        }
    }
    else {
        $(".clustering-manual").hide();
        $(".clustering-add").show();
    }
}

/**
 * Function that sends the add request to the backend
 */
function addDialogYES() {
    var url;
    var data = {};
    var serverSerialNumberValue = serverSerialNumber.val();

    if (addType == "status") {
        url = CONTEXT + "/clustering/status/" + pasSelect.val() + "/add";
        serverSerialNumberValue = "na";
    } else {
        url = CONTEXT + "/clustering/processing/" + pasSelect.val() + "/add";
    }

    if(modalSelect.val() == "new") {
        url += "/manual";

        data.serverStateBool = serverStateBool.is(":checked");
        data.serverAddress = serverAddress.val();
        data.serverPort = serverPort.val();
        data.serverSerialNumber = serverSerialNumberValue;
    }
    else {
        data.sourceUUID = modalSelect.val();
        data.useHostName = $("#useHostName").is(":checked");
        data.reciprocate = $("#reciprocate").is(":checked");
    }

    ajax({
        url: url,
        type: "POST",
        data: data,
        success: function (resp) {
            notifySuccess($("#settingsSavedMessage").val());
            addModal.modal("hide");

            if (addType == "status") {
                generateRowsFromJSON(JSON.parse(resp));
            }
            else {
                dtUnloadUUID($("#processing_table"));
                dtRedraw(false, "#processing_table");
            }
        },
        error: function(xhr) {
            if (xhr.status == 400) {
                var errors = JSON.parse(xhr.responseText);
                for (var error in errors) {
                    addErrorToField($("#" + errors[error].field), errors[error].error);
                }
            }
            else {
                notifyError(xhr.responseText);
            }
        }
    });
}

/**
 * Function that updates the information in the backend
 */
function editDialogYES() {
    var url;

    var serverSerialNumberValue = serverSerialNumber.val();

    if (addType == "status") {
        url = CONTEXT + "/clustering/status/" + editUUID + "/edit";
        serverSerialNumberValue = "na";
    } else {
        url = CONTEXT + "/clustering/processing/" + editUUID + "/edit";
    }

    ajax({
        url: url,
        type: "POST",
        data: {
            serverStateBool: serverStateBool.is(":checked"),
            serverAddress: serverAddress.val(),
            serverPort: serverPort.val(),
            serverSerialNumber: serverSerialNumberValue,
            index: currentIndex
        },
        success: function () {
            notifySuccess($("#settingsSavedMessage").val());
            if (addType == "status") {
                updateRowFromModelFields(editUUID, currentIndex, addType);
            }
            else {
                dtUnloadUUID($("#processing_table"));
                dtRedraw(false, "#processing_table");
            }
            addModal.modal("hide");
        },
        error: function(xhr) {
            if (xhr.status == 400) {
                var errors = JSON.parse(xhr.responseText);
                for (var error in errors) {
                    addErrorToField($("#" + errors[error].field), errors[error].error);
                }
            }
            else {
                notifyError(xhr.responseText);
            }
        }
    });
}

/**
 * Sets up values then brings up the confirm delete modal
 * @param uuid PAS Modal
 * @param index Index of the connection
 */
function confirmDeleteStatus(uuid, index) {
    deleteType = "status";
    deleteUUID = uuid;
    currentIndex = index;

    $(".clustering-status").show();
    $(".clustering-processing").hide();

    deleteModal.modal("show");
}

/**
 * Sets up values then brings up the confirm delete modal
 * @param uuid PAS Modal
 * @param index Index of the connection
 */
function confirmDeleteProcessor(uuid, index) {
    deleteType = "processing";
    deleteUUID = uuid;
    currentIndex = index;

    $(".clustering-status").hide();
    $(".clustering-processing").show();

    deleteModal.modal("show");
}

/**
 * Sends the delete request to the backend
 */
function deleteConfirmYES() {
    var url;

    if (deleteType == "status") {
        url = CONTEXT + "/clustering/status/" + deleteUUID + "/delete";
    } else {
        url = CONTEXT + "/clustering/processing/" + deleteUUID + "/delete";
    }

    ajax({
        url: url,
        type: "POST",
        data: {
            index: currentIndex
        },
        success: function (resp) {
            notifySuccess(resp);
            if (deleteType != "status") {
                dtUnloadUUID($("#processing_table"));
                dtRedraw(false, "#processing_table");
            }
            else {
                deleteRow(deleteUUID, currentIndex, deleteType);
            }
            deleteModal.modal("hide");
        },
        error: function(xhr) {
            notifyError(xhr.responseText);
        }
    });
}

/**
 * Takes the returned JSON from an add response and puts it into its respective data table
 * @param json The JSON from the add response
 */
function generateRowsFromJSON(json)
{
    for (var uuid in json) {
        var table = $("#"+uuid + "_" + addType + "_table");
        var index = dtGetRowCount(table);

        var row = "<tr id='" + uuid + "_" + index + "_" + addType + "' data-index='" + index + "'>";

        var checked = json[uuid].serverStateBool ? 'checked' : '';
        var prefix = addType + "_" + uuid + "_list" + index;

        row += "<td class='col-md-1'><input id='" + prefix + "-serverStateBool' type='checkbox' value='" + json[uuid].serverStateBool + "' " + checked + " disabled='true'/><label for='" + addType + "_" + pasSelect.val() + "_list" + index + "-serverStateBool'></label></td>";


        if (addType == "processing") {
            row += "<td class='col-md-2'><span id='" + prefix + "-serverAddress'>" + json[uuid].serverAddress + "</span></td>";
            row += "<td class='col-md-2'><span id='" + prefix + "-serverPort'>" + json[uuid].serverPort + "</span></td>";
            row += "<td class='col-md-2'><span id='" + prefix + "-serverSerialNumber'>" + json[uuid].serverSerialNumber + "</span></td>";
            row += "<td class='col-md-1'><a id='" + prefix + "-edit' onclick=\"showEditDialogProcessing('" + uuid + "', " + index + ")\" class='btn btn-default'>" + $("#editButtonText").val() + "</a></td>";
            row += "<td class='col-md-1'><a id='" + prefix + "-delete' type='button' class='btn btn-danger' onclick=\"confirmDeleteProcessor('" + uuid + "', " + index + ")\">" + $("#deleteButtonText").val() + "</a></td>";
        }
        else {
            row += "<td class='col-md-3'><span id='" + prefix + "-serverAddress'>" + json[uuid].serverAddress + "</span></td>";
            row += "<td class='col-md-2'><span id='" + prefix + "-serverPort'>" + json[uuid].serverPort + "</span></td>";
            row += "<td class=col-md-1'><a id='" + prefix + "-edit' onclick=\"showEditDialogStatus('" + uuid + "', " + index + ")\" class='btn btn-default'>" + $("#editButtonText").val() + "</a>";
            row += "<td class=col-md-1'><a id='" + prefix + "-delete' type='button' class='btn btn-danger' onclick=\"confirmDeleteStatus('" + uuid + "', " + index + ")\">" + $("#deleteButtonText").val() + "</a>";
        }

        row += "</tr>";

        dtAddRow(row, table);
    }
}

/**
 * Function to update the values of a row based on what was entered into the modal
 *
 * @param uuid PAS UUID
 * @param index Index of the connection
 * @param type Status or Processing
 */
function updateRowFromModelFields (uuid, index, type) {
    var prefix = type + "_" + uuid + "_list" + index;

    $("#" + prefix + "-serverStateBool").attr("checked", serverStateBool.is(":checked"));
    $("#" + prefix + "-serverAddress").html(serverAddress.val());
    $("#" + prefix + "-serverPort").html(serverPort.val());
    if (type == "processing") {
        $("#" + prefix + "-serverSerialNumber").html(serverSerialNumber.val());
    }
}

/**
 * Removes a row from the datatable and updates the indexes of the remaining rows
 *
 * @param uuid PAS UUID
 * @param index Index of the connection
 * @param type Status or Processing
 */
function deleteRow (uuid, index, type) {
    var table = $("#" + uuid + "_" + type + "_table");

    dtRemoveRow($("#" + uuid + "_" + index + "_" + type), table);

    var rows = dtGetAllRows(table);

    $(rows).each(function () {
        var rowIndex = $(this).data("index");

        if (parseInt(rowIndex) > index) {
            var newIndex = parseInt(rowIndex) - 1;
            var prefix = type + "_" + uuid + "_list" + rowIndex;
            var newPrefix = type + "_" + uuid + "_list" + newIndex;
            var row = $("#" + uuid + "_" + rowIndex + "_" + type);
            var editButton = $("#" + prefix + "-edit");
            var deleteButton = $("#" + prefix + "-delete");

            row.data("index", newIndex);
            row.attr("id", uuid + "_" + newIndex + "_" + type);
            $("#" + prefix + "-serverStateBool").attr("id", newPrefix + "-serverStateBool");
            $("#" + newPrefix + "-serverStateBool + label").attr("for", newPrefix + "-serverStateBool");
            $("#" + prefix + "-serverAddress").attr("id", newPrefix + "-serverAddress");
            $("#" + prefix + "-serverPort").attr("id", newPrefix + "-serverPort");

            if (type == "processing") {
                $("#" + prefix + "-serverSerialNumber").attr("id", newPrefix + "-serverSerialNumber");
                editButton.attr("onclick", "showEditDialogProcessing('" + uuid + "', " + newIndex + ")");
                deleteButton.attr("onclick", "confirmDeleteProcessor('" + uuid + "', " + newIndex + ")");
            }
            else {
                editButton.attr("onclick", "showEditDialogStatus('" + uuid + "', " + newIndex + ")");
                deleteButton.attr("onclick", "confirmDeleteStatus('" + uuid + "', " + newIndex + ")");
            }

            editButton.attr("id", newPrefix + "-edit");
            deleteButton.attr("id", newPrefix + "-delete");
        }
    });

    dtRedraw(table);
}