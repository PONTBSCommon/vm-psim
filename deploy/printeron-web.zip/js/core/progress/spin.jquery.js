/**
 * Copyright (c) 2011-2014 Felix Gnass
 * Licensed under the MIT license
 */

/*

 Basic Usage:
 ============

 $('#el').spin(); // Creates a default Spinner using the text color of #el.
 $('#el').spin({ ... }); // Creates a Spinner using the provided options.
 $('#el').spin(false); // Stops and removes the spinner.
 */

(function(factory) {

    if (typeof exports == 'object') {
        // CommonJS
        factory(require('jquery'), require('spin.js'))
    }
    else if (typeof define == 'function' && define.amd) {
        // AMD, register as anonymous module
        define(['jquery', 'spin'], factory)
    }
    else {
        // Browser globals
        if (!window.Spinner) throw new Error('Spin.js not present')
        factory(window.jQuery, window.Spinner)
    }

}(function($, Spinner) {

    $.fn.spin = function(opts, color) {

        return this.each(function() {

            var $this = $(this),
                data = $this.data();

            if (data.spinner) {
                data.spinner.stop();
                delete data.spinner;
            }
            if (opts !== false) {
                opts = $.extend({ color: color || $this.css('color') }, opts);
                data.spinner = new Spinner(opts).spin(this)
            }
        })
    };
}));