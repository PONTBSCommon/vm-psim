/**
 * Defines notification helper functions.
 *
 * @author Lukas Rezek <lrezek@printeron.com>
 */
var maxTop;

$(document).ready(function() {
    if ($(".divide-nav").length) {
        maxTop = 100;
    }
    else {
        maxTop = 50;
    }

    $(window).scroll(function () {
        updateNotifCSS();
    });
});

function updateNotifCSS() {
    var notifContainer =  $(".notifyjs-corner");

    if (notifContainer.length) {
        var top = $(window).scrollTop();
        var newTop = top >= maxTop ? 0 : maxTop;

        notifContainer.css("top", newTop + "px");
        notifContainer.css("position", "fixed");
    }
}

// Add notify style
$.notify.addStyle("xButton", {
    html: "<div><span data-notify-text/>&nbsp;&nbsp;<span class='notify-glyph-push cancel-notifyjs pointer glyphicons glyphicons-remove'></span></div>"
});

// Add onclick removal
$(document).on("click", ".cancel-notifyjs", function () {
    $(".notifyjs-container").trigger("notify-hide");
});

// If you have a save success value, show the success notif
$(function() {

    var subMenuId = $("#currentSubmenu").val();
    $("#" + subMenuId).addClass("active");

    var menuId = $("#mainMenu").val();
    $("#" + menuId).addClass("active");

    $(document).tooltip();

    if ($('#saveSuccess').length > 0)
    {
        $.notify($("#saveSuccess").val(), {style: "xButton", className: "success", autoHide: true, autoHideDelay: 5000, clickToHide: false, position: "bottom right", arrowShow: false});
        updateNotifCSS()
    }

    if ($('#saveWarning').length > 0)
    {
        $.notify($("#saveWarning").val(), {style: "xButton", className: "warn", position: "top right", autoHide: false, clickToHide: false});
        updateNotifCSS()
    }
});

/**
 * Notifies the user of an error.
 *
 * @param message The message to display.
 * @param element The element to display the notification on (optional).
 * @param params The params for the notification (optional).
 */
function notifyError(message, element, params) {

    // Prepare default params
    var notifParams = {
        style: "xButton",
        className: "error",
        position: "top right",
        autoHide: false,
        clickToHide: false
    };

    // Show the notification
    _doNotification(message, notifParams, element, params);
}

/**
 * Notifies the user of a success.
 *
 * @param message The message to display.
 * @param element The element to display the notification on (optional).
 * @param params The params for the notification (optional).
 */
function notifySuccess(message, element, params) {

    // Prepare default params
    var notifParams = {
        style: "xButton",
        className: "success",
        autoHide: true,
        autoHideDelay: 5000,
        clickToHide: false,
        position: "top right",
        arrowShow: false
    };

    // Show the notification
    _doNotification(message, notifParams, element, params);
}

/**
 * Notifies the user of an informational message.
 *
 * @param message The message to display.
 * @param element The element to display the notification on (optional).
 * @param params The params for the notification (optional).
 */
function notifyInfo(message, element, params) {

    // Prepare default params
    var notifParams = {
        style: "xButton",
        className: "info",
        autoHide: true,
        autoHideDelay: 5000,
        clickToHide: false,
        position: "top right",
        arrowShow: false
    };

    // Show the notification
    _doNotification(message, notifParams, element, params);
}

/**
 * Notifies the user of a warning message.
 *
 * @param message The message to display.
 * @param element The element to display the notification on (optional).
 * @param params The params for the notification (optional).
 */
function notifyWarning(message, element, params) {

    // Prepare default params
    var notifParams = {
        style: "xButton",
        className: "warn",
        position: "top right",
        autoHide: false,
        clickToHide: false
    };

    // Show the notification
    _doNotification(message, notifParams, element, params);
}

/**
 * Method that does the actual notification.
 *
 * @param message The message to notify with.
 * @param params The params to use.
 * @param element The element to notify on (optional).
 * @param userParams The specified user params (optional).
 */
function _doNotification(message, params, element, userParams) {

    // Put the params together
    $.extend(params, userParams);

    // Do a notify on an element
    if(typeof element !== 'undefined' && $(element).length) {
        $(element).notify(message, params);

    // Do a notify on the page
    } else {
        $.notify(message, params);
    }

    updateNotifCSS();
}