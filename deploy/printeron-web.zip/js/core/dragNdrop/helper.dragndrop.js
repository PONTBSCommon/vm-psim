var __drag = null;

var __mouseDown = false;

$(document).ready(function () {
    $(document).on("mouseup", function () {
        __drag = null;
        __mouseDown = false;
        $(".drop-target-glow").removeClass("drop-target-glow");
        $("body").removeClass("disable-text-select");
    });
});

function registerDraggable (elem) {
    elem = $(elem);

    elem.on("mousedown", function () {
        __drag = $(this);
        __mouseDown = true;
        $("body").addClass("disable-text-select");
    });
}

function registerDroppable (elem) {
    elem = $(elem);

    elem.on("mouseup", function () {
        if (__drag !== null) {
            $(this).trigger("dragndrop-item-dropped", [{
                "drag": __drag,
                "drop": $(this)
            }])
        }
    });

    elem.on("mouseenter", function () {
        if (__mouseDown) {
            $(this).addClass("drop-target-glow");
        }
    });

    elem.on("mouseleave", function () {
        if (__mouseDown) {
            $(this).removeClass("drop-target-glow");
        }
    });
}