var currentForm;

$(function() {
    var displayText = $("#newKeyGenerated").val();
    var generated = getUrlParameter("generated");

    if(typeof generated != 'undefined') {
        notifySuccess(displayText);
    }

    currentForm = $("#securityForm");
});

function dialogConfirmYES()
{
    //Set Backup key Store flag
    $("#backupKeystore").val(true);

    currentForm.attr("action", $("#formAction").val() + "generate/");

    currentForm.submit();
}

function dialogConfirmNO() 
{
    //Set Backup key Store flag
    $("#backupKeystore").val(false);

    currentForm.attr("action", $("#formAction").val() + "generate/");

    currentForm.submit();
}


function generateNewKey(){
    $('#dialog-confirm').modal('show');
}


function getUrlParameter(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}