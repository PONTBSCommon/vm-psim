/**
 * Created by bershaa on 2/6/2015.
 */
$(function (){
    $( document ).tooltip();

    $( "#accordion" ).accordion({
        heightStyle: "content",
        collapsible: true,
        active: false
    });
});

function deleteData(){

    $("#delete-confirm").modal("hide");

    //TODO: Localize?
    notifyInfo("Deleting Data files...");

    ajax({
        type: "POST",
        url: window.location.pathname + "/deleteData",
        success: function (response) {

            notifySuccess(response);
        },
        error: function() {

            //TODO: Localize?
            notifyError("Error during test");
        }
    });

}

function migrateData() {
    if ($("#currentDataPath").val() == $("#dataPath").val()) {

        //TODO: localize?
        notifyInfo("You must change the data directory before migrating the files");
        return false;
    }

    // TODO: localize?
    notifyInfo("Migrating Data files...");

    ajax({
        type: "POST",
        url: window.location.pathname + "/migrateData",
        data:
        "newLocation=" + $("#dataPath").val(),
        success: function (response) {

            notifySuccess(response);
        },
        error: function() {

            // TODO: localize?
            notifyError("Error during test");
        }
    });

}

function deleteDataPrompt(){
    $("#delete-confirm").modal("show");
}
