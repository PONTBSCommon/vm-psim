/**
 * Created by bershaa on 4/30/2015.
 */

function testClusterPeer(){
    notifyInfo($("#testClusterPeer").val());

    ajax({
        url: window.location.pathname + "testClusterPeer",
        type: "POST",
        data:
        "requestUrl=" + $("#scheme").val() + "://" + $("#address").val() + ":" + $("#port").val(),
        success: function (response) {
            var res = response.split("|");

            if(res[0] == 1) {
                notifySuccess($("#" + res[1]).val());
            }
            else {
                notifyError($("#" + res[1]).val());
            }
        }
    })
}