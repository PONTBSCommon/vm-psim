$(document).ready( function () {

    dtErrorMode("throw");

    // Initialize datatable
    dtLoad('#queueMonitorTable', {

        fnRowCallback: function( nRow, aData, iDisplayIndex ) { return decorateRow(nRow, aData); },
        tableTools: { sRowSelect: "single" },
        selectableRows:true,
        multiSelectRows:true,
        processing: true,
        serverSide: true,
        ajax: {url: 'ajax/'},
        columns: [
            { data: "jobId" },
            { data: "PTID" },
            { data: "documentName" },
            { data: "fileSize" },
            { data: "timeReceived" },
            { data: "printerName", className: "printerName"},
            { data: "userEmail" },
            { data: "statusText" },
            { data: "pages" }
        ],
        order: [[ 4, "asc" ]]
    });

    $('#queueMonitorTable').on( 'dt.selection.updated', enableDisableButtons );
} );

function enableDisableButtons () {
    ajax({
        url: CONTEXT + "/printers/jobs/buttonState",
        method: "GET",
        data: dtGetTableParamsForAjax("#queueMonitorTable"),
        success: function (data) {
            if(data['printable'])
                $("#printButton").removeAttr("disabled");
            else
                $("#printButton").attr("disabled", true);

            if(data['deleteable'])
                $("#deleteButton").removeAttr("disabled");
            else
                $("#deleteButton").attr("disabled", true);

            if(data['pauseable'])
                $("#pauseButton").removeAttr("disabled");
            else
                $("#pauseButton").attr("disabled", true);
        }
    });
}

function decorateRow(row, data) {

    // Truncate all long columns
    $(row).children().each(function(index, td){
        if ($(td).html().length > 20) {
            if($(td).html().indexOf("glyphicons") < 0) {
                var truncated = $(td).html().substring(0, 20);
                $(td).html(truncated + "<span title=\"" + $(td).html() + "\" class='more-bottom glyphicons glyphicons-more'></span>");
            }
        }
    });

    var date = new Date(0);
    date.setUTCMilliseconds(data['timeReceived']);

    //Format the EDT time format in local time
    $("td:eq(3)", row).html(date.toLocaleString());

    // Update printer name field to a link
    var printerName = $("td.printerName", row);
    printerName.html("<a href='" + CONTEXT + "/printers/?goToPrinter=" + data["printeronID"] + "'>" + printerName.html() + "</a>");

    return row;
}

function setAndSubmit(printJobId, actionType){
    $("#printJobId").val(printJobId);
    $("#actionType").val(actionType);
    $("#queuemonitor").submit();
}

function refresh(){
    var table = $('#queueMonitorTable');

    dtUnloadUUID(table);
    dtRedraw(false, table);

    table.one("dt.ajax.complete", enableDisableButtons);
}

function savePrintMode(){

    ajax({
        type : "POST",
        url : window.location.pathname + "/saveprintmode",
        data : "printMode=" + $('#printModeType').val(),
        success : function(response) {
            refresh();
        },
        error : function(e) {

        }
    });
}

function printJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].printable || data[i].reprintable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : window.location.pathname,
        data : "jobIds=" + ids + "&actionType=print",
        success : function(response) {
            refresh();
        },
        error : function(e) {

        }
    });

    refresh();
}

function deleteJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].deleteable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : window.location.pathname,
        data : "jobIds=" + ids + "&actionType=delete",
        success : function(response) {
            refresh();
        },
        error : function(e) {

        }
    });

    refresh();
}

function pauseJobs(){
    var table = $('#queueMonitorTable').DataTable();
    var data = table.rows('.selected').data();
    var ids;
    var count = 0;
    for(var i = 0; i < data.length; i++) {
        if (data[i].pauseable)
        {
            if(count == 0){
                ids = data[i].jobId;
            }else{
                ids = ids + "," + data[i].jobId;
            }
            count++;
        }
    }

    ajax({
        type : "POST",
        url : window.location.pathname,
        data : "jobIds=" + ids + "&actionType=pause",
        success : function(response) {
            refresh();
        },
        error : function(e) {

        }
    });

    refresh();
}