var isDelete = false;
var isShare = false;
var isSave = false;
var isRename = false;

var googleEmail = $("#googleEmail");
var googlePassword = $("#googlePassword");
var buttonsToDisable = $(".must-have-creds");
var printerButtonsToDisable = $(".must-have-printer");

var pollForAdd;

function setDelete(){
    isDelete = true;
    isShare = false;
    isSave = false;
    isRename = false;

    if(!printerIsSelected())
        return false;
}

function setShare(){
    isDelete = false;
    isShare = true;
    isSave = false;
    isRename = false;

    if(!printerIsSelected())
        return false;
}

function setSave(){
    isDelete = false;
    isShare = false;
    isRename = false;
    isSave = true;
}

function setRename(){
    isDelete = false;
    isShare = false;
    isSave = false;
    isRename = true;
}

var currentForm;


function showAddPrinter(){
    $("input").removeClass("error");
    $("select").removeClass("error");
    $(".errorMessage").html("");

    $('#add-printer').modal('show');
}

function printerIsSelected(){
    var selected = false;

    $( "input:checkbox.selectPrinter" ).each(function( ) {
        if(this.checked) {
            selected = true;
        }
    });

    if(selected)
        return true;
    else
        return false;
}


function showRenamePrinter(){

    var selectedPrinterId = $("#selectedPrinterId").val();
    var currentName = $("#" + selectedPrinterId).find(".currentName").text();

    if(!printerIsSelected())
        return false;

    var currentUrl = $("#renameUrl").val();

    var renameUrl = currentUrl + "printerId=" + selectedPrinterId + "&currentName=" + currentName + "";

    $("#renamePrinterFrame").attr("src", renameUrl);

    $('#renamePrinterFrame').load(function() {
        var params = $("#renamePrinterFrame").contents().find("#renamePrinterForm")[0].action;
        var action = getUrlParameter(params,"renamed");

        if(action == "true") {
            closeRenamePrinter();
        }
    });

    $('#rename-printer').modal('show');
}


function closeAddPrinter(){
    $('#add-printer').modal('hide');

    notifySuccess($("#printerAddedSuccess").val());

    setTimeout( function(){
            location.reload();
        }
        , 2000 );
}

function closeRenamePrinter(){
    $('#rename-printer').modal('hide');

    notifySuccess($("#printerRenamedSuccess").val());

    setTimeout( function(){
            location.reload();
        }
        , 2000 );
}


function doAjaxPost() {
    var googleEmail = $('#googleEmail').val();
    var googlePassword = $('#googlePassword').val();
    var googleProxy = $('#googleProxy').val();

    notifyInfo($("#runCredentialsTest").val());

    ajax({
        type : "POST",
        url : window.location.pathname + "/testGCP",
        data : "googleEmail=" + googleEmail + "&googlePassword=" + googlePassword + "&googleProxy=" + googleProxy,
        success : function(response) {
            notifySuccess($("#credentialsTestSuccess").val());
        },
        error : function(e) {
            notifyError($("#credentialsTestFailed").val());
        }
    });

    return false;
}


function getUrlParameter(source,sParam)
{
    var n = source.lastIndexOf('?');
    var result = source.substring(n + 1);

    var sURLVariables = result.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

function toggleButtonsDisabledNoPrinterSelected () {
    if (printerIsSelected()) {
        $(".to-disable").prop("disabled", false);
    }
    else {
        $(".to-disable").prop("disabled", true);
    }
}


function toggleButtonsDisabled () {
    if (!$(".selectPrinter:checked").length) {
        printerButtonsToDisable.prop("disabled", true);
    }
}

function redirectToGoogleAuth (resp, printerNumber) {
    $("#addPrinterWrapper").hide();
    $("#confirmAuthWrapper").show();

    stopSpinnerOnButton("#addPrinterSubmit");

    $("#addGooglePrinterLink").attr("href", resp);

    pollForAdd = setInterval(function () {pollForAddComplete(printerNumber)}, 5000);
}

function pollForAddComplete (printerNumber)
{
    ajax({
        method: "GET",
        url: "ajax/modal/add/poll/" + printerNumber,
        success: function (resp) {
            resp = JSON.parse(resp);
            if (resp.finished == "true") {
                clearInterval(pollForAdd);

                $("#add-printer").modal("hide");

                $("#confirmAuthWrapper").hide();
                $("#addPrinterWrapper").show();

                if (resp.added == "true") {
                    notifySuccess($("#printerAddedSuccess").val());

                    setTimeout(function () {
                        window.location = window.location;
                    }, 2000);
                }
                else {
                    notifyError($("#printerAddedError").val());
                }
            }
        },
        error: function (xhr) {

            clearInterval(pollForAdd);

            $("#add-printer").modal("hide");

            $("#confirmAuthWrapper").hide();
            $("#addPrinterWrapper").show();

            notifyError(xhr.responseText);
        }
    })
}


function resetAddPrinterModal ()
{
    $("#confirmAuthWrapper").hide();
    $("#addPrinterWrapper").show();

    stopSpinnerOnButton("#addPrinterSubmit");

    $("#add-printer").modal("hide");

    $("#newPrinterName").val("");
    $("#newPrinterMap").val($("#newPrinterMap option:first").val());
}

$(document).ready(function() {

    useAjaxForForm("#addPrinterForm", {
        beforeSend: function () {
          startSpinnerOnButton("#addPrinterSubmit");
        },
        success: function (resp) {
            redirectToGoogleAuth(resp, $("#newPrinterMap").val());
        },
        complete: function () {
            stopSpinnerOnButton("#addPrinterSubmit");

        },
        error: function () {
            stopSpinnerOnButton("#addPrinterSubmit");
        }
    });

    $("#closeAddPrinter").click(resetAddPrinterModal);

    $("#cancelAddPrinter").click(resetAddPrinterModal);

    buttonsToDisable.prop("disabled", false);

    toggleButtonsDisabled();

    //set event listeners for changes in the email and password fields
    googleEmail.on({
        click: toggleButtonsDisabled,
        keyup: toggleButtonsDisabled
    });
    googlePassword.on({
        click: toggleButtonsDisabled,
        keyup: toggleButtonsDisabled
    });

    $(".selectPrinter").click(toggleButtonsDisabled);

    $('input.selectPrinter').on('change', function() {
        $('input.selectPrinter').not(this).prop('checked', false);
        toggleButtonsDisabledNoPrinterSelected();
    });

    toggleButtonsDisabledNoPrinterSelected();

    $('#addPrinterFrame').load(function() {
        var params = $("#addPrinterFrame").contents().find("#addPrinterForm")[0].action;
        var action = getUrlParameter(params,"added");

        if(action == "true") {
            closeAddPrinter();
        }
    });

    $('input.selectPrinter').on('change', function() {
        $('input.selectPrinter').not(this).prop('checked', false);
        var selected = $('.selectPrinter:checked').length;
        if (selected == 0)
        {
           $("#selectedPrinterId").val("");
        }
    });

    $('form').submit(function(e) {
        currentForm = this;
        if(isDelete && $("#selectedPrinterId").val() != "") {
            $('#delete-confirm').modal('show');
        }else if(isShare && $("#selectedPrinterId").val() != "")
            $('#share-confirm').modal('show');
        else if(isSave) {
            if($("#isFirstLogin").val() == "true")
            notifySuccess($("#firstLogin").val());

            var formActionUrl = currentForm.action;

            var hasQueryParams = formActionUrl.includes("?");

            if(hasQueryParams)
            {
                currentForm.action = currentForm.action + "&save=true"
            }
            else
            {
                currentForm.action = currentForm.action + "?save=true"
            }
            currentForm.submit();
        }
        else if(isRename) {
            currentForm.action = currentForm.action + "?renamePrinter=true"
            currentForm.submit();
        }


        return false;
    });

    if ($('#invalidCredentials').length > 0) {
        notifyError($("#invalidCredentials").val());
    }


    var sPageURL = window.location.search.substring(1);

    var action = getUrlParameter(sPageURL,"deleted");

    if(action == "true") {
        notifySuccess($("#printerDeletedSuccess").val());
    }
});

function shareConfirm() {
    $("#share-confirm").modal("hide");
    window.open("https://www.google.com/cloudprint#printers/" + $("#selectedPrinterId").val(), '_blank');
}

function deleteConfirm() {
    $("#delete-confirm").modal("hide");

    notifyInfo($("#deletingPrinter").val());

    currentForm.action = currentForm.action.substring(0, currentForm.action.lastIndexOf("/")) + "?deletePrinter=true;";

    currentForm.submit();
}

var selectedPrinter;

function selectPrinter(id) {
    selectedPrinter = id;
    $("#selectedPrinterId").val(id);
}