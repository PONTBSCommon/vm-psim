/**
 * Created by cabanaj on 2/11/2015.
 *
 * Return codes:
 * 0 OK
 * 1 Contains username
 * 2 bad length
 * 3 bad combination, or sequence error
 *
 * Reference documentation:
 * 1. Minimum Length - 8
 * 2. If length is 8 or 9, the it should contain at least 1 alphabet, 1 numeric, 1special character combination.
 * 3. If length is 10 or more, it is sufficient if only two of alphabets, numeric, special characters are included.
 * However, there should be at least 2 of each of them.
 * examples) 3-combination : cert12!@(○), test1#(Ｘ)
 * 2-combination : security77(○), superman1(Ｘ)
 * 4. Make sure the 'useraccount' information is not repeated in the password.
 *   eg) id is test, pw is test12!@ (Ｘ)
 * 5. Make sure that the password does not have 4 or more consecutive alphabets or digits
 *   eg) abcd(Ｘ), abc(○), 123(○), 1234(Ｘ)
 */
var re = {
    lower: /[a-z]/g,
    upper: /[A-Z]/g,
    alpha: /[A-Z]/gi,
    numeric: /[0-9]/g,
    special: /[\W_]/g
};

function samsungPolicyEnforcementPassword(user, pw)
{
    // fill req 1
    // minimum 8 characters
    var pwLength = pw.length;
    if (pwLength < 8) {
        return 2;
    }

    // check the complexity
    var firstPass = validatePassword(pw, {
        alpha: 1,
        numeric: 1,
        special: 1
    });

    // fill req 2
    // if failed, do the aditional test
    if (!firstPass) {
        // fill req 3
        // require 10 or more characters
        if (pwLength < 10) {
            return 3;
        }

        /*
         * These are "class counts". They count the amount of letters that fit each class.
         *
         * 0 : alpha
         * 1 : num
         * 2 : special
         */
        var classCount = [0, 0, 0];


        // fill class count
        for (var i = 0; i < pw.length; i++) {
            var pwChar = pw[i]
            if (pwChar.match(re.alpha)) {
                classCount[0]++;
            }

            if (pwChar.match(re.numeric)) {
                classCount[1]++;
            }

            if (pwChar.match(re.special)) {
                classCount[2]++;
            }
        }

        // counts the amount of class counts that exceed "2"
        var combinationCount = 0;
        for (var j = 0; j < classCount.length; j++)
        {
            if (classCount[j] >= 2)
            {
                combinationCount++;
            }
        }

        // if there is less than 2 classes that have a 2 matches, complain.
        if (combinationCount < 2) return 3;
    }

    // fill req 4
    if (pw.toLowerCase().indexOf(user.toLowerCase()) != -1) return 1;

    // fill req 5
    var seqPass = validatePassword(pw, {
        badSequenceLength: 4
    });

    if (!seqPass) return 3;

    return 0;
}

function validatePassword(pw, options) {
    // default options (allows any password)
    var o = {
        lower: 0,
        upper: 0,
        alpha: 0, /* lower + upper */
        numeric: 0,
        special: 0,
        length: [0, Infinity],
        custom: [/* regexes and/or functions */],
        badWords: [],
        badSequenceLength: 0,
        noQwertySequences: false,
        noSequential: false
    };

    for (var property in options)
        o[property] = options[property];

    var rule, i;

    //enforce min/max length
    if (pw.length < o.length[0] || pw.length > o.length[1])
    {
        return false;
    }

    // enforce lower/upper/alpha/numeric/special rules
    for (rule in re) {
        if ((pw.match(re[rule]) || []).length < o[rule])
            return false;
    }

    // enforce word ban (case insensitive)
    for (i = 0; i < o.badWords.length; i++) {
        if (pw.toLowerCase().indexOf(o.badWords[i].toLowerCase()) > -1)
            return false;
    }

    // enforce the no sequential, identical characters rule
    if (o.noSequential && /([\S\s])\1/.test(pw))
        return false;

    // enforce alphanumeric/qwerty sequence ban rules
    if (o.badSequenceLength) {
        var lower = "abcdefghijklmnopqrstuvwxyz",
            upper = lower.toUpperCase(),
            numbers = "0123456789",
            qwerty = "qwertyuiopasdfghjklzxcvbnm",
            start = o.badSequenceLength - 1,
            seq = "_" + pw.slice(0, start);
        for (i = start; i < pw.length; i++) {
            seq = seq.slice(1) + pw.charAt(i);
            if (
                lower.indexOf(seq) > -1 ||
                upper.indexOf(seq) > -1 ||
                numbers.indexOf(seq) > -1 ||
                (o.noQwertySequences && qwerty.indexOf(seq) > -1)
            ) {
                return false;
            }
        }
    }

    // enforce custom regex/function rules
    for (i = 0; i < o.custom.length; i++) {
        rule = o.custom[i];
        if (rule instanceof RegExp) {
            if (!rule.test(pw))
                return false;
        } else if (rule instanceof Function) {
            if (!rule(pw))
                return false;
        }
    }

    // great success!
    return true;
}