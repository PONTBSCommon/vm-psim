var _currentDomain = "";
var _allowExternalRedirect = false;
var _targetLink;
var _domainRegex = /(^http[s]?:\/\/[^\/]+\/)/;
var _isHttpRegex = /^http[s]?:\/\//;
var _idleTime = 0;

/**
 * Contains utility methods that are accessible to every page.
 *
 * @author Lukas Rezek <lrezek@printeron.com>
 * @author Robert Bowering <rbowering@printeron.com>
 * @author Andrei Bershadski <abershadski@printeron.com>
 * @author Bruno Oliveira <boliveira@printeron.com>
 */

/**
 * Prevents a click from propagating to other components.
 *
 * @param e The click event.
 */
function preventPropogation(e) {

    if (!e) {
        e = window.event;
    }

    //IE9 & Other Browsers
    if (e.stopPropagation) {
        e.stopPropagation();
    }

    //IE8 and Lower
    else {
        e.cancelBubble = true;
    }
}

/**
 * Gets the id of the clicked element from a click event.
 *
 * @param event The click event
 * @returns {*} The element ID.
 */
function getIdFromEvent(event) {

    // Get the ID
    event = event || window.event; // IE
    var target = event.target || event.srcElement; // IE
    return target.id;
}

/**
 * Grabs URL parameters.
 *
 * @param source The source string
 * @param sParam The parameter to get
 * @returns {*}
 */
function getUrlParameter(source,sParam)
{
    var n = source.lastIndexOf('?');
    var result = source.substring(n + 1);

    var sURLVariables = result.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

/**
 * Run on document load.
 */
$(document).ready(function () {

    // Clear the session timeout on ajax calls
    $(document).bind('ajaxSend', function () {
        _idleTime = 0;
    });

    // Set up session timer
    setInterval(function () {

        // Redirect to login page if the session is expired
        if (_idleTime >= SESSION_TIMEOUT) {
            window.location = CONTEXT + "/login";

        // Increase idle time otherwise
        } else {
            _idleTime += SESSION_CHECK_INTERVAL;
        }

    }, SESSION_CHECK_INTERVAL);

    // Regex out our domain
    _currentDomain = _domainRegex.exec(window.location)[0];

    $('#menu-showAdvancedSettings').on({
        "click":function(e){
            e.stopPropagation();
            $('#toggle').bootstrapToggle('toggle');
            ADVANCED_VIEW_ENABLED = $('#toggle').prop('checked');

            ajax({
                url: CONTEXT + "/status/generalSettings/showAdvancedSettings/" + $('#toggle').prop('checked'),
                type: "POST",
                success: function (resp) {
                    advancedSettingsToggle();
                }
            });
        }
    });

    //Turn autocomplete off for all inputs
    $('input, :input').attr('autocomplete', 'off');

    // Bind necessary error handlers
    bindErrorHandler();

    // Equalize required row element heights
    handleFlexRows();

    setUpAdvancedView(ADVANCED_VIEW_ENABLED);

    // When a link is clicked, check to see if it is external. If so, display a warning.
    $("a[href]").click(function () {
        // We can only get the fully qualified href from the DOM object, not the jQuery object
        if (isExternalUrl(this.href)) {
            if (_allowExternalRedirect) {
                _allowExternalRedirect = false;
            }
            else {
                _targetLink = $(this);
                $("#__redirectWarningModal").modal("show");
                return false;
            }
        }
    });

    // When the OK button of the redirect warning is clicked,
    // turn allow external redirect on, then trigger the original link.
    $("#__redirectWarningModalOK").click(function () {
        _allowExternalRedirect = true;
        // jQuery click won't trigger navigation. Get the DOM object, then call click
        _targetLink[0].click();
        $("#__redirectWarningModal").modal("hide");
    });

    $.fn.dataTable.ext.errMode = function () {
        notifyError($(".js-dataTableErrorMessage").last().val());
    }

});


/**
 * Checks if a link is external or not.
 * Returns true if the link has a different domain. False if it has the same domain, or does not start with http
 *
 * @param url
 * @returns {boolean}
 */
function isExternalUrl(url) {
    if (_isHttpRegex.test(url)) {
        return !url.startsWith(_currentDomain);
    }
    else {
        return false;
    }
}

/**
 * Toggle the advanced settings.
 */
function advancedSettingsToggle()
{
    var mailOption = $("#emailType").find(":selected").text();

    //handle the e-mail type None option
    if(mailOption != "None")
    {
        //Call set on iframes
        $("iframe").each(function(index)
        {
            if($(this)[index])
            {
                var iframeHeight;

                //Show hide elements to calculate the right height and hide back
                if(ADVANCED_VIEW_ENABLED)
                {
                    $('.advancedSetting', this.contentDocument).show();
                    iframeHeight = window.parent.document.body.scrollHeight;
                    $('.advancedSetting', this.contentDocument).hide();
                }
                else
                {
                    iframeHeight = window.parent.document.body.scrollHeight;
                }

                $('.advancedSetting', this.contentDocument).slideToggle('slow');

                $(this)[index].height = iframeHeight;
            }
        });

        $(".advancedSetting").slideToggle('slow');
    }
}

/**
 * Binds the default error handler to invalid form inputs, this can be called again if new fields are added.
 */
function bindErrorHandler() {

    // Get all the forms
    var forms = document.getElementsByTagName('form');
    for (var i = 0; i < forms.length; i++) {
        forms[i].addEventListener('invalid', function(e) {
            e.preventDefault();
            //Possibly implement your own here.
        }, true);
    }

    // Register an invalid event handler
    $("form input").on("invalid", function(event) {

        var target = $(this).parents(".row").children(".errorMessage");

        // Add error class to input
        $(this).addClass("error");

        // Insert the error message
        var message;
        var type = $(this).attr('type');
        if (type == "number") {
            message = $("#mustBeANumber").val();
        } else if (type == "url") {
            message = $("#mustBeAURL").val();
        }

        target.html("<span class='error-tooltip' title='" + message + "'><span class='glyphicons glyphicons-circle-exclamation-mark'></span></span>");
    });

    // Remove the error class and message on submit
    $("button[type=submit]").on("click", function(e) {
        resetErrorsOnForm($(this.form))
    });
}

function resetErrorsOnForm (form) {
    if (typeof form === "undefined") {
        form = $("body")
    }

    $("input", form).removeClass("error");
    $("select", form).removeClass("error");
    $(".errorMessage", form).html("");
}

/**
 * Adds an error to a field.
 *
 * @param field The field.
 * @param error The error.
 */
function addErrorToField (field, error) {
    $(field).addClass("error");
    var target = $(field).parents(".row").first().find(".errorMessage");
    target.html("<span class='error-tooltip' title='" + error + "'><span class='glyphicons glyphicons-circle-exclamation-mark'></span></span>");
}

/**
 * Handles rows with the "flex" class. All panels and wells should be equal heights within flex rows.
 */
function handleFlexRows() {

    // Loop over all the flex rows
    $(".row.flex").each(function(i, row) {

        // Equalize everything inside columns in the row
        $(row).children('div[class|="col"]').children().responsiveEqualHeightGrid();
    });
}

/**
 * Determines if a modal is open.
 *
 * @param modal The modal.
 * @returns {null|*}
 */
function isModalOpen(modal) {

    return (modal.data('bs.modal') || {}).isShown;
}

/**
 * Helper function for refreshing the current page.
 */
function refresh() {
    window.location.href = window.location.href;
}

/**
 * Hide and Show Advanced Settings
 * @param advanced Whether to show advanced config.
 * hide or show the advanced settings.
 */
function setUpAdvancedView(advanced) {

    if(advanced) {
        $('#toggle').bootstrapToggle('on');
        $(".advancedSetting").show();
    } else {
        $('#toggle').bootstrapToggle('off');
        $(".advancedSetting").hide();
    }
}

/**
 * Utility method for determining if a string ends with another string.
 *
 * @param suffix The suffix
 * @returns {boolean} True if the ending is there, false otherwise.
 */
String.prototype.endsWith = function(suffix) {
    return this.indexOf(suffix, this.length - suffix.length) !== -1;
};

// Add a startsWith polyfill if required
if(!String.prototype.startsWith) {

    /**
     * Utility method for determining if a string starts with another string.
     *
     * @param prefix The prefix we're looking for.
     * @param startPosition The starting position. Defaults to 0.
     * @returns {boolean} True if the string is there, false otherwise.
     */
    String.prototype.startsWith = function(prefix, startPosition) {
        startPosition = startPosition || 0;
        return this.indexOf(prefix, startPosition) === startPosition;
    };
}

/**
 * Removes the last slash from the text
 * @param text - URL for example
 * @returns string without the last slash
 */
function trailingSlash(text)
{
    if (text != null && text !== undefined) {
        text = text.replace(/\/$/, '');
    }

    return text;
}

/**
 * Get specified query parameter from the URL
 * @param paramName - parameter name to pull from the URL
 * @returns string - value of query parameter specified
 */
function getQueryParameter(paramName) {
    var str = window.location.search;
    var objURL = {};

    str.replace(
        new RegExp( "([^?=&]+)(=([^&]*))?", "g" ),
        function( $0, $1, $2, $3 ){
            objURL[ $1 ] = $3;
        }
    );
    return objURL[paramName];
}