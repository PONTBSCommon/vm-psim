/**
 * Server list JS.
 *
 * @author Lukas Rezek <lrezek@printeron.com>
 */
var uuidToDelete;
var rowsToDelete = [];

$(document).ready(function() {

    var table = $("#serverTable");

    // Initialize datatable, if required
    if(!table.hasClass("hidden")) {

        dtLoad(table, {"order": [[$("#onlineStatus").index(), 'asc']]});

        // Add an onclick to the remove buttons for all servers
        dtQueryRows("[id^='remove_']").click(showConfirmationDialog);

        // Add an onclick to the configure buttons for all servers
        dtQueryRows("[id^='configure_']").click(showComponentsDialog);

        // Add onclick to confirmation button
        $("#confirmationButton").click(removeServer);
    }
});

/**
 * Shows the dialog with the list of servers this delete would remove.
 *
 * @param event The event spawning this dialog.
 */
function showConfirmationDialog(event) {

    // Get the ID
    var id = getIdFromEvent(event);

    // Blur the select box outta here
    $("#" + id).parent().blur();

    // Split the id on hyphens
    var parts = id.split('_');

    // Get the UUID, it's the second part
    uuidToDelete = parts[1];

    // Get the list of children affected by this remove
    ajax({
        url: CONTEXT + "/servers/" + uuidToDelete + "/children",
        type: "GET",
        success: function(resp) {

            // Find your own row
            var thisRow = dtGetRowById("row_" + uuidToDelete);

            // Add your own row
            rowsToDelete = [thisRow];

            // No child servers, just remove it
            if(resp.length == 0) {

                removeServer();

            // Some child servers, show confirmation
            } else {

                var dialog = $("#confirmationDialog");
                var serverList = dialog.find("#serversAffected");

                // Clear the server list
                serverList.find("li").remove();

                // Loop over affected servers
                for(var i = 0; i < resp.length; i++) {

                    // Get the row and host name
                    var row = dtGetRowById("row_" + resp[i]);
                    var hostName = row.find(".hostName").html().trim();

                    // Add host name to server list
                    serverList.append("<li>" + hostName + "</li>");

                    // Add row to row delete list
                    rowsToDelete.push(row);
                }

                // Show the confirmation
                dialog.modal("show");
            }
        },
        error: function () {

            notifyError($("#subServerFailed").val());
        }
    });
}

/**
 * Shows the components dialog.
 *
 * @param event The click event.
 */
function showComponentsDialog(event){

    // Get the ID
    var id = getIdFromEvent(event);

    // Blur the select box outta here
    $("#" + id).parent().blur();

    // Split the id on hyphens
    var parts = id.split('_');

    // Get the server UUID
    var uuid = parts[1];

    // Send an ajax request for the list of components
    ajax({
        url: CONTEXT + "/servers/" + uuid + "/components",
        type: "GET",
        success: function(resp) {

            if(resp.length == 0) {

                // Hide the table, show the error
                $("#componentList").addClass("hidden");
                $("#noComponents").removeClass("hidden");

            } else {

                var tbody = "";

                // Loop over the response, make TR's out of every entry
                for (var i = 0; i < resp.length; i++) {

                    var tr = "<tr><td>";

                    tr += resp[i].name;
                    tr += '</td><td>';

                    if (resp[i].online) {

                        tr += '<span class="glyphicons glyphicons-ok x1 green"></span>';
                        tr += '</td><td class="text-right">';
                        tr += '<a href="' + CONTEXT + '/' + resp[i].type + '/' + resp[i].uuid + '"><button type="button" class="btn btn-default">' + $("#configureLabel").val() + '</button></a>';
                        tr += "</td>";

                    } else {

                        tr += '<span class="glyphicons glyphicons-remove x1 red"></span>';
                        tr += '</td><td class="text-right">';
                        tr += '<a href="' + CONTEXT + '/' + resp[i].type + '/' + resp[i].uuid + '"><button disabled type="button" class="btn btn-default">' + $("#configureLabel").val() + '</button></a>';
                        tr += "</td>";
                    }

                    tr += "</tr>";

                    tbody += tr;
                }

                // Replace the HTML in the tbody modal
                $("#componentTableBody").html(tbody);

                // Show the table, hide the error
                $("#componentList").removeClass("hidden");
                $("#noComponents").addClass("hidden");
            }

            // Show the modal
            $("#componentsDialog").modal("show");
        },
        error: function() {

            notifyError($("#componentListingFailed").val());
        }
    });
}

/**
 * Removes a server via ajax.
 */
function removeServer() {

    var button = $("#confirmationButton");

    startSpinnerOnButton(button);

    // Do the ajax call
    ajax({
        url: CONTEXT + "/servers/" + uuidToDelete,
        type: "DELETE",
        success: function () {

            // Remove the rows
            for (var i = 0; i < rowsToDelete.length; i++) {
                dtRemoveRow(rowsToDelete[i]);
            }

            // Refresh the table with the changes
            dtRedraw();

            // Check if you have no more entries, remove the table and display "none connected"
            if (dtGetRowCount() == 0) {

                dtDestroy();
                $("#noServers").removeClass("hidden");
            }

            // Clear out old data
            rowsToDelete = [];
            uuidToDelete = null;

            stopSpinnerOnButton(button);

            $("#confirmationDialog").modal("hide");
        },
        error: function () {

            notifyError($("#removeFailed").val());
        }
    });
}